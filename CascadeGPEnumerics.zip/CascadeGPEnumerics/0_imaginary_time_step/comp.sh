############## comp.sh ###########################
#!bin/bash
LIB="-lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core -lpthread"
OPTION=" -CB -traceback -check all -parallel -openmp -openmp-report2 -shared-intel -mcmodel=large"

ifort ${OPTION} ${LIB} ${1} 

#####################################################