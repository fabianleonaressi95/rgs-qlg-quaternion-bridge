include 'mkl_dfti.f90'

!-------------------------------------------------------------------------------------------------------------------------
module setup
   implicit none

!parameters and arrays for real and wave-number coordinate
integer :: ix, iy, iz
integer, parameter :: Nx = 128, Ny = 128, Nz = 128, Nxh = Nx/2, Nyh = Ny/2, Nzh = Nz/2, Nxyz = Nx*Ny*Nz, Nr = Nx/2
double precision :: dx, dy, dz, dr, dkx, dky, dkz, dkr, x(0:Nx), y(0:Ny), z(0:Nz), rxy(0:Nx,0:Ny), &
                    kx(0:Nx), ky(0:Ny), kz(0:Nz), kxyz(0:Nx,0:Ny,0:Nz), kxyz2(0:Nx,0:Ny,0:Nz), kr(0:Nr)
double precision, parameter :: Lx = 40.d0, Ly = 40.d0, Lz = 40.d0, eta = 1.16411621952d0, tau = 0.00370862441837d0, &
                               Rpxy = 16.d0/eta, Lpz = 27.d0/eta, Vh = 3.2d0*10.d0**( 9.d0/9.d0*dlog10(64.d0/3.2d0) )

!parameters
double precision, parameter :: a = 0.114705260445d0, pi = 4.d0*datan(1.d0), Ntp = 1.2d0*(10.d0**5.d0)
complex(kind(0d0)), parameter :: uso = (0.d0, 1.d0)

!parameters and arrays of time
double precision ::  dt = 4.d0*(0.1d0)**3.d0
integer, parameter :: Nstep = (10**8), parameter_t = 1
integer :: Ntime, jikoku(8)
double precision :: time, time_start,time_end, stime, etime
character(len=40) filename

!arrays for wavefunction
complex(kind(0d0)),dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: psir1, psik1, psika1, psikb1, nlgp1, potgp1, rg1

!parameters and arrays for the fourth-Order Runge-Kutta method
integer :: Nrg
double precision :: crg1(1:4), crg2(1:4)

!parameters and arrays for physical quantities
double precision :: Nt, mu, Et, Ek, Ep, Ed, Eb, gamma(0:Nx-1,0:Ny-1,0:Nz-1)
double precision,dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: n, pot, phase

!array for MKL fast fourier transformation
complex(kind(0d0)),dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: funcx, funcy, funcz, func1, func2, func3, func4

  contains

  subroutine rg_set
     crg1(1) = 0.d0
     crg1(2) = 0.5d0*dt
     crg1(3) = 0.5d0*dt
     crg1(4) = dt
     crg2(1) = dt/6.d0
     crg2(2) = dt/3.d0
     crg2(3) = dt/3.d0
     crg2(4) = dt/6.d0
  end subroutine rg_set

  subroutine coordinate_set
  !real corrdinate
        dx = Lx/dble(Nx)
        dy = Ly/dble(Ny)
        dz = Lz/dble(Nz)
     do ix=0,Nx
        x(ix) = dx*dble(ix)
     end do
     do iy=0,Ny
        y(iy) = dy*dble(iy)
     end do
     do iz=0,Nz
        z(iz) = dz*dble(iz)
     end do
     do iy=0,Ny; do ix=0,Nx
        rxy(ix,iy)  = dsqrt( (x(ix)-Lx/2.d0)**2.d0 + (y(iy)-Ly/2.d0)**2.d0 )
     end do; end do

  !wave number coordinate
       dkx = 2.d0*pi/Lx
       dky = 2.d0*pi/Ly
       dkz = 2.d0*pi/Lz
       dkr = dkx
    do ix=0,Nxh
       kx(ix) = dkx*dble(ix)
    end do
    do ix=Nxh+1,Nx
       kx(ix) = dkx*( dble(ix) - dble(Nx) )
    end do

    do iy=0,Nyh
       ky(iy) = dky*dble(iy)
    end do
    do iy=Nyh+1,Ny
       ky(iy) = dky*( dble(iy) - dble(Ny) )
    end do

    do iz=0,Nzh
       kz(iz) = dkz*dble(iz)
    end do
    do iz=Nzh+1,Nz
       kz(iz) = dkz*( dble(iz) - dble(Nz) )
    end do

    do ix=0,Nxh
       kr(ix) =  dkr*dble(ix)
    end do

    do iz=0,Nz; do iy=0,Ny; do ix=0,Nx
       kxyz(ix,iy,iz)  = dsqrt(kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0)
       kxyz2(ix,iy,iz) = kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0
    end do; end do; end do

    do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
       if(rxy(ix,iy)>Rpxy+3.d0 .or. dabs(z(iz)-Lz/2.d0)>Lpz/2.d0+3.d0 ) then
          gamma(ix,iy,iz) = 1.d0
       else
          gamma(ix,iy,iz) = 1.d0
       end if
    end do; end do; end do

    do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
       if(rxy(ix,iy)>Rpxy .or. dabs(z(iz)-Lz/2.d0)>Lpz/2.d0 ) then
          pot(ix,iy,iz) = Vh
       else
          pot(ix,iy,iz) = 0.d0
       end if
    end do; end do; end do
  end subroutine coordinate_set

  subroutine cpu_start
  	 call cpu_time (time_start)
	   call date_and_time(values=jikoku)
	   open(parameter_t,file='cpu_time.txt',form='formatted')
	   write(parameter_t,*)'start'
	   write(parameter_t,*)jikoku(2),'mon',jikoku(3),'th',jikoku(5),'h',jikoku(6),'min',jikoku(7),'sec'
     stime = dble(jikoku(6))*60 + dble(jikoku(7)) + dble(jikoku(8))/1000
  end subroutine cpu_start

  subroutine cpu_end
     call date_and_time(values=jikoku)
     write(parameter_t,*)'stop'
     write(parameter_t,*)jikoku(2),'mon',jikoku(3),'th',jikoku(5),'h',jikoku(6),'min',jikoku(7),'sec'
     call cpu_time (time_end)
     write(parameter_t,*)'cputime'
     write(parameter_t,*)time_end-time_start
     close(parameter_t)
     etime = dble(jikoku(6))*60 + dble(jikoku(7)) + dble(jikoku(8))/1000
  end subroutine cpu_end

end module setup
!-------------------------------------------------------------------------------------------------------------------------


!-------------------------------------------------------------------------------------------------------------------------
module FFT
  use setup
  use mkl_dfti
  implicit none
  TYPE(dfti_descriptor), pointer, save :: handle
  integer :: stat

  contains

  subroutine FFT_init
     stat = dfticreatedescriptor(handle,dfti_double,dfti_complex,3,(/Nx,Ny,Nz/))
     stat = dfticommitdescriptor(handle)
     return
  end subroutine FFT_init

  subroutine forwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nxyz)
     func(:) = func(:)/dble(Nxyz)
     stat = dfticomputeforward(handle,func)
     return
  end subroutine forwardFFT

  subroutine backwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nxyz)
     stat = dfticomputebackward(handle,func)
     return
  end subroutine backwardFFT

  subroutine diffx(f)
     complex(kind(0d0)), intent(inout) :: f(0:Nx-1,0:Ny-1,0:Nz-1)
     call forwardFFT(f)
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        f(ix,iy,iz) = uso*kx(ix)*f(ix,iy,iz)
     end do; end do; end do
     call backwardFFT(f)
  end subroutine diffx

  subroutine diffy(f)
     complex(kind(0d0)), intent(inout) :: f(0:Nx-1,0:Ny-1,0:Nz-1)
     call forwardFFT(f)
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        f(ix,iy,iz) = uso*ky(iy)*f(ix,iy,iz)
     end do; end do; end do
     call backwardFFT(f)
  end subroutine diffy

  subroutine diffz(f)
     complex(kind(0d0)), intent(inout) :: f(0:Nx-1,0:Ny-1,0:Nz-1)
     call forwardFFT(f)
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        f(ix,iy,iz) = uso*kz(iz)*f(ix,iy,iz)
     end do; end do; end do
     call backwardFFT(f)
  end subroutine diffz

end module FFT
!-------------------------------------------------------------------------------------------------------------------------


!-------------------------------------------------------------------------------------------------------------------------
module cal_phy_quan
  use setup
  use mkl_dfti
  use FFT
  implicit none

  contains

  subroutine initial_state
        psir1(:,:,:)    = 0.d0
	   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
	      psir1(ix,iy,iz) = ( dsqrt(2.d0) )*dexp( -( (x(ix)-Lx/2.d0)**2.d0 + (y(iy)-Ly/2.d0)**2.d0 + (z(iz)-Lz/2.d0)**2.d0 )/80.d0  )
     end do; end do; end do

        Nt = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Nt = Nt + cdabs(psir1(ix,iy,iz))**2.d0
     end do; end do; end do
        Nt = Nt*dx*dy*dz

     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        psir1(ix,iy,iz) = dsqrt(Ntp/Nt)*psir1(ix,iy,iz)
     end do; end do; end do

	   psikb1(:,:,:) = psir1(:,:,:)
	   call forwardFFT(psikb1)
	   psik1(:,:,:)  = psikb1(:,:,:)

     !$omp parallel shared(psir1,n,nlgp1,pot),private(ix,iy,iz)
     !$omp do
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
	      n(ix,iy,iz)     = cdabs(psir1(ix,iy,iz))**2.d0
        nlgp1(ix,iy,iz) = a*n(ix,iy,iz)*psir1(ix,iy,iz)+ pot(ix,iy,iz)*psir1(ix,iy,iz)
     end do; end do; end do
     !$omp end do
     !$omp end parallel
     call forwardFFT(nlgp1)
  end subroutine initial_state

  subroutine field
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        n(ix,iy,iz) = cdabs(psir1(ix,iy,iz))**2.d0
     end do; end do; end do
  end subroutine field

  subroutine particle_number
        Nt = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Nt = Nt + cdabs(psir1(ix,iy,iz))**2.d0
     end do; end do; end do
        Nt = Nt*dx*dy*dz
  end subroutine particle_number

  subroutine energy
        call field
        Ek = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Ek = Ek + kxyz2(ix,iy,iz)*cdabs(psikb1(ix,iy,iz))**2.d0
     end do; end do; end do
        Ek = Ek*Lx*Ly*Lz

        Ep = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Ep = Ep + pot(ix,iy,iz)*n(ix,iy,iz)
     end do; end do; end do
        Ep = Ep*dx*dy*dz

        Ed = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Ed = Ed + 0.5d0*a*n(ix,iy,iz)**2.d0
     end do; end do; end do
        Ed = Ed*dx*dy*dz

        Et = Ek + Ep + Ed
  end subroutine energy

  subroutine chemical_potential
     call field
     call particle_number

         Ek = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         Ek = Ek + kxyz2(ix,iy,iz)*cdabs(psik1(ix,iy,iz))**2.d0
     end do; end do; end do
         Ek = Ek*Lx*Ly*Lz

         Ep = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         Ep = Ep + pot(ix,iy,iz)*n(ix,iy,iz)
     end do; end do; end do
         Ep = Ep*dx*dy*dz

         Ed = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         Ed = Ed + n(ix,iy,iz)**2.d0
     end do; end do; end do
         Ed = 0.5d0*a*Ed*dx*dy*dz
         mu = (Ek + Ep + 2.d0*Ed)/Nt
  end subroutine chemical_potential

end module cal_phy_quan
!-------------------------------------------------------------------------------------------------------------------------
