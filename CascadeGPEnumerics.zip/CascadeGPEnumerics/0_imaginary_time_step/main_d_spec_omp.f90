include 'sub_d_spec_omp.f90'

program kazuya
!$use omp_lib
  use setup
  use mkl_dfti
  use FFT
  use cal_phy_quan
  implicit none

  call coordinate_set
  call rg_set
  call FFT_init
  call initial_state
  call chemical_potential

  open(3,file="particle_number.txt")
  open(4,file="energy.txt")
  open(5,file="wavefunction.tat",form="unformatted")

  Eb    = 0.d0
  time  = 0.d0

  call field
  call particle_number
  print *, "total particle number"
  print *, Nt

!*************************** Time evolution ***************************
!Fourth-Order Runge-Kutta method
!**********************************************************************

!***************computation time(start)***************
  call cpu_start

do Ntime=1,Nstep
   !$omp parallel shared(psika1,rg1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psika1(ix,iy,iz) = 0.d0
      rg1(ix,iy,iz)    = 0.d0
   end do; end do; end do
   !$omp end do
   !$omp end parallel

   do Nrg=1,4
      !$omp parallel shared(psir1,psik1,psikb1,crg1,rg1),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         psik1(ix,iy,iz) = (psikb1(ix,iy,iz)+crg1(Nrg)*rg1(ix,iy,iz))
         psir1(ix,iy,iz) = psik1(ix,iy,iz)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
      call backwardFFT(psir1)

      !calculation of the nonlinear and potential terms
      !$omp parallel shared(psir1,n,nlgp1,pot,x,y,z,rxy),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         n(ix,iy,iz)     =  cdabs(psir1(ix,iy,iz))**2.d0
         nlgp1(ix,iy,iz) = a*n(ix,iy,iz)*psir1(ix,iy,iz) + pot(ix,iy,iz)*psir1(ix,iy,iz)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
      call forwardFFT(nlgp1)

      call chemical_potential
      !$omp parallel shared(psika1,psik1,nlgp1,crg2,kxyz2,rg1,gamma),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         rg1(ix,iy,iz)    = ((kxyz2(ix,iy,iz)-mu)*psik1(ix,iy,iz) + nlgp1(ix,iy,iz))/(- gamma(ix,iy,iz))
         psika1(ix,iy,iz) = psika1(ix,iy,iz) + rg1(ix,iy,iz)*crg2(Nrg)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
   end do

   !$omp parallel shared(psika1,psikb1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psika1(ix,iy,iz) = psika1(ix,iy,iz) + psikb1(ix,iy,iz)
   end do; end do; end do
   !$omp end do
   !$omp end parallel
   time = dble(Ntime)*dt

   !for the next step
   !$omp parallel shared(psika1,psikb1,psir1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psikb1(ix,iy,iz) = psika1(ix,iy,iz)
      psir1(ix,iy,iz)  = psika1(ix,iy,iz)
   end do; end do; end do
   !$omp end do
   !$omp end parallel
   call backwardFFT(psir1)

   call field
   call particle_number
   call energy
   write(3,'(8(E23.15))') time, Nt
   write(4,'(6(E23.15))') time, Et, Ek, Ep, Ed, dabs(Et-Eb)/dabs(Et)

   if(ddim(dabs(Et-Eb),dabs(Et)*10**(-12.d0)) == 0) exit
      Eb = Et

end do

   call cpu_end
   write(5) (((psir1(ix,iy,iz),iz=0,Nz-1),iy=0,Ny-1),ix=0,Nx-1)

end program kazuya
