The numerical codes are composed of the following four directories.
The height of the box potential is set by Vh.

[0_imaginary_time_step]
Numerical codes for preparing an initial state. The numerical data for the initial state is stored in "wavefunction.tat".
*******************************
How to implement a simulation
Step 1 "./comp.sh main_d_spec_omp.f90"
Step 2 "./a.out"
*******************************

[1_bdg]
Numerical codes for calculating energy excitations by using the Bogoliubov-de Gennes equation. The numerical data for the energy is stored in "energy.txt".
*******************************
How to implement a simulation
Step 1 Copy "wavefunction.tat" of [0_imaginary_time_step] in the working directory.
Step 2 "./comp.sh main_bdg.f90"
Step 3 "./a.out"
*******************************

[2_time_evolution]
Numerical codes for calculating real-time evolution by using the Gross-Pitaevskii equation. The numerical data for the particle loss (Figs.3, 4, and S2) is stored in "particle_number.txt".
*******************************
How to implement a simulation
Step 1 Copy "wavefunction.tat" of [0_imaginary_time_step] in the working directory.
Step 2 "./comp.sh main_d_spec_omp.f90"
Step 3 "./a.out"
*******************************

[3_momentum_distribution]
Numerical codes for calculating the momentum distribution. In a simulation of [2_time_evolution], the data for the macroscopic wavefunction is stored in "out_wavefunction.tat". Using the data, the numerical codes calculate the time evolution of the momentum distributions (Fig.S3). The numerical data for the momentum distributions is stored in "momentum_distiribution(time_label).txt".
*******************************
How to implement a simulation
Step 1 Copy "out_wavefunction.tat" of [2_time_evolution] in the working directory.
Step 2 "./comp.sh main_spectrum.f90"
Step 3 "./a.out"
*******************************