include 'sub_d_spec_omp.f90'

program kazuya
!$use omp_lib
  use setup
  use mkl_dfti
  use FFT
  use cal_phy_quan
  use mt19937
  implicit none

  call coordinate_set
  call rg_set
  call FFT_init
  call initial_state

  open(3,file="particle_number.txt")
  open(4,file="energy.txt")
  open(5,file="out_wavefunction.tat",form="unformatted")

  mu    = a*cdabs(psir1(Nxh,Nyh,Nzh))**2.d0
  amp   = 1.215d0/Lpz
  omega = 0.20269798d0
  time  = 0.d0
  print *, mu

  call field
  call particle_number
  call energy

  write(3,'(4(E23.15))') time*tau, Nt, Ntp-Nt
  write(4,'(6(E23.15))') time*tau, Et, Ek, Ep, Ed
  write(5) (((psir1(ix,iy,iz),iz=0,Nz-1),iy=0,Ny-1),ix=0,Nx-1)


!*************************** Time evolution ***************************
!The fourth-Order Runge-Kutta method
!**********************************************************************

!***************computation time(start)***************
   call cpu_start

do Ntime = 1, Nstep

   !$omp parallel shared(psika1,rg1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psika1(ix,iy,iz) = 0.d0
      rg1(ix,iy,iz)    = 0.d0
   end do; end do; end do
   !$omp end do
   !$omp end parallel

   do Nrg = 1, 4

      !$omp parallel shared(psir1,psik1,psikb1,crg1,rg1),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         psik1(ix,iy,iz) = (psikb1(ix,iy,iz)+crg1(Nrg)*rg1(ix,iy,iz))
         psir1(ix,iy,iz) = psik1(ix,iy,iz)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
      call backwardFFT(psir1)

      !calculation of nonlinear and potential terms
      !$omp parallel shared(psir1,n,nlgp1,pot_e,pot_s,x,y,z,rxy),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         n(ix,iy,iz)        = cdabs(psir1(ix,iy,iz))**2.d0
         pot_e(ix,iy,iz)    = amp*( dsin(omega*(time+crg1(Nrg))) )*z(iz)
         nlgp1(ix,iy,iz)    = a*n(ix,iy,iz)*psir1(ix,iy,iz) + (pot_s(ix,iy,iz)+pot_e(ix,iy,iz))*psir1(ix,iy,iz) &
                             -uso*gamma(ix,iy,iz)*psir1(ix,iy,iz)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
      call forwardFFT(nlgp1)

      !$omp parallel shared(psika1,psik1,nlgp1,crg2,kxyz2,rg1,gamma),private(ix,iy,iz)
      !$omp do
      do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
         rg1(ix,iy,iz)    = ((kxyz2(ix,iy,iz))*psik1(ix,iy,iz) + nlgp1(ix,iy,iz))/uso
         psika1(ix,iy,iz) = psika1(ix,iy,iz) + rg1(ix,iy,iz)*crg2(Nrg)
      end do; end do; end do
      !$omp end do
      !$omp end parallel
   end do

   !$omp parallel shared(psika1,psikb1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psika1(ix,iy,iz) = psika1(ix,iy,iz) + psikb1(ix,iy,iz)
   end do; end do; end do
   !$omp end do
   !$omp end parallel
   time = dble(Ntime)*dt

   !for next step
   !$omp parallel shared(psika1,psikb1,psir1),private(ix,iy,iz)
   !$omp do
   do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
      psikb1(ix,iy,iz) = psika1(ix,iy,iz)
      psir1(ix,iy,iz)  = psika1(ix,iy,iz)
   end do; end do; end do
   !$omp end do
   !$omp end parallel
   call backwardFFT(psir1)


   if(mod(Ntime,1000) == 0) then
	    call field
      call particle_number
      call energy
      write(3,'(4(E23.15))') time*tau, Nt, Ntp-Nt
      write(4,'(6(E23.15))') time*tau, Et, Ek, Ep, Ed
   end if

   if(mod(Ntime,10000) == 0) then
      write(5) (((psir1(ix,iy,iz),iz=0,Nz-1),iy=0,Ny-1),ix=0,Nx-1)
   end if

   if(Ntime == Nstep) exit

end do

   call cpu_end

end program kazuya
