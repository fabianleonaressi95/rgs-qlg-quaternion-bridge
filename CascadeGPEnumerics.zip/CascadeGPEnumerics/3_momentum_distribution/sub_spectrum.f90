include 'mkl_dfti.f90'

!------------------------------------------------------------------------------------------------------------------
module setup
   implicit none

!parameters and arrays for real and wave-number coordinate
integer :: ix, iy, iz, j1, j2, j3, l, m
integer, parameter :: Nx = 128, Ny = 128, Nz = 128, Nxh = Nx/2, Nyh = Ny/2, Nzh = Nz/2, Nxyz = Nx*Ny*Nz, Nr = Nx/2
double precision :: dx, dy, dz, dkx, dky, dkz, dkr, x(0:Nx), y(0:Ny), z(0:Nz), rxy(0:Nx,0:Ny), &
                    kx(0:Nx), ky(0:Ny), kz(0:Nz), kxyz(0:Nx,0:Ny,0:Nz), kxyz2(0:Nx,0:Ny,0:Nz), kr(0:Nr)
double precision, parameter :: Lx = 40.d0, Ly = 40.d0, Lz = 40.d0, eta = 1.16411621952d0, tau = 0.00370862441837d0, &
                               Rpxy = 16.d0/eta, Lpz = 27.d0/eta, Vh = 3.2d0*10.d0**( 9.d0/9.d0*dlog10(64.d0/3.2d0) )

!parameters
double precision, parameter :: a = 0.114705260445d0, pi = 4.d0*datan(1.d0)
complex(kind(0d0)), parameter :: uso = (0.d0, 1.d0)

!parameters and arrays of time
integer :: Ntime, jikoku(8), time
integer, parameter :: Nstep = 400, parameter_t = 1
double precision :: time_start,time_end, stime, etime
double precision, parameter :: dt = 1.d0*(0.1d0)**3.d0
character(len=40) filename

!arrays for wavefunction
complex(kind(0d0)),dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: psir1, psik1

!parameters and arrays for physical quantities
double precision :: Nt, Nkr(0:Nr), dummy1, dummy2

!array for MKL fast fourier transformation
complex(kind(0d0)),dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: func

  contains

  subroutine coordinate_set
     !real corrdinate
        dx = Lx/dble(Nx)
        dy = Ly/dble(Ny)
        dz = Lz/dble(Nz)
     do ix=0,Nx
        x(ix) = dx*dble(ix)
     end do
     do iy=0,Ny
        y(iy) = dy*dble(iy)
     end do
     do iz=0,Nz
        z(iz) = dz*dble(iz)
     end do
     do iy=0,Ny; do ix=0,Nx
        rxy(ix,iy) = dsqrt( (x(ix)-Lx/2.d0)**2.d0 + (y(iy)-Ly/2.d0)**2.d0 )
     end do; end do

     !wave number coordinate
        dkx = 2.d0*pi/Lx
        dky = 2.d0*pi/Ly
        dkz = 2.d0*pi/Lz
        dkr = dkx
     do ix=0,Nxh
        kx(ix) = dkx*dble(ix)
     end do
     do ix=Nxh+1,Nx
        kx(ix) = dkx*( dble(ix) - dble(Nx) )
     end do

     do iy=0,Nyh
        ky(iy) = dky*dble(iy)
     end do
     do iy=Nyh+1,Ny
        ky(iy) = dky*( dble(iy) - dble(Ny) )
     end do

     do iz=0,Nzh
        kz(iz) = dkz*dble(iz)
     end do
     do iz=Nzh+1,Nz
        kz(iz) = dkz*( dble(iz) - dble(Nz) )
     end do

     do ix=0,Nxh
        kr(ix) =  dkr*dble(ix)
     end do
     do iz=0,Nz; do iy=0,Ny; do ix=0,Nx
        kxyz(ix,iy,iz)  = dsqrt(kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0)
        kxyz2(ix,iy,iz) = kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0
     end do; end do; end do
  end subroutine coordinate_set

end module setup
!------------------------------------------------------------------------------------------------------------------


!------------------------------------------------------------------------------------------------------------------
module FFT
  use setup
  use mkl_dfti
  implicit none
  TYPE(dfti_descriptor), pointer, save :: handle
  integer :: stat

  contains

  subroutine FFT_init
     stat = dfticreatedescriptor(handle,dfti_double,dfti_complex,3,(/Nx,Ny,Nz/))
     stat = dfticommitdescriptor(handle)
     return
  end subroutine FFT_init

  subroutine forwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nxyz)
     func(:) = func(:)/dble(Nxyz)
     stat = dfticomputeforward(handle,func)
     return
  end subroutine forwardFFT

  subroutine backwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nxyz)
     stat = dfticomputebackward(handle,func)
     return
  end subroutine backwardFFT

end module FFT
!------------------------------------------------------------------------------------------------------------------


!------------------------------------------------------------------------------------------------------------------
module physical_quantity
  use setup
  use mkl_dfti
  use FFT

  contains

  subroutine particle_number
        Nt = 0.d0
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        Nt = Nt + cdabs(psir1(ix,iy,iz))**2.d0
     end do; end do; end do
        Nt = Nt*dx*dy*dz
  end subroutine particle_number

  subroutine spectrum
     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        psik1(ix,iy,iz) = psir1(ix,iy,iz)
     end do; end do; end do

     call forwardFFT(psik1)
     do l=0,Nr
           dummy1 = 0.d0
           dummy2 = 0.d0
        do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
           if ( kr(l)-dkr*0.5d0 <= kxyz(ix,iy,iz) .and. kxyz(ix,iy,iz) < kr(l)+dkr*0.5d0 ) then
              dummy1 = dummy1 + cdabs(psik1(ix,iy,iz))**2.d0
              dummy2 = dummy2 + 1
           end if
        end do; end do; end do
           Nkr(l)   = dummy1*Lx*Ly*Lz/dummy2
     end do
  end subroutine spectrum

end module physical_quantity
!------------------------------------------------------------------------------------------------------------------
