include 'sub_spectrum.f90'
program kazuya
!$use omp_lib
  use setup
  use mkl_dfti
  use FFT
  use physical_quantity
  implicit none

  call coordinate_set
  call FFT_init

  open(1,file="out_wavefunction.tat",form="unformatted")
  open(2,file="data/particle_number.txt")

  do m = 0, Nstep
     read(1) (((psir1(ix,iy,iz), iz=0,Nz-1),iy=0,Ny-1),ix=0,Nx-1)
     time = int((m)*dt*10000)

     call particle_number
     call spectrum

     write(2,'(5(E23.15))') dble(m)*dt*10000, Nt

     write(filename,"(a,i5.5,a)") "data/momentum_distiribution",time,".txt"
     open(4,file=filename)
     do l=1,Nr-1
        write(4,'(7(E23.15))') kr(l)/eta, Nkr(l)*( eta*eta*eta/( dkr*dkr*dkr ) )
     end do
     close(4)
  end do

end
