!BdG eqyuation
include 'sub_bdg.f90'

program kazuya
!$use omp_lib
  use setup
  use mkl_dfti
  use FFT
  use bdg
  implicit none

  call FFT_init
  call coordinate_set
  call initial_state
  call chemical_potential
  call construnction_of_bdg_matrix
  call diagonalization
  call cpu_end
end program kazuya
