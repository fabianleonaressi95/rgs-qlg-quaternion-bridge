include 'mkl_dfti.f90'

!--------------------------------------------------------------------------------------------------------------------
module setup
   implicit none

!parameters and arrays for real and wave-number coordinate
integer :: ix, iy, iz, j1, j2, j3
integer, parameter :: Nx = 128, Ny = 128, Nz = 128, Nxh = Nx/2, Nyh = Ny/2, Nzh = Nz/2, Nxyz = Nx*Ny*Nz, Nr = Nx/2
double precision :: dx, dy, dz, dr, dkx, dky, dkz, dkr, x(0:Nx), y(0:Ny), z(0:Nz), rxy(0:Nx,0:Ny), &
                    kx(0:Nx), ky(0:Ny), kz(0:Nz), kxyz(0:Nx,0:Ny,0:Nz), kxyz2(0:Nx,0:Ny,0:Nz), kr(0:Nr)
double precision, parameter :: Lx = 40.d0, Ly = 40.d0, Lz = 40.d0, eta = 1.16411621952d0, tau = 0.00370862441837d0, &
                               Rpxy = 16.d0/eta, Lpz = 27.d0/eta, Vh = 3.2d0*10.d0**( 9.d0/9.d0*dlog10(64.d0/3.2d0) )

!parameters
double precision, parameter :: a = 0.114705260445d0, pi = 4.d0*datan(1.d0), Ntp = 1.2d0*(10.d0**5.d0)
complex(kind(0d0)), parameter :: uso = (0.d0, 1.d0)

!parameters and arrays of time
integer, parameter :: parameter_t = 1
integer :: jikoku(8)
double precision :: time, time_start,time_end, stime, etime
character(len=40) filename

!arrays for wavefunction
complex(kind(0d0)),dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: psir_3d
complex(kind(0d0)),dimension(0:Nz-1) :: psir_1d, psik_1d

!arrays for wavefunction
complex(kind(0d0)),dimension(0:2*Nz-1,0:2*Nz-1) :: Mat

!parameters and arrays for physical quantities
double precision :: Nt, mu, Et, Ek, Ep, Ed, Norm
double precision,dimension(0:Nx-1,0:Ny-1,0:Nz-1) :: n, pot, vx, vy,vz, phase

!for zgeev
integer :: info
integer, parameter :: Nm = 2*Nz,lwork = 10*Nm
complex(kind(0d0)) :: work(0:lwork), rwork(0:10*Nm)

!eigenvector and eigenvalue
complex(kind(0d0)) :: ur(0:Nm-1,0:Nm-1), ul(0:Nm-1,0:Nm-1), uwork(0:Nm-1), Eval(0:Nm-1), Ework, Espe(0:Nm)
double precision :: dummy1

  contains

  subroutine coordinate_set
  !real corrdinate
        dx = Lx/dble(Nx)
        dy = Ly/dble(Ny)
        dz = Lz/dble(Nz)
     do ix=0,Nx
        x(ix) = dx*dble(ix)
     end do
     do iy=0,Ny
        y(iy) = dy*dble(iy)
     end do
     do iz=0,Nz
        z(iz) = dz*dble(iz)
     end do
     do iy=0,Ny; do ix=0,Nx
        rxy(ix,iy)  = dsqrt( (x(ix)-Lx/2.d0)**2.d0 + (y(iy)-Ly/2.d0)**2.d0 )
     end do; end do

  !wave number coordinate
        dkx = 2.d0*pi/Lx
        dky = 2.d0*pi/Ly
        dkz = 2.d0*pi/Lz
        dkr = dkx
     do ix=0,Nxh
        kx(ix) = dkx*dble(ix)
     end do
     do ix=Nxh+1,Nx
        kx(ix) = dkx*( dble(ix) - dble(Nx) )
     end do

     do iy=0,Nyh
        ky(iy) = dky*dble(iy)
     end do
     do iy=Nyh+1,Ny
        ky(iy) = dky*( dble(iy) - dble(Ny) )
     end do

     do iz=0,Nzh
        kz(iz) = dkz*dble(iz)
     end do
     do iz=Nzh+1,Nz
        kz(iz) = dkz*( dble(iz) - dble(Nz) )
     end do

     do ix=0,Nxh
        kr(ix) =  dkr*dble(ix)
     end do

     do iz=0,Nz; do iy=0,Ny; do ix=0,Nx
        kxyz(ix,iy,iz)  = dsqrt(kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0)
        kxyz2(ix,iy,iz) = kx(ix)**2.d0 + ky(iy)**2.d0 + kz(iz)**2.d0
     end do; end do; end do

     do iz=0,Nz-1; do iy=0,Ny-1; do ix=0,Nx-1
        if(rxy(ix,iy)>Rpxy .or. dabs(z(iz)-Lz/2.d0)>Lpz/2.d0 ) then
           pot(ix,iy,iz) = Vh
        else
           pot(ix,iy,iz) = 0.d0
        end if
     end do; end do; end do
  end subroutine coordinate_set

  subroutine cpu_start
	   call cpu_time (time_start)
	   call date_and_time(values=jikoku)
	   open(parameter_t,file='cpu_time.txt',form='formatted')
  	 write(parameter_t,*)'start'
	   write(parameter_t,*)jikoku(2),'mon',jikoku(3),'th',jikoku(5),'h',jikoku(6),'min',jikoku(7),'sec'
     stime = dble(jikoku(6))*60 + dble(jikoku(7)) + dble(jikoku(8))/1000
  end subroutine cpu_start

  subroutine cpu_end
     call date_and_time(values=jikoku)
     write(parameter_t,*)'stop'
     write(parameter_t,*)jikoku(2),'mon',jikoku(3),'th',jikoku(5),'h',jikoku(6),'min',jikoku(7),'sec'
     call cpu_time (time_end)
     write(parameter_t,*)'cputime'
     write(parameter_t,*)time_end-time_start
     close(parameter_t)
     etime = dble(jikoku(6))*60 + dble(jikoku(7)) + dble(jikoku(8))/1000
  end subroutine cpu_end

end module setup
!--------------------------------------------------------------------------------------------------------------------


!--------------------------------------------------------------------------------------------------------------------
module FFT
  use setup
  use mkl_dfti
  implicit none
  TYPE(dfti_descriptor), pointer, save :: handle
  integer :: stat

  contains

  subroutine FFT_init
     stat = dfticreatedescriptor(handle,dfti_double,dfti_complex,1,Nz)
     stat = dfticommitdescriptor(handle)
     return
  end subroutine FFT_init

  subroutine forwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nz)
     func(:) = func(:)/dble(Nz)
     stat = dfticomputeforward(handle,func)
     return
  end subroutine forwardFFT

  subroutine backwardFFT(func)
     complex(kind(0d0)), intent(inout) :: func(Nz)
     stat = dfticomputebackward(handle,func)
     return
  end subroutine backwardFFT

end module FFT
!--------------------------------------------------------------------------------------------------------------------


!--------------------------------------------------------------------------------------------------------------------
module bdg
  use setup
  use mkl_dfti
  use FFT
  implicit none

  contains

  subroutine initial_state
     open(1,file="wavefunction.tat",form="unformatted")
     read(1) (((psir_3d(ix,iy,iz), iz=0,Nz-1),iy=0,Ny-1),ix=0,Nx-1)
     close(1)

     do iz=0,Nz-1
        psir_1d(iz) = psir_3d(Nxh,Nyh,iz)
     end do
  end subroutine initial_state

  subroutine chemical_potential
     psik_1d(:) = psir_1d(:)
     call forwardFFT(psik_1d)

        Nt = 0.d0
     do iz=0,Nz-1
        Nt = Nt + cdabs(psir_1d(iz))**2.d0
     end do
        Nt = Nt*dz

        Ek = 0.d0
     do iz=0,Nz-1
        Ek = Ek + kz(iz)*kz(iz)*cdabs(psik_1d(iz))**2.d0
     end do
        Ek = Ek*Lz

        Ep = 0.d0
        Ed = 0.d0
     do iz=0,Nz-1
        Ep = Ep + pot(Nxh,Nyh,iz)*cdabs(psir_1d(iz))**2
        Ed = Ed + cdabs(psir_1d(iz))**4
     end do
        Ep = Ep*dz
        Ed = 0.5d0*a*Ed*dz
        mu = (Ek + Ep + 2.d0*Ed)/Nt
  end subroutine chemical_potential

  subroutine construnction_of_bdg_matrix
     Mat(:,:) = 0.d0
     !diagonal part
     do iz=0,Nz-1
        Mat(iz,iz)       =    2.d0/(dz**2) + pot(Nxh,Nyh,iz) + 2.d0*a*cdabs(psir_1d(iz))**2 - mu
        Mat(iz,iz+Nz)    =    a*psir_1d(iz)**2
        Mat(iz+Nz,iz+Nz) =  - 2.d0/(dz**2) - pot(Nxh,Nyh,iz) - 2.d0*a*cdabs(psir_1d(iz))**2 + mu
        Mat(iz+Nz,iz)    =  - a*dconjg(psir_1d(iz))**2
     end do

     !non-diagonal(upper)
     do iz=0,Nz-2
        Mat(iz,iz+1)       =  - 1.d0/(dz**2)
        Mat(iz+Nz,iz+Nz+1) =    1.d0/(dz**2)
     end do

     !non-diagonal(lower)
     do iz=1,Nz-1
        Mat(iz,iz-1)       =  - 1.d0/(dz**2)
        Mat(iz+Nz,iz+Nz-1) =    1.d0/(dz**2)
     end do

     !periodic boundary condition
     Mat(0,Nz-1)    = - 1.d0/(dz**2)
     Mat(Nz-1,0)    = - 1.d0/(dz**2)
     Mat(Nz,2*Nz-1) =   1.d0/(dz**2)
     Mat(2*Nz-1,Nz) =   1.d0/(dz**2)
  end subroutine construnction_of_bdg_matrix

  subroutine diagonalization
     ur(:,:)  = 0.d0
     ul(:,:)  = 0.d0
     Eval(:)  = 0.d0
     work(:)  = 0.d0
     rwork(:) = 0.d0
     call zgeev('N','V',Nm,Mat,Nm,Eval,ul,Nm,ur,Nm,work,lwork,rwork,info)

     !sorting of eigenvalues
     do j1 = 0, Nm-1
        do j2 = j1+1, Nm-1
           If(dreal(Eval(j1)) > dreal(Eval(j2))) then
              Ework    = Eval(j2)
              Eval(j2) = Eval(j1)
              Eval(j1) = Ework

            do iz=0,2*Nz-1
               uwork(iz)  = ur(iz,j2)
            end do
            do iz=0,2*Nz-1
               ur(iz,j2)  = ur(iz,j1)
            end do
            do iz=0,2*Nz-1
               ur(iz,j1)  = uwork(iz)
            end do
           end if
        end do
     end do

        dummy1 = 0.d0
     do j1=0, Nm-1
           Norm = 0.d0
        do iz=0, Nz-1
           Norm = Norm + cdabs(ur(j1,iz))**2.d0 - cdabs(ur(j1,iz+Nz))**2.d0
        end do

        if(Norm>0.d0) then
           Espe(int(dummy1)) = Eval(j1)
           dummy1 = dummy1 + 1.d0
        end if
     end do

     !output of eigenvalue
     open(11,file="energy.txt")
     do iz = 0, 2*Nz-1
        write(11,*) dble(iz-Nz), dreal(Eval(iz))
     end do
     close(11)
  end subroutine diagonalization

end module bdg
!--------------------------------------------------------------------------------------------------------------------
