A13 — RGS-PSU / QLG / TWINE-ANTITWIN

CONTENUTO
- A13_RGS_PSU_QLG_TWINE_ANTITWIN.py : script principale
- RGS_PSU_all_matrices.npz : archivio matrici RGS-PSU
- RGS_PSU_fiber_connection_audit/psu_fibre_connection_matrices.npz : connessione SO(3)/SU(2), Q, link Q6
- RGS_PSU_SEA_DERIVATION/sea_operators.npz : coframe vierbein a 4 componenti e tau QLG
- giacosa_twins_antitwins_bridge.npz : tetraedri Twin/AntiTwin e involuzione esatta
- A13_RGS_PSU_QLG_OUTPUT/ : risultati già calcolati in questa sessione

ESECUZIONE KAGGLE
1. Caricare questo ZIP come Dataset oppure estrarlo nella working directory.
2. Aprire un notebook Kaggle nella cartella in cui si trova lo script.
3. Eseguire:

   !python A13_RGS_PSU_QLG_TWINE_ANTITWIN.py

Dipendenze: Python 3, numpy. Nessun file A13_geometry.npz deve essere creato.

OUTPUT
Lo script crea A13_RGS_PSU_QLG_OUTPUT con:
- A13_report.json
- A13_RGS_PSU_QLG_matrices.npz
- A13_multifractal_partition.csv
- A13_tau_spectra.csv

NOTA SCIENTIFICA
La base Q (192x188) è recuperata dall'archivio QLG. Il suo complemento normale 4D viene calcolato senza inventare vincoli. Il coframe è verificato direttamente dalla definizione archiviata e dai link. Il report distingue ciò che è verificato da ciò che richiede ancora la matrice Jacobiana originale con le quattro righe etichettate (x,y,z,radiale). La mappa Giacosa tetraedro -> 64 stati Q6 non viene inventata. La cascata è un audit numerico su grafo finito, non una prova di multifrattalità continua.
