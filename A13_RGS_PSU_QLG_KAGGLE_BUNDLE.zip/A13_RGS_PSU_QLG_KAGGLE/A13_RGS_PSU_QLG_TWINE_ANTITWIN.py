#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A13 — RGS–PSU / QLG / Twine–AntiTwin integrated audit.

Runs directly from the bundled, already archived QLG and Giacosa data.
No A13_geometry.npz, guessed constraints, or synthetic 188D Hessian is required.

Required sibling files (included in the release bundle):
  RGS_PSU_all_matrices.npz
  RGS_PSU_fiber_connection_audit/psu_fibre_connection_matrices.npz
  RGS_PSU_SEA_DERIVATION/sea_operators.npz
  giacosa_twins_antitwins_bridge.npz

The archived Q (192x188) is authoritative for the 188D tangent space.
Its four-dimensional orthogonal complement is recovered from Q; this script
never fabricates three translation rows plus one radial row. The QLG radial
coframe component and tau field are audited as archived fields. The precise
identification of each of the four archived normal directions with the
3+1 constraint labels is reported as requiring the original labelled
constraint Jacobian if it is not contained in the archive.

The three Giacosa mixed-correlation coordinates are audited using the exact
archived Bell-tetrahedron bridge. The multifractal scan uses the archived QLG
edge coframe (three spatial components) under Cartesian rotations, separately
on the two conjugate SU(2) sheets. This is a finite-graph diagnostic, not a
claim that multifractality or a continuum law has been proved.
"""
from pathlib import Path
import json, csv, hashlib, zipfile, sys
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'A13_RGS_PSU_QLG_OUTPUT'
OUT.mkdir(exist_ok=True)
TOL = 1e-9

# ----------------------- locate archived inputs -----------------------
def first_existing(paths, label):
    for p in paths:
        if p.exists(): return p
    raise FileNotFoundError(f"Missing bundled QLG source: {label}; checked: " + ', '.join(map(str, paths)))

all_matrices_path = first_existing([
    ROOT/'RGS_PSU_all_matrices.npz',
    ROOT/'sources'/'RGS_PSU_all_matrices.npz'], 'RGS_PSU_all_matrices.npz')
fibre_path = first_existing([
    ROOT/'RGS_PSU_fiber_connection_audit'/'psu_fibre_connection_matrices.npz',
    ROOT/'RGS_PSU_FIBRE_CONNECTION_COMPLETE'/'RGS_PSU_fiber_connection_audit'/'psu_fibre_connection_matrices.npz'],
    'psu_fibre_connection_matrices.npz')
sea_path = first_existing([
    ROOT/'RGS_PSU_SEA_DERIVATION'/'sea_operators.npz'], 'sea_operators.npz')
giacosa_path = first_existing([
    ROOT/'giacosa_twins_antitwins_bridge.npz'], 'giacosa_twins_antitwins_bridge.npz')

A = np.load(all_matrices_path, allow_pickle=True)
F = np.load(fibre_path, allow_pickle=True)
S = np.load(sea_path, allow_pickle=True)
G = np.load(giacosa_path, allow_pickle=True)

# ----------------------- QLG source data -----------------------
X = np.asarray(A['X_Oh_reconstructed'], float)
Q = np.asarray(F['Q'], float)
K0 = np.asarray(F['K0'], float)
edges = np.asarray(F['edges'], int)
R_SO3 = np.asarray(F['R_SO3'], float)
U_SU2 = np.asarray(F['U_SU2'], complex)
edge_coframe = np.asarray(S['edge_coframe'], float)
tau = np.asarray(S['tau'], float)
Q_sea = np.asarray(S['Q'], float)

assert X.shape == (64,3), X.shape
assert Q.shape == (192,188), Q.shape
assert K0.shape == (188,188), K0.shape
assert edges.shape == (192,3), edges.shape
assert R_SO3.shape == (192,3,3), R_SO3.shape
assert U_SU2.shape == (192,2,2), U_SU2.shape
assert edge_coframe.shape == (192,4), edge_coframe.shape
assert tau.shape == (64,), tau.shape

# Check the SEA and fibre archives describe the same tangent frame and links.
q_sea_res = float(np.linalg.norm(Q-Q_sea, 'fro'))
edge_match = bool(np.array_equal(edges, np.asarray(S['edges'], int)))

# ----------------------- 3+1 tangent/normal audit -----------------------
# Q is the actual archived tangent basis. Recover its normal complement.
q_orth = float(np.linalg.norm(Q.T@Q-np.eye(188), 'fro'))
normal = np.linalg.svd(Q.T, full_matrices=True)[2][188:].T
# More stable explicit QR complement; SVD row basis has 4 columns.
normal = np.linalg.svd(Q.T, full_matrices=True)[2][188:].T
assert normal.shape == (192,4), normal.shape
normal_orth = float(np.linalg.norm(normal.T@normal-np.eye(4), 'fro'))
normal_tangent = float(np.linalg.norm(normal.T@Q, 'fro'))
P_T = Q@Q.T
P_N = normal@normal.T
projector_complement = float(np.linalg.norm(P_T+P_N-np.eye(192), 'fro'))
projector_idempotence = float(np.linalg.norm(P_T@P_T-P_T, 'fro'))

# ----------------------- QLG vierbein / coframe audit -----------------------
# edge rows are (g,h,cartesian_bit); coframe = (X_h-X_g, |X_h|-|X_g|), normalized.
raw_coframe = np.empty((len(edges),4), float)
radii = np.linalg.norm(X, axis=1)
for k,(g,h,axis) in enumerate(edges):
    raw_coframe[k,:3] = X[h]-X[g]
    raw_coframe[k,3] = radii[h]-radii[g]
raw_norm = np.linalg.norm(raw_coframe, axis=1)
coframe_expected = raw_coframe / np.maximum(raw_norm[:,None], 1e-15)
coframe_residual = float(np.linalg.norm(coframe_expected-edge_coframe, 'fro'))
coframe_norm_residual = float(np.max(np.abs(np.linalg.norm(edge_coframe,axis=1)-1)))

# SU(2) connection audits, both sheets are U and complex conjugate U*.
su2_unitarity = float(max(np.linalg.norm(u.conj().T@u-np.eye(2)) for u in U_SU2))
so3_orthogonality = float(max(np.linalg.norm(r.T@r-np.eye(3)) for r in R_SO3))
so3_det_residual = float(max(abs(np.linalg.det(r)-1) for r in R_SO3))

# ----------------------- exact Giacosa twin/anti-twin tetrahedra -----------------------
Vt = np.asarray(G['V_twin'], float)
Va = np.asarray(G['V_antitwin'], float)
answer = np.asarray(G['answer_triples'], int)
corr = np.asarray(G['correlation_triples'], int)
exchange = np.asarray(G['exchange'], complex)
obs = np.asarray(G['correlation_observables'], complex)
P_even = np.asarray(G['P_exchange_even'], complex)
P_odd = np.asarray(G['P_exchange_odd'], complex)
I8 = np.eye(8)
exchange_square = float(np.linalg.norm(exchange@exchange-I8))
exchange_hermitian = float(np.linalg.norm(exchange-exchange.conj().T))
correlation_odd = float(max(np.linalg.norm(exchange@obs[k]@exchange+obs[k]) for k in range(3)))
projector_res = float(max(
    np.linalg.norm(P_even@P_even-P_even),
    np.linalg.norm(P_odd@P_odd-P_odd),
    np.linalg.norm(P_even@P_odd),
    np.linalg.norm(P_even+P_odd-I8)))
tetra_inversion = float(np.linalg.norm(Va+Vt))

# ----------------------- rotation/quadrant resolved coframe cascade -----------------------
def Rz(theta):
    c,s=np.cos(theta),np.sin(theta)
    return np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]])

def quadrant(x,y):
    # q=0: ++, q=1: -+, q=2: +-, q=3: -- (x sign is low bit).
    return (x<0).astype(int) + 2*(y<0).astype(int)

def box_partition(points, mass, eps):
    lo=points.min(axis=0); span=np.maximum(points.max(axis=0)-lo, 1e-14)
    idx=np.floor((points-lo)/(span*eps+1e-14)).astype(np.int64)
    _, inv=np.unique(idx, axis=0, return_inverse=True)
    m=np.bincount(inv, weights=mass)
    return m[m>0]

scales = 2.0**(-np.arange(0,7))
orders = np.array([-2.,-1.,-0.5,0.,0.5,1.,2.,3.])
angles = np.linspace(0,2*np.pi,73)
# Edge midpoint positions in the actual archived embedding.
mid = np.array([(X[g]+X[h])/2 for g,h,_ in edges])
# QLG coframe triplet: the three Cartesian components, not a fitted eigenvector.
spatial = edge_coframe[:,:3]
radial_component = edge_coframe[:,3]

cascade_rows=[]
for theta in angles:
    R=Rz(theta)
    mid_rot=mid@R.T
    spatial_rot=spatial@R.T
    qlab=quadrant(mid_rot[:,0],mid_rot[:,1])
    zsign=np.where(mid_rot[:,2]>=0,1,-1)
    # Separate the two conjugate biverse sheets. Geometry is shared; connection is conjugated.
    for sheet_sign in (+1,-1):
        for q in range(4):
            for zs in (-1,+1):
                mask=(qlab==q)&(zsign==zs)
                if mask.sum()<3: continue
                pts=mid_rot[mask]
                for channel in range(3):
                    mass=np.abs(spatial_rot[mask,channel])+1e-15
                    mass=mass/mass.sum()
                    for eps in scales:
                        bm=box_partition(pts,mass,eps)
                        for p in orders:
                            # Negative p is safe because zero-mass boxes are excluded.
                            zp=float(len(bm)) if p==0 else float(np.sum(bm**p))
                            cascade_rows.append({
                                'theta':float(theta),'sheet':sheet_sign,
                                'quadrant_xy':q,'z_sign':int(zs),
                                'channel':'xyz'[channel], 'p':float(p),
                                'epsilon':float(eps),'Z':zp,
                                'boxes':int(len(bm)),'links':int(mask.sum()),
                                'radial_coframe_mean':float(np.mean(radial_component[mask]))
                            })

# Fit tau(p) per angle/sheet/quadrant/z/channel/p; require >=3 distinct scales.
groups={}
for row in cascade_rows:
    key=(row['theta'],row['sheet'],row['quadrant_xy'],row['z_sign'],row['channel'],row['p'])
    groups.setdefault(key,[]).append(row)
tau_rows=[]
for key, vals in groups.items():
    if len(vals)<3: continue
    eps=np.array([v['epsilon'] for v in vals]); Zp=np.array([v['Z'] for v in vals])
    slope,intercept=np.polyfit(np.log(eps),np.log(Zp),1)
    fit=slope*np.log(eps)+intercept
    tau_rows.append({
        'theta':key[0],'sheet':key[1],'quadrant_xy':key[2],
        'z_sign':key[3],'channel':key[4],'p':key[5],
        'tau':float(slope),'fit_rms':float(np.sqrt(np.mean((np.log(Zp)-fit)**2))),
        'n_scales':int(len(vals))})

# ----------------------- checks and report -----------------------
checks={
 'X_64x3':X.shape==(64,3),
 'Q_192x188':Q.shape==(192,188),
 'Q_orthonormal':q_orth<1e-8,
 'normal_complement_192x4':normal.shape==(192,4),
 'normal_orthonormal':normal_orth<1e-8,
 'normal_tangent_orthogonal':normal_tangent<1e-8,
 'projector_complement':projector_complement<1e-8,
 'projector_idempotent':projector_idempotence<1e-8,
 'sea_Q_matches_fibre_Q':q_sea_res<1e-8,
 'edge_lists_match':edge_match,
 'QLG_coframe_matches_X_and_edges':coframe_residual<1e-8,
 'coframe_unit_norm':coframe_norm_residual<1e-8,
 'SO3_links_orthogonal':so3_orthogonality<1e-8,
 'SO3_links_det_one':so3_det_residual<1e-8,
 'SU2_links_unitary':su2_unitarity<1e-8,
 'Giacosa_exchange_involution':exchange_square<1e-10,
 'Giacosa_exchange_hermitian':exchange_hermitian<1e-10,
 'Giacosa_correlators_odd':correlation_odd<1e-10,
 'Giacosa_even_odd_projectors':projector_res<1e-10,
 'Twin_AntiTwin_tetrahedron_inversion':tetra_inversion<1e-12,
 'multifractal_rows_generated':len(cascade_rows)>0,
 'tau_fits_generated':len(tau_rows)>0
}

report={
 'title':'A13 RGS-PSU QLG Twine-AntiTwin integrated audit',
 'source_files':{
  'all_matrices':str(all_matrices_path.relative_to(ROOT)),
  'fibre_connection':str(fibre_path.relative_to(ROOT)),
  'sea_operators':str(sea_path.relative_to(ROOT)),
  'giacosa_bridge':str(giacosa_path.relative_to(ROOT))},
 'dimensions':{'vertices':64,'links':len(edges),'tangent':188,'normal':4,'coframe':list(edge_coframe.shape)},
 'constraint_3plus1':{
  'archived_tangent_basis':'Q from QLG fibre-connection archive',
  'normal_basis_recovered_from_Q':normal.tolist(),
  'normal_dimension':4,
  'tangent_dimension':188,
  'normal_basis_labels':'not inferred from an arbitrary basis; labelled 3 translation + 1 radial decomposition requires original labelled Jacobian',
  'Q_orthogonality_residual':q_orth,
  'normal_orthogonality_residual':normal_orth,
  'normal_tangent_residual':normal_tangent,
  'projector_complement_residual':projector_complement,
  'projector_idempotence_residual':projector_idempotence},
 'vierbein':{
  'definition':'e_gh = normalize((X_h-X_g, ||X_h||-||X_g||))',
  'coframe_residual_against_archive':coframe_residual,
  'unit_norm_residual':coframe_norm_residual,
  'radial_component_rms':float(np.sqrt(np.mean(radial_component**2))),
  'radial_component_min':float(radial_component.min()),
  'radial_component_max':float(radial_component.max()),
  'tau_shape':list(tau.shape),'tau_min':float(tau.min()),'tau_max':float(tau.max())},
 'connection':{
  'SO3_orthogonality_max':so3_orthogonality,
  'SO3_det_residual_max':so3_det_residual,
  'SU2_unitarity_max':su2_unitarity,
  'sheet_0':'U_SU2','sheet_1':'complex_conjugate(U_SU2)',
  'note':'the conjugate sheet is the archived biverse connection; it is not inferred from the sign of an edge radial increment'},
 'twine_antitwin':{
  'twin_vertices':Vt.tolist(),'anti_twin_vertices':Va.tolist(),
  'answer_triples':answer.tolist(),'correlation_triples':corr.tolist(),
  'exchange_involution_residual':exchange_square,
  'exchange_hermiticity_residual':exchange_hermitian,
  'correlator_exchange_odd_residual':correlation_odd,
  'even_odd_projector_residual':projector_res,
  'tetrahedron_inversion_residual':tetra_inversion,
  'mapping_to_Q6_64_states':'not imposed; no equivariant vertex-to-Q6 map is assumed'},
 'multifractal_scan':{
  'measure':'absolute x/y/z components of archived QLG link coframe',
  'rotation':'Rz(theta), theta in [0,2pi], 73 samples',
  'sectors':'four xy quadrants, z sign, conjugate biverse sheet',
  'orders':orders.tolist(),'scales':scales.tolist(),
  'partition_rows':len(cascade_rows),'tau_fits':len(tau_rows),
  'interpretation':'finite-graph scale-fit diagnostics; not proof of multifractality or continuum scaling'},
 'checks':checks,'checks_passed':int(sum(checks.values())),'checks_total':len(checks),
 'all_checks_pass':bool(all(checks.values())),
 'limitations':[
  'the 3+1 labels of the four normal directions are not guessed from Q; labelled original constraint Jacobian is needed to assign those labels exactly',
  'the Bell-tetrahedron correlation labels are not silently identified with the 64 Q6 states',
  'the multifractal scan uses the archived QLG vierbein triplet and rotation sectors; a stable scaling window and refinement sequence are still needed for a multifractal/continuum claim',
  'SU(2) geometric fibre connection is not SU(3) colour gauge field',
  'no Mosco convergence or physical prediction is claimed']
}

# Save arrays and reports.
np.savez_compressed(OUT/'A13_RGS_PSU_QLG_matrices.npz',X=X,Q=Q,normal_basis=normal,
    P_T=P_T,P_N=P_N,edges=edges,edge_coframe=edge_coframe,raw_coframe=raw_coframe,
    R_SO3=R_SO3,U_SU2=U_SU2,tau=tau,correlation_twin=Vt,
    correlation_antitwin=Va,answer_triples=answer,correlation_triples=corr,
    exchange=exchange,correlation_observables=obs)
(OUT/'A13_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))

def write_csv(path, rows):
    if not rows: return
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
write_csv(OUT/'A13_multifractal_partition.csv',cascade_rows)
write_csv(OUT/'A13_tau_spectra.csv',tau_rows)

print('='*72)
print('A13 RGS-PSU / QLG / TWINE-ANTITWIN')
print('='*72)
print('Source archive:', all_matrices_path.name, fibre_path.name, sea_path.name, giacosa_path.name)
print('Checks:',sum(checks.values()),'/',len(checks),'ALL:',all(checks.values()))
print('Q shape:',Q.shape,'normal complement:',normal.shape)
print('Q orthogonality residual:',q_orth)
print('QLG coframe reconstruction residual:',coframe_residual)
print('SU2 unitarity residual:',su2_unitarity)
print('Giacosa exchange odd residual:',correlation_odd)
print('Multifractal rows:',len(cascade_rows),'tau fits:',len(tau_rows))
print('Output folder:',OUT)
