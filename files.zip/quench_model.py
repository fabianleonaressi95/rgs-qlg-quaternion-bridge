"""
Modello di quench per un film sottile Al65Cu20Fe15 depositato su substrato
(sorgente a scarica pulsata multistadio).

Obiettivo: stimare la velocita' di raffreddamento (K/s) raggiungibile in
funzione dello spessore del film e della conduttanza termica di contatto
film/substrato, e confrontarla con le soglie di letteratura per la
formazione della fase icosaedrica.

Riferimenti di letteratura usati come benchmark (vedi note nel report):
  - Probabilita' di formazione della fase quasicristallina aumenta
    significativamente per velocita' di raffreddamento > 100 K/s
    (Dependence of phase selection..., ScienceDirect).
  - Il melt-spinning classico raggiunge 5-7 x 10^4 degC/s ma NON produce
    nastri a fase singola: fasi concorrenti (theta-Al2Cu, lambda-Al13Fe4)
    permangono anche a queste velocita' (Al-Cu-Fe quasicrystals: Stability
    and microstructure, ScienceDirect).
  - La fase icosaedrica Al65Cu20Fe15 e' STABILE (non solo metastabile) e
    si forma per reazione peritettica: questo significa che una tempra
    troppo rapida puo' SOPPRIMERE la reazione peritettica invece di
    favorirla. Il target quindi non e' "il piu' veloce possibile" ma una
    finestra di velocita' -- ipotesi da verificare sperimentalmente.

Questo script NON dimostra che il processo funzioni: fornisce la stima
analitica di ordine di grandezza richiesta per una proof-of-concept TRL3,
con tutte le assunzioni esplicitate.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------------------------------------------------
# 1. MODELLO A CAPACITA' CONCENTRATA (lumped capacitance)
#    Stima della velocita' di raffreddamento iniziale di un film sottile
#    in contatto con un substrato semi-infinito a temperatura Tsub.
#
#    dT/dt|t=0 = - h_c * (T0 - Tsub) / (rho * cp * delta)
#
#    h_c    = conduttanza termica di contatto film/substrato [W/m^2K]
#    delta  = spessore del film [m]
#    rho,cp = densita' e calore specifico del film (lega Al-Cu-Fe)
# ----------------------------------------------------------------------

# Proprieta' approssimate della lega Al65Cu20Fe15 allo stato liquido/solido
# (stime da dati di leghe Al-Cu-Fe in letteratura; da affinare con misure
# dirette o database CALPHAD nello step 1 del piano di lavoro)
RHO_FILM = 4200.0     # kg/m^3
CP_FILM = 650.0       # J/(kg K)

T0 = 900.0            # degC, temperatura iniziale del film (sovrariscaldato oltre liquidus)
TSUB = 150.0          # degC, temperatura del substrato/target (assunta preriscaldata e controllata)

film_thicknesses_um = np.array([1, 2, 5, 10, 20, 50, 100])   # micrometri
h_contact_values = {
    "Contatto scarso (ossidato, 1e4 W/m2K)": 1e4,
    "Contatto buono (metallico pulito, 1e5 W/m2K)": 1e5,
    "Contatto ottimo (interfaccia curata, 5e5 W/m2K)": 5e5,
}

print("=" * 78)
print("MODELLO 1 - Capacita' concentrata: velocita' di raffreddamento iniziale")
print("=" * 78)
results_lumped = {}
for label, h_c in h_contact_values.items():
    delta_m = film_thicknesses_um * 1e-6
    cooling_rate = h_c * (T0 - TSUB) / (RHO_FILM * CP_FILM * delta_m)  # K/s
    results_lumped[label] = cooling_rate
    print(f"\n{label}")
    for t_um, rate in zip(film_thicknesses_um, cooling_rate):
        print(f"  spessore {t_um:>4.0f} um  ->  {rate:>12,.0f} K/s")

# ----------------------------------------------------------------------
# 2. MODELLO 1D A DIFFERENZE FINITE (piu' realistico)
#    Film sottile + substrato semi-infinito discretizzato, conduzione
#    transiente pura (senza sorgente/pozzo esterni durante il quench).
#    Estrae la velocita' di raffreddamento MEDIA nell'intervallo di
#    solidificazione (liquidus -> solidus, ~150 K di sottoraffreddamento
#    utile) per un caso rappresentativo.
# ----------------------------------------------------------------------

def fd_cooling_curve(delta_film_um, k_film=80.0, k_sub=200.0,
                      rho_sub=8000.0, cp_sub=500.0, n_sub_nodes=200,
                      sub_thickness_mm=2.0, dt=None, t_max=0.01):
    """Conduzione 1D esplicita: film sottile su substrato semi-infinito.
    Ritorna il tempo (s) e la temperatura del nodo centrale del film."""
    delta_film = delta_film_um * 1e-6
    n_film_nodes = 5
    dx_film = delta_film / n_film_nodes
    dx_sub = (sub_thickness_mm * 1e-3) / n_sub_nodes

    alpha_film = k_film / (RHO_FILM * CP_FILM)
    alpha_sub = k_sub / (rho_sub * cp_sub)

    dx_min = min(dx_film, dx_sub)
    alpha_max = max(alpha_film, alpha_sub)
    if dt is None:
        dt = 0.4 * dx_min ** 2 / alpha_max  # stabilita' esplicita (margine)

    n_nodes = n_film_nodes + n_sub_nodes
    T = np.full(n_nodes, TSUB)
    T[:n_film_nodes] = T0

    alpha = np.where(np.arange(n_nodes) < n_film_nodes, alpha_film, alpha_sub)
    dx = np.where(np.arange(n_nodes) < n_film_nodes, dx_film, dx_sub)

    steps = int(t_max / dt)
    times = np.zeros(steps)
    T_center_film = np.zeros(steps)
    node_mid = n_film_nodes // 2

    for step in range(steps):
        T_new = T.copy()
        for i in range(1, n_nodes - 1):
            dx_i = dx[i]
            T_new[i] = T[i] + alpha[i] * dt / dx_i**2 * (T[i+1] - 2*T[i] + T[i-1])
        T_new[-1] = TSUB  # substrato profondo a temperatura fissa
        T_new[0] = T_new[1]  # superficie libera adiabatica
        T = T_new
        times[step] = step * dt
        T_center_film[step] = T[node_mid]

    return times, T_center_film

print("\n" + "=" * 78)
print("MODELLO 2 - Differenze finite 1D: curva di raffreddamento nel tempo")
print("=" * 78)

fd_cases = [5, 20, 50]  # micrometri
plt.figure(figsize=(7.5, 5))
for delta_um in fd_cases:
    t, Tc = fd_cooling_curve(delta_um)
    # velocita' media nella finestra di solidificazione utile (T0 -> T0-150K)
    T_start, T_end = T0, T0 - 150.0
    idx_start = np.argmax(Tc <= T_start)
    idx_end = np.argmax(Tc <= T_end) if np.any(Tc <= T_end) else len(Tc) - 1
    if idx_end > idx_start:
        dt_window = t[idx_end] - t[idx_start]
        rate_avg = (T_start - T_end) / dt_window if dt_window > 0 else float("nan")
    else:
        rate_avg = float("nan")
    print(f"Film {delta_um:>3d} um  ->  velocita' media di raffreddamento "
          f"nella finestra di solidificazione: {rate_avg:>12,.0f} K/s")
    plt.plot(t * 1000, Tc, label=f"Film {delta_um} \u00b5m")

plt.axhline(T0 - 150, color="gray", linestyle="--", linewidth=1, label="Fine finestra di solidificazione")
plt.xlabel("Tempo [ms]")
plt.ylabel("Temperatura nodo centrale del film [\u00b0C]")
plt.title("Curve di raffreddamento del film (modello FD 1D)")
plt.legend(fontsize=9)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("/home/claude/quench/cooling_curves.png", dpi=150)
print("\nGrafico salvato: cooling_curves.png")

# ----------------------------------------------------------------------
# 3. CONFRONTO CON LE SOGLIE DI LETTERATURA
# ----------------------------------------------------------------------
plt.figure(figsize=(7.5, 5))
for label, rates in results_lumped.items():
    plt.plot(film_thicknesses_um, rates, marker="o", label=label)
plt.axhline(100, color="green", linestyle="--", linewidth=1.2,
            label="Soglia probabilita' QC (~100 K/s, letteratura)")
plt.axhline(5e4, color="red", linestyle="--", linewidth=1.2,
            label="Benchmark melt-spinning (~5-7\u00d710\u2074 K/s)")
plt.yscale("log")
plt.xlabel("Spessore del film [\u00b5m]")
plt.ylabel("Velocita' di raffreddamento iniziale [K/s] (scala log)")
plt.title("Velocita' di raffreddamento vs spessore del film e qualita' del contatto")
plt.legend(fontsize=8)
plt.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("/home/claude/quench/cooling_vs_thickness.png", dpi=150)
print("Grafico salvato: cooling_vs_thickness.png")

print("\n" + "=" * 78)
print("NOTA IMPORTANTE")
print("=" * 78)
print("""
Le due soglie di letteratura NON vanno lette come 'piu' veloce e' meglio':
- Sopra i ~100 K/s la letteratura riporta una maggiore probabilita' di
  ottenere la fase quasicristallina rispetto a fasi concorrenti.
- Ma anche a ~5-7x10^4 K/s (melt-spinning) NON si ottengono nastri a fase
  singola: restano tracce di fasi concorrenti (theta-Al2Cu, lambda-Al13Fe4).
- La fase icosaedrica Al65Cu20Fe15 e' una fase STABILE che si forma per
  reazione peritettica: una tempra eccessivamente rapida rischia di
  SOPPRIMERE questa reazione invece di favorirla.

Implicazione per il progetto: l'obiettivo di processo non e' massimizzare
la velocita' di raffreddamento, ma CENTRARE una finestra (~10^2-10^4 K/s,
da restringere con dati sperimentali reali) che favorisca la fase
icosaedrica senza sopprimere la reazione peritettica. Questo e' esattamente
il tipo di parametro che l'anello di retroazione IoT (sensori di
temperatura + controllo della temporizzazione della scarica) deve poter
regolare in tempo reale.
""")
