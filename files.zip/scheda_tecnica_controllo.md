# Scheda tecnica — Sistema di controllo a retroazione per la sintesi pulsata di rivestimenti quasicristallini Al-Cu-Fe

**Progetto:** Quasicrystal Materials — piattaforma di sintesi pulsata per rivestimenti spaziali
**Documento:** Specifica funzionale del sottosistema di controllo
**Stato:** TRL 2-3 — proof-of-concept analitica in corso di consolidamento
**Data:** Agosto 2026

---

## 1. Scopo

Descrivere l'architettura e la logica del sottosistema che monitora e regola in tempo reale il processo di fusione e raffreddamento (quench) del film Al65Cu20Fe15 durante la deposizione, mantenendo la velocità di raffreddamento entro la finestra target necessaria a favorire la formazione della fase icosaedrica.

## 2. Perché serve un controllo attivo, non solo un processo a parametri fissi

Il modello analitico di quench sviluppato per questo progetto (vedi `quench_model.py` e i grafici allegati) porta a una conclusione che **corregge un'assunzione iniziale del progetto**: l'obiettivo di processo non è massimizzare la velocità di raffreddamento, ma centrarla in una finestra utile.

- La letteratura riporta che la probabilità di formazione della fase quasicristallina aumenta sopra i **~100 K/s**, ma che anche il melt-spinning classico (**~5–7×10⁴ K/s**) non produce materiale a fase singola: restano fasi concorrenti (θ-Al₂Cu, λ-Al₁₃Fe₄).
- La fase icosaedrica Al65Cu20Fe15 è una fase **stabile** che si forma per **reazione peritettica**: una tempra troppo aggressiva rischia di sopprimere questa reazione invece di favorirla.
- Le nostre stime di ordine di grandezza (modello a capacità concentrata + modello 1D a differenze finite) indicano che, per film di spessore micrometrico in buon contatto termico con il substrato, la velocità di raffreddamento raggiungibile è **facilmente superiore di diversi ordini di grandezza** sia alla soglia dei 100 K/s sia al benchmark del melt-spinning.

**Conclusione tecnica:** il rischio principale del processo non è "raffreddare troppo lentamente", ma raffreddare **troppo velocemente e in modo non controllato**. Questo rende necessario un anello di retroazione attivo capace di *moderare* — non solo misurare — il profilo termico durante la solidificazione.

*(Nota metodologica: le cifre sopra sono stime analitiche di ordine di grandezza da un modello semplificato, non misure di laboratorio. Il modello 1D a differenze finite in particolare usa una discretizzazione grossolana e va trattato come indicativo, non quantitativo — da raffinare con un modello FEM e con dati sperimentali reali prima di ogni decisione di processo.)*

## 3. Architettura del sistema

```
[Bobina a induzione (Cu/Litz wire)] --riscalda--> [Target di lega Al-Cu-Fe]
                                                          |
                                                     fusione/deposizione
                                                          |
                                                          v
                                          [Substrato / componente target]
                                                          |
        +-------------------------------------------------+
        |                                                  |
[Sensori IoT: termocoppia rapida        [Sistema di temporizzazione della
 o pirometro + microcontrollore]         scarica multistadio (Marx-derivata)]
        |                                                  ^
        +---------------- anello di retroazione -----------+
                  (regola il profilo dell'impulso in
                   funzione della T e dT/dt misurate)
```

### 3.1 Componenti

| Componente | Funzione | Note |
|---|---|---|
| Bobina a induzione (rame o Litz wire) | Fusione del target di lega | Materiale a **alta** conducibilità elettrica — non quasicristallino: il QC è il materiale prodotto, non un componente del sistema di controllo |
| Sensore di temperatura rapido | Misura T e dT/dt in tempo reale | Termocoppia a risposta rapida per range medi, pirometro ottico per misure senza contatto ad alta velocità di campionamento |
| Microcontrollore / nodo IoT | Acquisizione, elaborazione, invio del segnale di correzione | Deve campionare a frequenza sufficiente a risolvere transitori dell'ordine dei millisecondi o inferiori, coerentemente con le velocità di raffreddamento stimate |
| Sistema di temporizzazione della scarica multistadio | Attuatore: regola l'energia e il profilo temporale dell'impulso erogato | Collegamento diretto con il modello elettrico SPICE (fase successiva del piano di lavoro) |

### 3.2 Logica di controllo (concettuale)

1. Il sensore misura la temperatura del film/target durante e dopo l'impulso.
2. Il microcontrollore calcola dT/dt in tempo reale.
3. Se dT/dt esce dalla finestra target (da definire sperimentalmente, indicativamente tra ~10² e ~10⁴ K/s sulla base della letteratura, non ancora validata per questo specifico processo), il sistema regola parametri del prossimo impulso (energia, temporizzazione tra stadi) per riportare il quench nella finestra.
4. Il ciclo si ripete per ogni impulso/deposizione successiva.

## 4. Requisiti da validare sperimentalmente

- Tempo di risposta reale dei sensori rispetto alla velocità di raffreddamento effettiva (rischio: se il quench è più veloce della capacità di campionamento, il controllo diventa reattivo solo tra un impulso e il successivo, non durante il singolo impulso).
- Ampiezza reale della finestra di velocità di raffreddamento che favorisce la fase icosaedrica per *questo specifico* processo di deposizione pulsata (la letteratura citata riguarda melt-spinning e casting convenzionale, non deposizione pulsata da plasma — l'estrapolazione è un'ipotesi, non un dato consolidato).
- Conduttanza termica di contatto reale film/substrato (assunta nel modello, da misurare).

## 5. Collegamento con il piano di lavoro verso TRL 3

Questo documento formalizza l'output analitico degli step 2 (modello di quench) e prepara l'input per lo step 3 (modello elettrico SPICE) e lo step 6 (sintesi in report di proof-of-concept) del piano di lavoro concordato. Il passaggio successivo naturale è collegare il profilo di energia calcolato nello step 3 a questo modello di quench per verificare che il sistema di temporizzazione possa effettivamente centrare la finestra target, non solo misurarne lo scostamento.
