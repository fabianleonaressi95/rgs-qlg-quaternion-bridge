The files FigS1A_--nK.txt correspond to a single trace at a specific trap depth U_D/k_B - (left panel, see paper).
The column headers (x/y) correspond to what is plotted in the figure:

x     -  \omega_s/(2\pi) (Hz)

y     -  x_CoM (\mu m)




FigS1B.txt shows the extracted resonance frequency (see paper) versus trap depth - (right panel, see paper).
The column headers (x/y/yerr) correspond to what is plotted in the figure:

x     -  U_D/k_B (nK)
y     -  \omega_res/(2\pi) (Hz)

yerr  -  fitting error on y
 