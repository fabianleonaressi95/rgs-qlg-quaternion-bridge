The files FigS2_#.txt correspond to the simulation curves of (y-axis) atom loss (10^3) versus (x-axis) t_s (s) [see figure]
for the different simulation parameters indicated by # (see also the legend in the figure):



#    -    \delta k_D    -    V_D/\mu

1    -        3.5       -       5

2    -        7.0   	-       5

3    -       10.5	-	5

4    -	     10.5	-	1

5    -	     10.5	-	0.1