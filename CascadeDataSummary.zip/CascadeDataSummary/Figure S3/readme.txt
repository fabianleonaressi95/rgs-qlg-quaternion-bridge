The files FigS3_t_s=#.##(s).txt correspond to individual curves on Fig.S3A (see file name/legend for the corresponding value of t_s).
The column headers (x/y) correspond to what is plotted in Fig.S3A (in the same units)


x     -  k (\mu m ^(-1))

y     -  n(k) (\mu m^3)