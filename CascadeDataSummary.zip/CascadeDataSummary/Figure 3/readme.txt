Fig3_data.txt corresponds to the experimental data.

Fig3_sim.txt corresponds to the simulation data.


The column headers (x/y/yerr) correspond to what is plotted in the figure (see paper):

x     -  U_D/k_B (nK)

y     -  \Pi_n (ms^(-1))

yerr  -  fitting error on y