Each text file (Fig2_--nK.txt) corresponds to a single experimental curve in the figure and the file name indicates the trap depth U_D/k_B for each trace.


As described in the text of the paper, the columns (with headers x/y/yerr) correspond to:

x     -  t_s (s)

y     -  atom loss (10^3)

yerr  -  error on y

