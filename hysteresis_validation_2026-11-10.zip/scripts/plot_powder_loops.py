#!/usr/bin/env python3
"""Plot measured and fitted J-H / B-H loops for the powder workbook.

Reads the same xlsx as run_powder_hysteresis_analysis.py and overlays
the best JA variant prediction stored in powder_hysteresis_report.json.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from models.magnetic_powders import (  # noqa: E402
    DATA_SHEETS, audit_sheet, extract_major_loop, load_sheet, load_workbook,
)
from scripts.run_powder_hysteresis_analysis import (  # noqa: E402
    MU0, predict_ja, to_si,
)


def main():
    xlsx = Path(sys.argv[1]) if len(sys.argv) > 1 else \
        Path("data/magnetic/Hysteresis_datasets.xlsx")
    report_path = Path(sys.argv[2]) if len(sys.argv) > 2 else \
        Path("projects/magnetic_powders_validation/powder_hysteresis_report.json")
    outdir = Path(sys.argv[3]) if len(sys.argv) > 3 else \
        Path("projects/magnetic_powders_validation")
    outdir.mkdir(parents=True, exist_ok=True)

    report = json.loads(report_path.read_text()) if report_path.exists() else {}
    wb = load_workbook(xlsx)

    for name in DATA_SHEETS:
        if name not in wb.sheetnames:
            continue
        d = load_sheet(wb, name)
        audit = audit_sheet(d)
        loop = extract_major_loop(d, audit)
        if loop is None:
            continue
        H_kA, J_mT, B_mT = loop["H_kA_m"], loop["J_mT"], loop["B_mT"]

        fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
        ax = axes[0]
        ax.plot(H_kA, J_mT, ".", ms=1.5, color="0.3", label="measured J-H")
        sres = report.get("sheets", {}).get(name, {})
        fits = sres.get("fits", {})
        best = None
        for vname in ("ja_offset", "ja_free_mirr", "ja_plain"):
            if vname in fits and "full_loop" in fits[vname]:
                if best is None or fits[vname]["full_loop"]["gof"] > \
                        fits[best]["full_loop"]["gof"]:
                    best = vname
        if best:
            H_si, M_si, _, _, _ = to_si(loop)
            params = fits[best]["full_loop"]["params"]
            model = {"params": params}
            Mhat = predict_ja(H_si, model)
            Jhat_mT = Mhat * MU0 * 1e3
            ax.plot(H_kA, Jhat_mT, "-", lw=1.0, color="tab:red",
                    label=f"JA+off ({best})")
            gof = fits[best]["full_loop"]["gof"]
            ax.set_title(f"{name} J-H loop — JA GOF={gof:.3f}")
        else:
            ax.set_title(f"{name} J-H loop")
        ax.set_xlabel("H [kA/m]")
        ax.set_ylabel("J [mT]")
        ax.legend(fontsize=7)
        ax.grid(alpha=0.3)

        ax = axes[1]
        ax.plot(H_kA, B_mT, ".", ms=1.5, color="0.3")
        ax.set_xlabel("H [kA/m]")
        ax.set_ylabel("B [mT]")
        ax.set_title("B-H loop")
        ax.grid(alpha=0.3)

        ax = axes[2]
        # residual on J-H for best JA
        if best:
            ax.plot(H_kA, (J_mT - Jhat_mT), ".", ms=1.5, color="tab:blue")
            ax.axhline(0, color="k", lw=0.5)
            ax.set_xlabel("H [kA/m]")
            ax.set_ylabel("J_meas - J_pred [mT]")
            ax.set_title("JA residual")
            ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(outdir / f"{name}_loops.png", dpi=140)
        plt.close(fig)
        print("wrote", outdir / f"{name}_loops.png")


if __name__ == "__main__":
    main()
