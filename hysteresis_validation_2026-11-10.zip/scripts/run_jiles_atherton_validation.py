#!/usr/bin/env python3
"""Jiles-Atherton validation on measured magnetic datasets (issue #114).

Datasets (CC BY 4.0, checksums recorded in the JSON report):
  * EMPIR 19ENG06 HEFMAG, Zenodo 5910893 - 50 Hz Epstein-frame major
    loops of NO and GO FeSi steel (H in A/m, J in Tesla).
  * INRIM first magnetization curves, Zenodo 10725890 - per-material
    H vs B/J curves (first magnetization only; NOT closed loops).

Protocol
--------
* JA is quasi-static and rate-independent; the EMPIR loops were measured
  at 50 Hz, so dynamic (eddy-current) contributions are present and the
  fit is interpreted as an effective quasi-static approximation only.
* EMPIR: one major loop is extracted per amplitude segment; the model is
  fitted on two amplitudes and tested on the held-out amplitude
  (leave-one-amplitude-out). Parameters are material-specific and are
  refit per steel grade (NO, GO) - no parameter sharing across grades.
* INRIM: each first-magnetization curve is split by field magnitude
  (low-field train / high-field test). This is an extrapolation test,
  not a closed-loop loss validation; anhysteretic behaviour is only
  partially exercised because c and alpha trade off.
* Magnetization M = J / mu0 (A/m) for EMPIR; for INRIM, B or J in Tesla
  is converted the same way. JA parameters are reported in A/m units.

Usage:
    python scripts/run_jiles_atherton_validation.py \
        --hefmag-dir data/magnetic/hefmag_loops \
        --inrim data/magnetic/inrim_hbj.dat \
        --output projects/jiles_atherton_validation
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.constitutive_hysteresis import simulate_jiles_atherton
from models.hysteresis_metrics import loop_area, rmse
from models.magnetic_datasets import (
    MU0, extract_major_loop, ja_units_check, load_hefmag_segment,
    load_inrim_first_magnetization,
)


def md5(path):
    return hashlib.md5(Path(path).read_bytes()).hexdigest()


def nrmse_gof(y, yhat):
    y = np.asarray(y, float); yhat = np.asarray(yhat, float)
    r = rmse(y, yhat)
    d = float(np.sqrt(np.mean((y - y.mean()) ** 2)))
    n = r / d if d > 0 else float("nan")
    return {"rmse": r, "nrmse": n, "gof": 1.0 - n}


def loop_metrics(H, J, Jhat):
    """Metrics on a closed major loop (H, J[T] measured, Jhat predicted)."""
    m = nrmse_gof(J, Jhat)
    # energy-loss proxy: area enclosed in the H-J plane
    area_meas = abs(loop_area(H, J))
    area_pred = abs(loop_area(H, Jhat))
    m["loop_area_meas"] = area_meas
    m["loop_area_pred"] = area_pred
    m["loop_area_rel_err"] = abs(area_pred - area_meas) / max(area_meas, 1e-12)
    # coercive field: H at J=0 crossings (mean of |H| at sign changes)
    def coercive(Hv, Jv):
        s = np.sign(Jv)
        idx = np.flatnonzero(np.diff(s) != 0)
        vals = []
        for i in idx:
            w = abs(Jv[i + 1] - Jv[i])
            w = w if w > 0 else 1.0
            vals.append(abs(Hv[i] + (Hv[i + 1] - Hv[i]) *
                           (0 - Jv[i]) / (Jv[i + 1] - Jv[i])))
        return float(np.mean(vals)) if vals else float("nan")
    m["coercive_field_meas"] = coercive(H, J)
    m["coercive_field_pred"] = coercive(H, Jhat)
    # remanence: J at H=0 crossings
    def remanence(Hv, Jv):
        s = np.sign(Hv)
        idx = np.flatnonzero(np.diff(s) != 0)
        vals = []
        for i in idx:
            vals.append(abs(Jv[i] + (Jv[i + 1] - Jv[i]) *
                               (0 - Hv[i]) / (Hv[i + 1] - Hv[i])))
        return float(np.mean(vals)) if vals else float("nan")
    m["remanence_meas"] = remanence(H, J)
    m["remanence_pred"] = remanence(H, Jhat)
    return m


def fit_ja(H, M, p0=None, max_nfev=200):
    """Least-squares fit of simulate_jiles_atherton on (H [A/m], M [A/m]).

    Residuals are normalized by the saturation scale so that the
    trust-region tolerances are meaningful for M ~ 1e6 A/m data.
    """
    from scipy.optimize import least_squares

    H = np.asarray(H, float); M = np.asarray(M, float)
    m_scale = max(float(np.abs(M).max()), 1.0)
    h_scale = max(float(np.abs(H).max()), 1.0)

    def resid(th):
        Ms, a, k, alpha, c = th
        try:
            pred = simulate_jiles_atherton(H, Ms, a, k, alpha, c, Mirr0=0.0)
        except (ValueError, FloatingPointError, ZeroDivisionError):
            return np.full(H.size, 1e3)
        r = (pred - M) / m_scale
        return r if np.all(np.isfinite(r)) else np.full(H.size, 1e3)

    # JA parameters scale with the *field* range (a, k ~ H) and the
    # magnetization range (Ms ~ M); alpha couples them so that
    # alpha*M ~ H. A Ms-scaled guess for a/k is ~1e3 too large and the
    # trust-region solver stalls on a nearly anhysteretic plateau.
    Ms0 = float(max(np.abs(M).max() * 1.15, 1e3))
    alpha0 = 0.25 * h_scale / Ms0
    starts = []
    if p0 is not None:
        starts.append(np.asarray(p0, float))
    for a_fac in (0.1, 0.5):
        for k_fac in (0.1, 0.5):
            starts.append(np.array([Ms0, h_scale * a_fac,
                                    h_scale * k_fac, alpha0, 0.3]))
    lb = np.array([1e3, 1e-6, 1e-6, 0.0, 0.0])
    ub = np.array([1e8, 1e8, 1e8, h_scale / Ms0, 1.0])
    best = None
    for start in starts:
        sol = least_squares(resid, start, bounds=(lb, ub), method="trf",
                            x_scale="jac", max_nfev=max_nfev)
        if best is None or sol.cost < best.cost:
            best = sol
    sol = best
    return {"Ms": float(sol.x[0]), "a": float(sol.x[1]), "k": float(sol.x[2]),
            "alpha": float(sol.x[3]), "c": float(sol.x[4]),
            "cost": float(sol.cost), "nfev": int(sol.nfev),
            "optimality": float(sol.optimality), "success": bool(sol.success)}


def predict_ja(H, model, Mirr0=0.0):
    return simulate_jiles_atherton(
        H, model["Ms"], model["a"], model["k"], model["alpha"], model["c"],
        Mirr0=Mirr0)


def _warm_start_H(H):
    """Prepend a short descent ramp so JA starts from a magnetized state.

    Each extracted loop begins at the field minimum and first sweeps up;
    physically the field arrived there from the positive maximum. Simulating
    a coarse descent from the loop maximum down to the start removes the
    Mirr0=0 transient. The prepended samples are discarded afterwards.
    """
    hmin, hmax = float(H[0]), float(np.abs(H).max())
    pre = np.linspace(hmax, hmin, 40)
    return np.concatenate([pre, H])


def predict_ja_loop(H, model):
    Hh = _warm_start_H(np.asarray(H, float))
    Mfull = predict_ja(Hh, model)
    return Mfull[40:]


def fit_ja_loops(loops_H, loops_M, max_nfev=150):
    """Fit JA on several loops, simulating each separately (no splice)."""
    from scipy.optimize import least_squares

    m_scale = max(float(np.abs(np.concatenate(loops_M)).max()), 1.0)
    h_scale = max(float(np.abs(np.concatenate(loops_H)).max()), 1.0)
    Ms0 = float(max(np.abs(np.concatenate(loops_M)).max() * 1.15, 1e3))
    alpha0 = 0.25 * h_scale / Ms0

    def resid(th):
        Ms, a, k, alpha, c = th
        try:
            parts = []
            for Hl, Ml in zip(loops_H, loops_M):
                pred = predict_ja_loop(Hl, {"Ms": Ms, "a": a, "k": k,
                                            "alpha": alpha, "c": c})
                parts.append((pred - Ml) / m_scale)
            r = np.concatenate(parts)
        except (ValueError, FloatingPointError, ZeroDivisionError):
            n = sum(l.size for l in loops_H)
            return np.full(n, 1e3)
        return r if np.all(np.isfinite(r)) else np.full(r.size, 1e3)

    starts = [np.array([Ms0, h_scale * af, h_scale * kf, alpha0, 0.3])
              for af in (0.1, 0.5) for kf in (0.1, 0.5)]
    lb = np.array([1e3, 1e-6, 1e-6, 0.0, 0.0])
    ub = np.array([1e8, 1e8, 1e8, h_scale / Ms0, 1.0])
    best = None
    for start in starts:
        sol = least_squares(resid, start, bounds=(lb, ub), method="trf",
                            x_scale="jac", max_nfev=max_nfev)
        if best is None or sol.cost < best.cost:
            best = sol
    x = best.x
    return {"Ms": float(x[0]), "a": float(x[1]), "k": float(x[2]),
            "alpha": float(x[3]), "c": float(x[4]),
            "cost": float(best.cost), "nfev": int(best.nfev),
            "optimality": float(best.optimality), "success": bool(best.success)}


def run_empif(hefmag_dir, outdir):
    results = {"dataset": "EMPIR 19ENG06 HEFMAG (Zenodo 5910893)",
               "note": ("50 Hz Epstein-frame loops; JA is quasi-static, "
                        "so results are an effective static approximation "
                        "and do not validate dynamic loss models."),
               "grades": {}}
    archive = Path(hefmag_dir)
    zip_path = archive.parent / "hefmag_loops.zip"
    prov = {"zip_md5": md5(zip_path) if zip_path.exists() else None,
            "files": {}}
    for grade, fname in (("NO", "NO.dat"), ("GO", "GO.dat")):
        fpath = archive / fname
        prov["files"][fname] = md5(fpath)
        nseg = len([1 for _ in open(fpath) if _.strip() == "--\t--"] ) + 1
        loops = []
        for si in range(3):
            H, J = load_hefmag_segment(fpath, si)
            Hl, Jl = extract_major_loop(H, J)
            loops.append((Hl, Jl, si))
        grade_res = {"n_segments": 3, "loo_amplitude": []}
        for held in range(3):
            train = [l for i, l in enumerate(loops) if i != held]
            # JA is rate-independent: decimate the fit grid by 2 for speed;
            # turning points are preserved because loops are smooth.
            tH = [l[0][::3] for l in train]
            tM = [ja_units_check(l[1])[::3] for l in train]
            t0 = time.time()
            model = fit_ja_loops(tH, tM, max_nfev=120)
            fit_s = time.time() - t0
            Hl, Jl, _ = loops[held]
            Mhat = predict_ja_loop(Hl, model)
            Jhat = Mhat * MU0
            met = loop_metrics(Hl, Jl, Jhat)
            met.update({"held_out_segment": held,
                        "peak_J_T": float(np.abs(Jl).max()),
                        "n_loop_samples": int(Hl.size),
                        "fit_seconds": fit_s,
                        "params": {k: model[k] for k in
                                   ("Ms", "a", "k", "alpha", "c")}})
            grade_res["loo_amplitude"].append(met)
            print(f"  {grade} held seg {held}: GOF={met['gof']:.4f} "
                  f"area_err={met['loop_area_rel_err']:.3f}", flush=True)
        results["grades"][grade] = grade_res
    results["provenance"] = prov
    return results


def run_inrim(path, outdir):
    mats = load_inrim_first_magnetization(path)
    results = {"dataset": "INRIM first magnetization curves (Zenodo 10725890)",
               "note": ("First-magnetization curves only; split is "
                        "low-field train / high-field test (extrapolation). "
                        "Not a closed-loop or dynamic validation."),
               "file_md5": md5(path), "materials": {}}
    for name, blk in mats.items():
        H = np.asarray(blk["H"], float)
        X = np.asarray(blk["B_or_J"], float)
        # Column is B (flux density, T) or J (polarization, T) per the
        # header order token. SI relations: J = mu0*M, B = mu0*(H + M),
        # with H already in A/m. JA needs M in A/m.
        if " B" in blk["order"] or blk["order"].endswith("B"):
            M = X / MU0 - H
        else:
            M = ja_units_check(X)
        order = np.argsort(H)
        Hs, Ms = H[order], M[order]
        hmax = float(np.abs(Hs).max())
        hsplit = 0.6 * hmax
        tr = np.abs(Hs) <= hsplit
        te = ~tr
        if tr.sum() < 5 or te.sum() < 3:
            results["materials"][name] = {"skipped": "too few points",
                                          "order": blk["order"]}
            continue
        try:
            model = fit_ja(Hs[tr], Ms[tr], max_nfev=150)
        except Exception as exc:
            results["materials"][name] = {"error": str(exc),
                                          "order": blk["order"]}
            continue
        # JA is path-dependent: simulate the whole curve once, then split
        # the prediction. Simulating only the high-field tail would reset
        # the irreversible state and corrupt the extrapolation metric.
        pred_all = predict_ja(Hs, model)
        m_tr = nrmse_gof(Ms[tr], pred_all[tr])
        m_te = nrmse_gof(Ms[te], pred_all[te])
        results["materials"][name] = {
            "order": blk["order"], "n_points": int(Hs.size),
            "h_split_Apm": float(hsplit),
            "train": m_tr, "test_high_field": m_te,
            "params": {k: model[k] for k in ("Ms", "a", "k", "alpha", "c")},
            "nfev": model["nfev"], "success": model["success"]}
        print(f"  {name}: test GOF={m_te['gof']:.4f}", flush=True)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hefmag-dir", required=True)
    ap.add_argument("--inrim", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    outdir = Path(args.output)
    outdir.mkdir(parents=True, exist_ok=True)

    report = {"issue": 114,
              "generated_by": "scripts/run_jiles_atherton_validation.py"}
    print("EMPIR HEFMAG loops...", flush=True)
    report["empif_hefmag"] = run_empif(args.hefmag_dir, outdir)
    print("INRIM first magnetization...", flush=True)
    report["inrim"] = run_inrim(args.inrim, outdir)

    (outdir / "jiles_atherton_validation.json").write_text(
        json.dumps(report, indent=2))
    print(f"wrote {outdir/'jiles_atherton_validation.json'}")


if __name__ == "__main__":
    main()
