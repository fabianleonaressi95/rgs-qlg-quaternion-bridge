#!/usr/bin/env python3
"""Experimental hysteresis analysis of Hysteresis_datasets.xlsx (Zenodo 17053338).

Pipeline:
  1. audit every measurement sheet (schema, units, sampling, reversals);
  2. extract the major B-H/J-H loop and the first-magnetization ramp;
  3. compute coercivity, remanence, saturation and loop-loss metrics on
     both the J-H and B-H planes and cross-check against the author
     metrics in the 'Results' sheet;
  4. fit the scalar quasi-static Jiles-Atherton model (with optional DC
     offset and free initial irreversible state) on each major loop;
  5. branch-holdout validation: fit on the descending sweep, predict the
     ascending sweep (and vice versa) — trajectory-level holdout, no
     random sample splitting;
  6. classical Prandtl-Ishlinskii dictionary baseline on the same splits;
  7. write JSON report, CSV tables and B-H/J-H plots.

Units inside the fits are SI: H [A/m], M [A/m] with J = mu0 * M.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.constitutive_hysteresis import (
    asymmetric_play_states,
    simulate_jiles_atherton,
)
from models.hysteresis_metrics import rmse
from models.magnetic_powders import (
    DATA_SHEETS, EXPECTED_MD5, audit_sheet, extract_first_magnetization,
    extract_major_loop, file_md5, load_results_metadata, load_sheet,
    load_workbook, loop_metrics_bh,
)

MU0 = 4e-7 * np.pi
XLSX = "data/magnetic/Hysteresis_datasets.xlsx"


def nrmse_gof(y, yhat):
    y = np.asarray(y, float); yhat = np.asarray(yhat, float)
    r = rmse(y, yhat)
    d = float(np.sqrt(np.mean((y - y.mean()) ** 2)))
    n = r / d if d > 0 else float("nan")
    return {"rmse": float(r), "nrmse": float(n), "gof": float(1.0 - n)}


def to_si(loop):
    """loop dict in released units -> H[A/m], M[A/m] (=J/mu0)."""
    return (loop["H_kA_m"] * 1e3,
            loop["J_mT"] * 1e-3 / MU0,
            loop["B_mT"], loop["J_mT"], loop["H_kA_m"])


# ---------------------------------------------------------------- JA fit

def fit_ja(H, M, max_nfev=120, offset=False, free_mirr=False):
    """Bounded least-squares fit of simulate_jiles_atherton.

    H, M in SI (A/m). If offset=True an additive constant M0 (A/m) is
    fitted — motivated by the observed positive J remanence asymmetry.
    If free_mirr=True the initial irreversible magnetization Mirr0 is
    fitted too (bounded by +/-Ms).
    """
    from scipy.optimize import least_squares

    H = np.asarray(H, float); M = np.asarray(M, float)
    m_scale = max(float(np.abs(M - M.mean()).max()), 1.0)
    h_scale = max(float(np.abs(H).max()), 1.0)
    Ms0 = float(max(np.abs(M).max() * 1.15, 1e3))
    alpha0 = 0.25 * h_scale / Ms0

    def resid(th):
        Ms, a, k, alpha, c = th[:5]
        off = th[5] if offset else 0.0
        mirr0 = th[6] if free_mirr else 0.0
        try:
            pred = simulate_jiles_atherton(H, Ms, a, k, alpha, c,
                                           Mirr0=mirr0) + off
        except (ValueError, FloatingPointError, ZeroDivisionError):
            return np.full(H.size, 1e3)
        r = (pred - M) / m_scale
        return r if np.all(np.isfinite(r)) else np.full(H.size, 1e3)

    n_par = 5 + int(offset) + int(free_mirr)
    starts = []
    for af in (0.05, 0.3):
        for kf in (0.05, 0.3):
            th = [Ms0, h_scale * af, h_scale * kf,
                  min(alpha0, 1e-2), 0.3]
            if offset:
                th.append(0.0)
            if free_mirr:
                th.append(0.0)
            starts.append(np.array(th, float))
    lb = [1e3, 1e-6, 1e-6, 0.0, 0.0]
    ub = [1e9, 1e9, 1e9, h_scale / Ms0, 1.0]
    if offset:
        lb.append(-m_scale); ub.append(m_scale)
    if free_mirr:
        lb.append(-Ms0); ub.append(Ms0)
    best = None
    for s in starts:
        sol = least_squares(resid, s, bounds=(np.array(lb), np.array(ub)),
                            method="trf", x_scale="jac", max_nfev=max_nfev)
        if best is None or sol.cost < best.cost:
            best = sol
    keys = ["Ms", "a", "k", "alpha", "c"]
    if offset:
        keys.append("offset_A_m")
    if free_mirr:
        keys.append("Mirr0_A_m")
    return {"params": dict(zip(keys, best.x)), "cost": float(best.cost),
            "nfev": int(best.nfev), "optimality": float(best.optimality),
            "success": bool(best.success)}


def predict_ja(H, model):
    p = model["params"]
    return (simulate_jiles_atherton(
        H, p["Ms"], p["a"], p["k"], p["alpha"], p["c"],
        Mirr0=p.get("Mirr0_A_m", 0.0))
        + p.get("offset_A_m", 0.0))


# ------------------------------------------------------- PI alternative

def fit_pi_loop(H, M, n_radii=15, ridge=1e-3):
    """Classical play-operator PI fit on one loop trajectory (SI units).

    Play states have the same magnitude as H (~1e6 A/m) while M ~ 1e5
    A/m, so the design matrix is severely collinear; an unregularized
    lstsq produces cancelling weights and diverging predictions. A small
    Tikhonov penalty on the play weights (not on bias/linear terms)
    stabilizes the fit.
    """
    radii = np.linspace(0.05 * np.abs(H).max(), 0.8 * np.abs(H).max(),
                        n_radii)
    S = asymmetric_play_states(H, radii, radii)
    X = np.column_stack((np.ones(H.size), H, S))
    p = X.shape[1]
    A = X.T @ X
    lam = ridge * np.trace(A) / p
    A.flat[::p + 1] += lam
    A[0, 0] -= lam
    A[1, 1] -= lam
    coef = np.linalg.solve(A, X.T @ M)
    model = {"bias": float(coef[0]), "linear_gain": float(coef[1]),
             "play_weights": coef[2:], "radii": radii}
    return model


def predict_pi_loop(H, model):
    from models.constitutive_hysteresis import (
        predict_prandtl_ishlinskii_v2)
    return predict_prandtl_ishlinskii_v2(H, model)


# ------------------------------------------------------------------ main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", default=XLSX)
    ap.add_argument("--output", default="projects/magnetic_powders_validation")
    ap.add_argument("--max-nfev", type=int, default=120)
    ap.add_argument("--skip-insample", action="store_true")
    args = ap.parse_args()
    outdir = Path(args.output)
    outdir.mkdir(parents=True, exist_ok=True)

    xlsx = Path(args.xlsx)
    prov = {"file": str(xlsx), "md5": file_md5(xlsx),
            "expected_md5": EXPECTED_MD5,
            "md5_match": file_md5(xlsx) == EXPECTED_MD5,
            "zenodo": "https://doi.org/10.5281/zenodo.17053338"}

    wb = load_workbook(xlsx)
    meta = load_results_metadata(wb)
    report = {"provenance": prov, "metadata": meta, "sheets": {},
              "generated_by": "scripts/run_powder_hysteresis_analysis.py"}

    sheet_names = [s for s in DATA_SHEETS if s in wb.sheetnames]
    exp_iter = iter(zip(meta["experiments"], meta["samples"],
                        meta["author_metrics"]))
    sheet_meta = {}
    for name in sheet_names:
        try:
            sheet_meta[name] = next(exp_iter)
        except StopIteration:
            sheet_meta[name] = (None, None, None)

    all_loop_rows = []
    for name in sheet_names:
        t0 = time.time()
        d = load_sheet(wb, name)
        audit = audit_sheet(d)
        loop = extract_major_loop(d, audit)
        virgin = extract_first_magnetization(d, audit, loop)
        exp, sample, auth = sheet_meta[name]
        sres = {"experiment": exp, "sample": sample,
                "author_metrics": auth, "audit": audit,
                "loop": None, "fits": {}}
        if loop is None:
            sres["error"] = "no major loop found"
            report["sheets"][name] = sres
            continue

        met = loop_metrics_bh(loop["H_kA_m"], loop["J_mT"], loop["B_mT"])
        sres["loop"] = {"n_samples": len(loop["H_kA_m"]),
                        "H_range_kA_m": [float(loop["H_kA_m"].min()),
                                         float(loop["H_kA_m"].max())],
                        "metrics": met,
                        "virgin_n": len(virgin["H_kA_m"]) if virgin else 0}
        all_loop_rows.append({"sheet": name, **met})

        # ---- JA fits on the full loop trajectory (SI units)
        H_si, M_si, _, _, _ = to_si(loop)
        # split indices: loop = down-sweep then up-sweep; find the field
        # minimum which separates them
        i_min = int(np.argmin(H_si))
        variants = {
            "ja_plain": fit_ja(H_si, M_si, args.max_nfev,
                               offset=False, free_mirr=False),
            "ja_offset": fit_ja(H_si, M_si, args.max_nfev,
                                offset=True, free_mirr=False),
            "ja_free_mirr": fit_ja(H_si, M_si, args.max_nfev,
                                   offset=True, free_mirr=True),
        }
        for vname, fit in variants.items():
            yhat = predict_ja(H_si, fit)
            metf = nrmse_gof(M_si, yhat)
            metf.update({"n_params": len(fit["params"]),
                         "nfev": fit["nfev"], "success": fit["success"],
                         "optimality": fit["optimality"],
                         "params": fit["params"]})
            sres["fits"][vname] = {"full_loop": metf}

        # ---- branch-holdout: fit on down-sweep -> predict up-sweep
        H_dn, M_dn = H_si[:i_min + 1], M_si[:i_min + 1]
        H_up, M_up = H_si[i_min:], M_si[i_min:]
        # carry the fitted state: fit on down only, then continue the
        # simulation into the up-sweep by concatenating histories
        for tag, Htr, Mtr, Hte, Mte in (
                ("down_to_up", H_dn, M_dn, H_up, M_up),):
            fit = fit_ja(Htr, Mtr, args.max_nfev,
                         offset=True, free_mirr=True)
            # predict up-sweep with state carried from down-sweep:
            # concatenate and simulate once, then slice
            H_cat = np.concatenate([Htr, Hte])
            Mhat_cat = predict_ja(H_cat, fit)
            Mhat_te = Mhat_cat[Htr.size:]
            met_te = nrmse_gof(Mte, Mhat_te)
            met_tr = nrmse_gof(Mtr, Mhat_cat[:Htr.size])
            # PI baseline on the same split
            pi = fit_pi_loop(Htr, Mtr)
            pi_cat = predict_pi_loop(H_cat, pi)
            met_pi_te = nrmse_gof(Mte, pi_cat[Htr.size:])
            met_pi_tr = nrmse_gof(Mtr, pi_cat[:Htr.size])
            sres["fits"]["ja_free_mirr"]["branch_holdout"] = {
                "direction": tag,
                "train": met_tr, "test": met_te,
                "pi_train": met_pi_tr, "pi_test": met_pi_te,
                "params": fit["params"]}

        sres["wall_seconds"] = time.time() - t0
        report["sheets"][name] = sres
        print(f"{name}: loop GOF ja_offset="
              f"{sres['fits']['ja_offset']['full_loop']['gof']:.4f} "
              f"holdout={sres['fits']['ja_free_mirr']['branch_holdout']['test']['gof']:.4f} "
              f"({sres['wall_seconds']:.0f}s)", flush=True)

    # CSV of loop metrics
    import csv
    if all_loop_rows:
        keys = sorted({k for r in all_loop_rows for k in r.keys()})
        with open(outdir / "loop_metrics.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for r in all_loop_rows:
                w.writerow({k: (json.dumps(v) if isinstance(v, (list, dict))
                                else v) for k, v in r.items()})

    # author-metric cross-check summary
    xcheck = []
    for name in sheet_names:
        s = report["sheets"].get(name)
        if not s or not s.get("loop"):
            continue
        auth = s["author_metrics"]
        met = s["loop"]["metrics"]
        hcj = met["coercive_fields_kA_m"]
        hcb = met["B_coercive_fields_kA_m"]
        rem = met["remanence_points_mT"]
        xcheck.append({
            "sheet": name,
            "HcJ_ours_meanabs": float(np.mean(np.abs(hcj))) if hcj else None,
            "HcJ_author": auth["HcJ_kA_m"] if auth else None,
            "HcB_ours_meanabs": float(np.mean(np.abs(hcb))) if hcb else None,
            "HcB_author": auth["HcB_kA_m"] if auth else None,
            "Br_ours_meanabs": float(np.mean(np.abs(rem))) if rem else None,
            "Br_author": auth["Br_mT"] if auth else None,
            "Js_ours_mT": met["J_max_mT"],
            "Js_author_mT": auth["Js_mT"] if auth else None,
            "loss_J_m3": met["loop_loss_abs_J_m3"],
        })
    report["author_crosscheck"] = xcheck

    (outdir / "powder_hysteresis_report.json").write_text(
        json.dumps(report, indent=2, default=str))
    print(f"wrote {outdir/'powder_hysteresis_report.json'}")


if __name__ == "__main__":
    main()
