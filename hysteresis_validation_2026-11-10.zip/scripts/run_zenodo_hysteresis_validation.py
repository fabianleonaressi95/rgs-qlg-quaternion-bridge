#!/usr/bin/env python3
"""Experimental validation of hysteresis models on the Zenodo actuator record.

Issue: https://github.com/fabianleonaressi95/theorem/issues/113
Dataset: https://doi.org/10.5281/zenodo.15584329 (CC BY 4.0)
Article: de la Morena Duque, Ramos, Vazquez, Actuators 14(7), 321 (2025),
         https://doi.org/10.3390/act14070321

Protocol
--------
* Non-destructive schema audit first (scripts/audit_hysteresis_csv.py).
* The record contains 4 complete triangular cycles. Evaluation is
  leave-one-cycle-out (LOCO): each fold trains on 3 complete cycles and
  tests on the held-out cycle. No sample of a test cycle is ever used
  for fitting (no leakage).
* Operator/dynamic models are always simulated on the *full* input
  history (causal); only the loss is masked to training cycles. This
  matches deployment, where the input command is known in advance.
* Dictionary models (Preisach, PI, asymmetric PI) are linear
  least-squares fits on fixed operator grids; GPI and Bouc-Wen are
  nonlinear least-squares fits on a strided grid (default stride 10,
  dt_fit = 10/30 s) to bound runtime; predictions for metrics are
  computed on the full-resolution record.
* Metrics per held-out cycle: RMSE, NRMSE, GOF = 1 - NRMSE (article
  convention), loop-area relative error, branch separation, reversal-
  point errors, parameter count, fit wall time.
* An all-cycles in-sample fit is also reported for comparison with the
  published GOF values (the article fitted all data with a GA; its
  results are *not* used as training targets anywhere).

Usage:
    python scripts/run_zenodo_hysteresis_validation.py \
        --data /path/to/data.csv --output projects/zenodo_hysteresis_validation
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.constitutive_hysteresis import (
    asymmetric_play_states,
    fit_bouc_wen,
    fit_gpi_varpro,
    generalized_prandtl_ishlinskii_predict,
    predict_asymmetric_prandtl_ishlinskii_v2,
    predict_bouc_wen,
    predict_prandtl_ishlinskii_v2,
    threshold_grid,
)
from models.hysteresis_metrics import branch_separation, loop_area, rmse
from models.zenodo_soft_actuator import load_zenodo_actuator, summarize_dataset
from scripts.audit_hysteresis_csv import audit_csv

# Published GOF values from Actuators 14(7), 321 (2025), for reference only.
ARTICLE_GOF = {
    "preisach_gc10": 0.8906, "preisach_gc50": 0.9550, "preisach_gc100": 0.9584,
    "preisach_gg10": 0.8890, "preisach_gg50": 0.9509, "preisach_gg100": 0.9538,
    "cpi5": 0.8601, "cpi10": 0.8606,
    "gpi10_tanh": 0.9744, "gpi10_gauss": 0.9668, "gpi10_poly": 0.9704,
    "gpi15_tanh": 0.9741, "gpi15_gauss": 0.9730, "gpi15_poly": 0.9707,
    "cbw": 0.8614, "abw1": 0.9367, "abw2": 0.9634,
}


def cycle_indices(ds, ci):
    c = ds.cycles[ci]
    return np.arange(c.start, c.stop)


def all_cycle_mask(ds, indices):
    mask = np.zeros(len(ds.input), bool)
    for ci in indices:
        mask[cycle_indices(ds, ci)] = True
    return mask


def nrmse_gof(y, yhat):
    y = np.asarray(y, float); yhat = np.asarray(yhat, float)
    r = rmse(y, yhat)
    denom = float(np.sqrt(np.mean((y - np.mean(y)) ** 2)))
    n = r / denom if denom > 0 else float("nan")
    return {"rmse": r, "nrmse": n, "gof": 1.0 - n}


def reversal_errors(u, y, yhat):
    """Errors at input extrema (loop tips) inside one cycle."""
    i_max = int(np.argmax(u))
    i_min = int(np.argmin(u))
    pts = sorted({0, i_max, i_min, len(u) - 1})
    errs = [float(abs(yhat[i] - y[i])) for i in pts]
    return {"max": float(max(errs)), "mean": float(np.mean(errs)),
            "n_points": len(pts)}


def branch_separation_input(u, y):
    """Mean horizontal (input-direction) branch gap at common output levels.

    Coercivity-like metric computed on the (u, y) loop supplied; call it on
    measured data and on predictions separately to compare them.
    """
    i_max = int(np.argmax(u))
    up_u, up_y = u[:i_max + 1], y[:i_max + 1]
    dn_u, dn_y = u[i_max:], y[i_max:]
    lo, hi = max(up_y.min(), dn_y.min()), min(up_y.max(), dn_y.max())
    if not hi > lo:
        return float("nan")
    grid = np.linspace(lo, hi, 200)
    # branches are monotone in y locally enough for interp after sorting
    o1 = np.argsort(up_y); o2 = np.argsort(dn_y)
    u1 = np.interp(grid, up_y[o1], up_u[o1])
    u2 = np.interp(grid, dn_y[o2], dn_u[o2])
    return float(np.mean(np.abs(u1 - u2)))


def cycle_metrics(u, y, yhat):
    m = nrmse_gof(y, yhat)
    m["loop_area_meas"] = loop_area(u, y)
    m["loop_area_pred"] = loop_area(u, yhat)
    m["loop_area_rel_err"] = abs(m["loop_area_pred"] - m["loop_area_meas"]) / max(
        abs(m["loop_area_meas"]), 1e-12)
    i_max = int(np.argmax(u))
    m["branch_separation"] = branch_separation(u, y, i_max)
    m["branch_separation_pred"] = branch_separation(u, yhat, i_max)
    m["branch_separation_input"] = branch_separation_input(u, y)
    m["branch_separation_input_pred"] = branch_separation_input(u, yhat)
    m["reversal"] = reversal_errors(u, y, yhat)
    return m


def fit_dictionary_models(u_full, y_full, train_mask, dt):
    """Fit all linear dictionary models on the masked training rows.

    Features are computed once on the full input record so operator memory
    follows the true causal input history; the fit uses only training rows.
    """
    fits = {}
    t_all = time.time()

    # --- Preisach on a triangular threshold grid ---
    alpha, beta = threshold_grid(u_full, levels=13)
    Xp = np.column_stack((np.ones(len(u_full)),
                          _preisach_feature_matrix(u_full, alpha, beta)))
    coef = _masked_lstsq(Xp[train_mask], y_full[train_mask])
    model = {"bias": float(coef[0]), "relay_weights": coef[1:],
             "alpha": alpha, "beta": beta}
    fits["preisach"] = {
        "model": model, "n_params": int(Xp.shape[1]),
        "predict": lambda uu, _m=model: predict_preisach_full(uu, _m),
        "fit_seconds": time.time() - t_all}

    # --- classical PI ---
    radii = np.linspace(0.02, 0.7, 25)
    Sp = asymmetric_play_states(u_full, radii, radii)
    Xpi = np.column_stack((np.ones(len(u_full)), u_full, Sp))
    coef = _masked_lstsq(Xpi[train_mask], y_full[train_mask])
    pi_model = {"intercept": True, "bias": float(coef[0]),
                "linear_gain": float(coef[1]), "play_weights": coef[2:],
                "radii": radii}
    fits["pi"] = {
        "model": pi_model, "n_params": int(Xpi.shape[1]),
        "predict": lambda uu, _m=pi_model: predict_prandtl_ishlinskii_v2(uu, _m),
        "fit_seconds": time.time() - t_all}

    # --- asymmetric PI: product grid of (lower, upper) widths ---
    widths = np.array([0.02, 0.05, 0.1, 0.18, 0.3, 0.45])
    lo, hi = np.meshgrid(widths, widths, indexing="ij")
    keep = ~((lo == 0) & (hi == 0))
    lw, hw = lo[keep], hi[keep]
    Sa = asymmetric_play_states(u_full, lw, hw)
    Xa = np.column_stack((np.ones(len(u_full)), u_full, Sa))
    coef = _masked_lstsq(Xa[train_mask], y_full[train_mask])
    a_model = {"intercept": True, "bias": float(coef[0]),
               "linear_gain": float(coef[1]), "play_weights": coef[2:],
               "lower_widths": lw, "upper_widths": hw}
    fits["asym_pi"] = {
        "model": a_model, "n_params": int(Xa.shape[1]),
        "predict": lambda uu, _m=a_model:
            predict_asymmetric_prandtl_ishlinskii_v2(uu, _m),
        "fit_seconds": time.time() - t_all}
    return fits


def _preisach_feature_matrix(u, alpha, beta, initial_state=-1.0):
    """Relay-state matrix, vectorized over thresholds (same recursion as
    models.constitutive_hysteresis.preisach_features)."""
    states = np.full(alpha.size, float(initial_state))
    out = np.empty((u.size, alpha.size), float)
    for k, value in enumerate(u):
        states = np.where(value >= alpha, 1.0,
                          np.where(value <= beta, -1.0, states))
        out[k] = states
    return out


def predict_preisach_full(u, model):
    X = _preisach_feature_matrix(u, model["alpha"], model["beta"])
    return model["bias"] + X @ model["relay_weights"]


def _masked_lstsq(X, y):
    coef, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    return coef


def fit_nonlinear_models(u_full, y_full, train_mask, dt, stride,
                         gpi_kinds=("tanh", "poly"), max_nfev=120):
    """Fit GPI variants and Bouc-Wen variants on strided full record."""
    us = u_full[::stride]
    ys = y_full[::stride]
    mask_s = train_mask[::stride]
    fits = {}
    radii = np.linspace(0.02, 0.8, 12)
    for kind in gpi_kinds:
        t0 = time.time()
        model = fit_gpi_varpro(us, ys, radii, kind=kind, mask=mask_s,
                               max_nfev=max_nfev)
        fits[f"gpi_{kind}"] = {
            "model": model, "n_params": int(4 + 2 * {"tanh": 3, "poly": 2,
                                                     "gauss": 3}[kind]),
            "predict": lambda uu, _m=model:
                generalized_prandtl_ishlinskii_predict(uu, _m),
            "fit_seconds": time.time() - t0}
    for asym in (False, True):
        name = "bw_abw" if asym else "bw_cbw"
        t0 = time.time()
        model = fit_bouc_wen(us, ys, dt * stride, stride=1,
                             asymmetric=asym, mask=mask_s, max_nfev=max_nfev)
        model["stride"] = 1
        model["dt_fit"] = float(dt * stride)
        fits[name] = {
            "model": model,
            "n_params": 8 if asym else 7,
            "predict": lambda uu, _m=model, _dt=dt:
                predict_bouc_wen(uu, _m, _dt),
            "fit_seconds": time.time() - t0}
    return fits


def evaluate_model(name, fit, ds, test_ci, train_cycles):
    c = ds.cycles[test_ci]
    sl = slice(c.start, c.stop)
    u_c, y_c = ds.input[sl], ds.output[sl]
    t0 = time.time()
    yhat = fit["predict"](ds.input)  # full-record causal prediction
    yhat_c = yhat[sl]
    pred_seconds = time.time() - t0
    met = cycle_metrics(u_c, y_c, yhat_c)
    met.update({"model": name, "held_out_cycle": test_ci,
                "train_cycles": list(train_cycles),
                "n_params": fit["n_params"],
                "fit_seconds": fit["fit_seconds"],
                "predict_seconds": pred_seconds})
    if name.startswith("bw_"):
        met["bw_params"] = fit["model"]["params"]
        met["bw_nfev"] = fit["model"]["nfev"]
        met["bw_success"] = fit["model"]["success"]
    if name.startswith("gpi_"):
        met["gpi_theta"] = list(map(float, fit["model"]["theta"]))
        met["gpi_linear"] = fit["model"]["linear_coeffs"]
        met["gpi_nfev"] = fit["model"]["nfev"]
        met["gpi_success"] = fit["model"]["success"]
    return met, yhat_c


def in_sample_gof(ds, fits_all):
    """GOF of each model fitted on all cycles, evaluated on all data."""
    out = {}
    y_all = ds.output
    for name, fit in fits_all.items():
        yhat = fit["predict"](ds.input)
        m = nrmse_gof(y_all, yhat)
        out[name] = {"gof": m["gof"], "nrmse": m["nrmse"], "rmse": m["rmse"]}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="path to Zenodo data.csv")
    ap.add_argument("--output", required=True, help="output directory")
    ap.add_argument("--stride", type=int, default=10,
                    help="decimation stride for nonlinear model fitting")
    ap.add_argument("--max-nfev", type=int, default=120)
    ap.add_argument("--skip-insample", action="store_true")
    ap.add_argument("--quick", action="store_true",
                    help="reduce GPI kinds to tanh only")
    args = ap.parse_args()

    outdir = Path(args.output)
    outdir.mkdir(parents=True, exist_ok=True)

    report = {"dataset": {}, "protocol": {}, "loco": [], "insample": {},
              "article_reference_gof": ARTICLE_GOF,
              "generated_by": "scripts/run_zenodo_hysteresis_validation.py"}

    # 1. schema audit (non-destructive)
    audit = audit_csv(args.data)
    (outdir / "schema_audit.json").write_text(json.dumps(audit, indent=2))

    # 2. load + segment
    ds = load_zenodo_actuator(args.data)
    report["dataset"] = summarize_dataset(ds)
    report["protocol"] = {
        "split": "leave-one-cycle-out over 4 complete cycles",
        "n_cycles": len(ds.cycles),
        "operator_history": "full causal input history; loss masked to train cycles",
        "nonlinear_fit_stride": args.stride,
        "dt_s": float(np.median(np.diff(ds.time))),
        "nonlinear_fit_dt_s": float(np.median(np.diff(ds.time))) * args.stride,
        "metrics": ["rmse", "nrmse", "gof", "loop_area_rel_err",
                    "branch_separation", "branch_separation_input",
                    "reversal.max", "reversal.mean", "n_params",
                    "fit_seconds"],
    }

    dt = float(np.median(np.diff(ds.time)))
    n_cycles = len(ds.cycles)
    gpi_kinds = ("tanh",) if args.quick else ("tanh", "poly")
    first_fold_preds = {}
    all_fold_preds = {}

    for held in range(n_cycles):
        train_cycles = [i for i in range(n_cycles) if i != held]
        train_mask = all_cycle_mask(ds, train_cycles)
        fold = {"held_out_cycle": held, "train_cycles": train_cycles,
                "models": {}}
        print(f"[fold {held}] held-out cycle {held}, "
              f"train cycles {train_cycles}", flush=True)

        dict_fits = fit_dictionary_models(ds.input, ds.output, train_mask, dt)
        nl_fits = fit_nonlinear_models(ds.input, ds.output, train_mask, dt,
                                       args.stride, gpi_kinds,
                                       args.max_nfev)

        for name, fit in {**dict_fits, **nl_fits}.items():
            met, yhat_c = evaluate_model(name, fit, ds, held, train_cycles)
            fold["models"][name] = met
            if held == 0:
                first_fold_preds[name] = yhat_c
            all_fold_preds[f"fold{held}_{name}"] = yhat_c
            print(f"  {name:10s} GOF={met['gof']:.4f} "
                  f"RMSE={met['rmse']:.5f} "
                  f"({met['fit_seconds']:.1f}s fit, "
                  f"{met['predict_seconds']:.1f}s pred)", flush=True)
        report["loco"].append(fold)

    # 3. in-sample all-cycle fits for article comparison
    if not args.skip_insample:
        all_mask = np.ones(len(ds.input), bool)
        insample_fits = {}
        dict_fits = fit_dictionary_models(ds.input, ds.output, all_mask, dt)
        insample_fits.update(dict_fits)
        insample_fits.update(fit_nonlinear_models(
            ds.input, ds.output, all_mask, dt, args.stride, gpi_kinds,
            args.max_nfev))
        report["insample"] = in_sample_gof(ds, insample_fits)
        report["insample"]["_note"] = (
            "GOF on all 4 cycles with models fitted on all 4 cycles; "
            "article values are in-sample GA fits, not held-out")

    # 4. aggregate LOCO metrics
    agg = {}
    for fold in report["loco"]:
        for name, met in fold["models"].items():
            agg.setdefault(name, []).append(met)
    summary = {}
    for name, mets in agg.items():
        def stat(key, sub=None):
            vals = []
            for m in mets:
                v = m
                for part in (sub or []):
                    v = v[part]
                v = v[key]
                try:
                    fv = float(v)
                except (TypeError, ValueError):
                    continue
                if np.isfinite(fv):
                    vals.append(fv)
            vals = np.array(vals, float)
            return {"mean": float(vals.mean()), "std": float(vals.std()),
                    "min": float(vals.min()), "max": float(vals.max()),
                    "n": int(vals.size)} if vals.size else None
        summary[name] = {
            "gof": stat("gof"), "rmse": stat("rmse"), "nrmse": stat("nrmse"),
            "loop_area_rel_err": stat("loop_area_rel_err"),
            "branch_separation": stat("branch_separation"),
            "branch_separation_pred": stat("branch_separation_pred"),
            "branch_separation_input": stat("branch_separation_input"),
            "branch_separation_input_pred":
                stat("branch_separation_input_pred"),
            "reversal_max": stat("max", ["reversal"]),
            "reversal_mean": stat("mean", ["reversal"]),
            "n_params": mets[0]["n_params"],
            "fit_seconds_mean": float(np.mean([m["fit_seconds"] for m in mets])),
        }
    report["loco_summary"] = summary

    (outdir / "zenodo_hysteresis_validation.json").write_text(
        json.dumps(report, indent=2))
    np.savez(outdir / "loco_predictions.npz", **all_fold_preds)
    print(f"wrote {outdir/'zenodo_hysteresis_validation.json'}")

    # 5. plots (fold-0 held-out predictions retained for overlays)
    try:
        c0 = ds.cycles[0]
        make_plots(report, ds, outdir,
                   u_test=ds.input[c0.start:c0.stop],
                   y_test=ds.output[c0.start:c0.stop],
                   preds=first_fold_preds)
    except Exception as exc:  # plots are best-effort
        print(f"plot generation failed: {exc}", file=sys.stderr)


def make_plots(report, ds, outdir, u_test=None, y_test=None, preds=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 5))
    for c in ds.cycles:
        sl = slice(c.start, c.stop)
        ax.plot(ds.input[sl], ds.output[sl], lw=0.8, alpha=0.8,
                label=f"cycle {c.index}" if c.index == 0 else None)
    ax.set_xlabel("Input (normalized)")
    ax.set_ylabel("Output (as released)")
    ax.set_title("Zenodo 15584329: four complete triangular cycles")
    ax.legend()
    fig.tight_layout()
    fig.savefig(outdir / "data_cycles.png", dpi=140)
    plt.close(fig)

    if u_test is not None and preds:
        fig, axes = plt.subplots(2, 4, figsize=(16, 7), sharex=True)
        axes = axes.ravel()
        for ax, (name, yh) in zip(axes, preds.items()):
            ax.plot(u_test, y_test, lw=0.9, label="measured", color="k")
            ax.plot(u_test, yh, lw=0.9, label=name, color="tab:red")
            ax.set_title(name)
            ax.legend(fontsize=7)
        for ax in axes[len(preds):]:
            ax.axis("off")
        fig.suptitle("Held-out cycle 0: measured vs predicted")
        fig.tight_layout()
        fig.savefig(outdir / "heldout_cycle0_predictions.png", dpi=140)
        plt.close(fig)

        # error vs input for the same predictions
        fig, ax = plt.subplots(figsize=(8, 4))
        for name, yh in preds.items():
            ax.plot(u_test, yh - y_test, lw=0.8, label=name)
        ax.axhline(0, c="k", lw=0.5)
        ax.set_xlabel("Input (normalized)")
        ax.set_ylabel("prediction - measurement")
        ax.set_title("Held-out cycle 0: model errors")
        ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(outdir / "heldout_cycle0_errors.png", dpi=140)
        plt.close(fig)

    summ = report.get("loco_summary", {})
    if summ:
        names = list(summ)
        gof = [summ[n]["gof"]["mean"] for n in names]
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.bar(names, gof)
        ax.axhline(0.95, ls="--", c="gray", lw=1)
        ax.set_ylabel("held-out GOF (mean over 4 LOCO folds)")
        ax.set_ylim(0, 1.05)
        ax.set_title("Zenodo actuator: held-out cycle GOF by model")
        fig.tight_layout()
        fig.savefig(outdir / "loco_gof.png", dpi=140)
        plt.close(fig)


if __name__ == "__main__":
    main()
