#!/usr/bin/env python3
"""Sensitivity / identifiability study for the Zenodo hysteresis validation.

Varies operator-grid density, GPI radius count, GPI multi-start and
Bouc-Wen fit stride on the *full* record (in-sample). Complements the
held-out LOCO protocol of run_zenodo_hysteresis_validation.py: these runs
measure how fragile each model's fit is to discretization and
initialization choices, not generalization.

Usage:
    python scripts/run_zenodo_sensitivity.py \
        --data /path/to/data.csv --output projects/zenodo_hysteresis_validation
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.constitutive_hysteresis import (
    asymmetric_play_states,
    fit_bouc_wen,
    fit_gpi_varpro,
    generalized_prandtl_ishlinskii_predict,
    predict_asymmetric_prandtl_ishlinskii_v2,
    predict_bouc_wen,
    predict_prandtl_ishlinskii_v2,
    threshold_grid,
)
from models.hysteresis_metrics import rmse
from models.zenodo_soft_actuator import load_zenodo_actuator
from scripts.run_zenodo_hysteresis_validation import (
    _masked_lstsq, _preisach_feature_matrix, nrmse_gof,
    predict_preisach_full,
)


def gof_of(y, yhat):
    return nrmse_gof(y, yhat)["gof"]


def dict_fit_predict(u, y, kind, param, intercept=True):
    """Generic dictionary fit; returns (gof, n_params, seconds)."""
    t0 = time.time()
    if kind == "preisach":
        alpha, beta = threshold_grid(u, levels=param)
        X = np.column_stack((np.ones(u.size),
                             _preisach_feature_matrix(u, alpha, beta)))
        coef = _masked_lstsq(X, y)
        model = {"bias": float(coef[0]), "relay_weights": coef[1:],
                 "alpha": alpha, "beta": beta}
        yhat = predict_preisach_full(u, model)
        npar = X.shape[1]
    elif kind == "pi":
        radii = np.linspace(0.02, 0.7, param)
        S = asymmetric_play_states(u, radii, radii)
        X = np.column_stack((np.ones(u.size), u, S))
        coef = _masked_lstsq(X, y)
        model = {"intercept": True, "bias": float(coef[0]),
                 "linear_gain": float(coef[1]), "play_weights": coef[2:],
                 "radii": radii}
        yhat = predict_prandtl_ishlinskii_v2(u, model)
        npar = X.shape[1]
    elif kind == "asym_pi":
        n = param
        widths = np.linspace(0.02, 0.5, n)
        lo, hi = np.meshgrid(widths, widths, indexing="ij")
        keep = ~((lo < 1e-9) & (hi < 1e-9))
        lw, hw = lo[keep], hi[keep]
        S = asymmetric_play_states(u, lw, hw)
        X = np.column_stack((np.ones(u.size), u, S))
        coef = _masked_lstsq(X, y)
        model = {"intercept": True, "bias": float(coef[0]),
                 "linear_gain": float(coef[1]), "play_weights": coef[2:],
                 "lower_widths": lw, "upper_widths": hw}
        yhat = predict_asymmetric_prandtl_ishlinskii_v2(u, model)
        npar = X.shape[1]
    else:
        raise ValueError(kind)
    return {"gof": gof_of(y, yhat), "n_params": int(npar),
            "seconds": time.time() - t0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--stride", type=int, default=10)
    ap.add_argument("--max-nfev", type=int, default=120)
    args = ap.parse_args()
    outdir = Path(args.output)
    outdir.mkdir(parents=True, exist_ok=True)

    ds = load_zenodo_actuator(args.data)
    u, y = ds.input, ds.output
    dt = float(np.median(np.diff(ds.time)))
    report = {"note": "in-sample sensitivity; not a held-out estimate",
              "dataset_md5": ds.provenance["checksums"]["md5"],
              "dictionary_grid": {}, "gpi": {}, "bouc_wen": {}}

    for kind, params in (("preisach", [9, 13, 17]),
                         ("pi", [15, 25, 40]),
                         ("asym_pi", [4, 6, 8])):
        for p in params:
            r = dict_fit_predict(u, y, kind, p)
            report["dictionary_grid"][f"{kind}_{p}"] = r
            print(f"{kind} param={p}: GOF={r['gof']:.4f} "
                  f"npar={r['n_params']} ({r['seconds']:.0f}s)", flush=True)

    us, ys = u[::args.stride], y[::args.stride]
    for kind in ("tanh", "poly"):
        for nr in (8, 12, 16):
            radii = np.linspace(0.02, 0.8, nr)
            t0 = time.time()
            model = fit_gpi_varpro(us, ys, radii, kind=kind,
                                   max_nfev=args.max_nfev)
            yhat = generalized_prandtl_ishlinskii_predict(u, model)
            report["gpi"][f"{kind}_r{nr}"] = {
                "gof": gof_of(y, yhat), "n_params": int(model["theta"].size),
                "nfev": model["nfev"], "success": model["success"],
                "seconds": time.time() - t0,
                "theta": [float(v) for v in model["theta"]]}
            print(f"gpi {kind} r={nr}: GOF={report['gpi'][f'{kind}_r{nr}']['gof']:.4f}"
                  f" ({report['gpi'][f'{kind}_r{nr}']['seconds']:.0f}s)",
                  flush=True)

    # GPI multi-start identifiability on the default config
    radii = np.linspace(0.02, 0.8, 12)
    starts = []
    for d2_0 in (0.3, 1.0, 4.0):
        t0 = time.time()
        model = fit_gpi_varpro(us, ys, radii, kind="tanh", delta2_0=d2_0,
                               max_nfev=args.max_nfev)
        yhat = generalized_prandtl_ishlinskii_predict(u, model)
        starts.append({"delta2_0": d2_0, "gof": gof_of(y, yhat),
                       "theta": [float(v) for v in model["theta"]],
                       "seconds": time.time() - t0})
        print(f"gpi multistart d2_0={d2_0}: GOF={starts[-1]['gof']:.4f}",
              flush=True)
    report["gpi"]["tanh_r12_multistart"] = starts

    for stride in (5, 10, 20):
        us2, ys2 = u[::stride], y[::stride]
        for asym in (False, True):
            name = f"bw_{'abw' if asym else 'cbw'}_s{stride}"
            t0 = time.time()
            model = fit_bouc_wen(us2, ys2, dt * stride, stride=1,
                                 asymmetric=asym, max_nfev=args.max_nfev)
            yhat = predict_bouc_wen(u, model, dt)
            report["bouc_wen"][name] = {
                "gof": gof_of(y, yhat), "params": model["params"],
                "nfev": model["nfev"], "success": model["success"],
                "seconds": time.time() - t0}
            print(f"{name}: GOF={report['bouc_wen'][name]['gof']:.4f} "
                  f"({report['bouc_wen'][name]['seconds']:.0f}s)", flush=True)

    (outdir / "zenodo_sensitivity.json").write_text(json.dumps(report, indent=2))
    print(f"wrote {outdir/'zenodo_sensitivity.json'}")


if __name__ == "__main__":
    main()
