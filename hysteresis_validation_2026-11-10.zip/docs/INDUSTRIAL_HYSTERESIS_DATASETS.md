# Industrial hysteresis: public experimental datasets and validation protocol

Status: **Zenodo actuator record audited and experimentally fitted with held-out cycle evaluation (LOCO GOF ≈ 0.96 for GPI-poly; see `projects/zenodo_hysteresis_validation/RESULTS_2026-11-09.md`); magnetic datasets fitted with quasi-static Jiles–Atherton (`projects/jiles_atherton_validation/RESULTS_2026-11-09.md`); piezoelectric datasets still candidates.**

This registry separates (i) measured actuator data, (ii) measured magnetic material data, and (iii) synthetic model checks. Raw data are not copied into the repository until the file schema, licence, attribution and preprocessing are checked.

## Priority A — actuator experiments

### Soft pneumatic actuators (Zenodo) — AUDITED 2026-11-09

- Record: https://doi.org/10.5281/zenodo.15584329
- Landing page: https://zenodo.org/records/15584329
- Dataset file: `data.csv` (10.4 MB; MD5 `654c05be81fa60391e4b481787c320d3`, SHA-256 `d66f9f862f4c23638a05e92639f28a03a753ad419d508010969ee453a9d2032e`)
- Licence: CC BY 4.0 (verified via Zenodo API).
- Companion article: de la Morena Duque, Ramos and Vázquez, *Hysteresis Modeling of Soft Pneumatic Actuators: An Experimental Review*, Actuators 14(7), 321 (2025), https://doi.org/10.3390/act14070321 (open access, CC BY).
- Schema audit (verified, `models/zenodo_soft_actuator.py` + `scripts/audit_hysteresis_csv.py`):
  - Columns `Input,Output,Time`; 240,001 rows; no missing/non-finite values; `Time` strictly increasing, median step 1/30 time units.
  - `Input`: dimensionless triangular command to the electronic pressure regulator, normalized to [0, 1]; 8 monotone half-cycles of 30,000 samples = **4 complete up-down cycles**, all starting/ending at Input ≈ 0.
  - `Output`: actuator curvature channel as released, observed range ≈ [0.00122, 0.01684]. The article describes output normalization to the unit, but the released values are *not* in [0, 1]; the loader therefore reports units as "as released" and applies no rescaling.
  - Frequency caveat: the article states f = 0.05 Hz. If `Time` is in seconds the record implies 0.0005 Hz (2000 time units per cycle); a centisecond interpretation gives 0.05 Hz. The CSV has no unit metadata — flagged as an open provenance question, not resolved by assumption.
- Loader: `models/zenodo_soft_actuator.py::load_zenodo_actuator` (checksum-verified, non-destructive, cycle segmentation by input reversals).
- Experimental validation: `scripts/run_zenodo_hysteresis_validation.py` implements leave-one-cycle-out evaluation of Preisach, classical PI, asymmetric PI, GPI (tanh/poly envelopes, variable-projection fit) and Bouc–Wen/ABW on identical splits; results in `projects/zenodo_hysteresis_validation/`.
- Gate status: **passed** — schema audited, loader committed, experimental fits reproducible. Results are experimental fits on one public record; they are not industrial qualification.

## Priority B — piezoelectric actuator benchmark

### Piezoelectric micromanipulator dataset (Data in Brief, 2020)

- Article / data description: https://doi.org/10.1016/j.dib.2020.105175
- Open article: https://pmc.ncbi.nlm.nih.gov/articles/PMC6997478/
- Licence of article: CC BY 4.0; confirm the supplementary-data terms before redistributing the archive.
- Two input/output experiments are described: 150 V, 1 Hz and 5 V, 300 Hz. The CSV files contain time, displacement and voltage; the 150 V / 1 Hz record has 50,001 samples and the 5 V / 300 Hz record has 200,001 samples. The article notes drift in the high-rate record and an initial transient in the other record.
- Intended use: rate/amplitude generalization test for PI/Preisach/Bouc–Wen and dynamic residual analysis. Preserve the authors' stated preprocessing and compare both raw and corrected data.

### Piezoelectric actuator Preisach identification dataset (Mendeley Data)

- Record: https://doi.org/10.17632/kzf668wggx.9
- Landing page: https://data.mendeley.com/datasets/kzf668wggx/9
- Description: measured voltage/displacement experiments over 0–5 V, including sinusoidal and triangular excitation files and identified Preisach density data.
- Licence shown by the repository: CC BY-NC 3.0. This is suitable for research comparison subject to attribution and non-commercial restrictions; it is not automatically suitable for commercial product training or redistribution.
- Intended use: independent Preisach baseline and frequency/amplitude comparisons.

## Magnetic material datasets for Jiles–Atherton

### EMPIR HEFMAG NO/GO steel-sheet loops — DOWNLOADED 2026-11-09

- Record: https://doi.org/10.5281/zenodo.5910893
- Archive `EMPIR 19ENG06 HEFMAG dataset loops NO and GO.zip`, MD5 `2ae32cfbcf0841e4a320d0adaf4e6355`, CC BY 4.0.
- Contents: `NO.dat`, `GO.dat` (tab-separated H [A/m], J [T]; three amplitude segments each, separated by `-- --` lines) and a descriptive PDF. Measurements: 50 Hz Epstein frame per IEC 60404-2.
- Loader: `models/magnetic_datasets.py::load_hefmag_segment` + `extract_major_loop` (each segment is one dominant major loop with small ripple).
- Caveat: 50 Hz dynamic loops; quasi-static Jiles–Atherton fits are effective static approximations only.

### INRIM first magnetization curves — DOWNLOADED 2026-11-09

- Record: https://zenodo.org/records/10725890
- File `HBJ data_file_res_Zenodo.dat`, MD5 `bd1ccce8e79f2b88ec566ae6fede1242`, CC BY 4.0.
- 23 material blocks; per-block header gives column order (`H B`, `B H`, `H J`, `J H`), H in A/m, B/J in Tesla. First-magnetization curves only — anhysteretic/first-magnetization checks, not closed-loop loss validation.
- Loader: `models/magnetic_datasets.py::load_inrim_first_magnetization`.

### Magnetic powders / magnetorheological elastomers — FITTED 2026-11-10

- Record: https://doi.org/10.5281/zenodo.17053338
- File `Hysteresis_datasets.xlsx` (721,317 bytes), MD5 `f2284f438b4d54282ae893dec4697a29` — verified against the declared checksum. CC BY 4.0. Researcher: O. Sodomka (U. West Bohemia).
- Contents: `Results` metadata sheet (batch, material class, temperature, coil, sample geometry, author metrics) + 7 measurement sheets (`CIPSQ, CIPHS, Fe85Si15, NdFeB, SF-D360, Fe3O4, Fe2O3`), columns `H [kA/m], J [mT], B [mT], t [s]` at ~50 Hz. Each sheet = first-magnetization ramp + ONE major loop.
- Loader: `models/magnetic_powders.py`; analysis `scripts/run_powder_hysteresis_analysis.py`; results `projects/magnetic_powders_validation/`.
- Findings: JA+offset/free-Mirr0 reaches full-loop GOF 0.84–0.98 and branch-holdout GOF 0.89–0.97 on 5/7 samples; loop metrics reproduce the author table (HcJ/Br/Js) to ~3 decimals; systematic J-channel offset documented; single loop per sample → no cycle/amplitude holdout possible.

## Required validation protocol

1. **Data audit:** preserve source files; record DOI, version, checksum, licence, units, sampling rate, channels, missing values and preprocessing.
2. **Cycle segmentation:** identify full and minor loops from measured input reversals; do not close open trajectories artificially for fitting.
3. **Leakage prevention:** split by complete cycle / trial / specimen, never random individual samples across the same loop.
4. **Baselines:** PI, Preisach and Bouc–Wen for actuator displacement/force; Jiles–Atherton for magnetic M(H) or B(H) loops. Do not compare models across incompatible physical output variables.
5. **Metrics:** held-out RMSE/normalized RMSE, loop-area error, branch-separation error, reversal-point error and rate dependence where the protocol supports it.
6. **Uncertainty:** report parameter identifiability, sensitivity to initialization, confidence intervals across independent trials and convergence under time-step / discretization refinement.
7. **Industrial relevance:** report cycle energy loss, repeatability, drift, temperature/rate dependence and control implications. A successful synthetic test is not experimental validation; a good fit to one public dataset is not industrial qualification.

## Current implementation boundary

The repository contains synthetic/reference implementations of Preisach, Prandtl–Ishlinskii (classical, asymmetric and complete GPI) and Bouc–Wen, plus a scalar quasi-static Jiles–Atherton model. Models have been fitted to the Zenodo pneumatic record (leave-one-cycle-out) and to the EMPIR/INRIM magnetic records (leave-one-amplitude-out / low-field→high-field extrapolation); see the project result notes. These are experimental fits on public research data: no industrial performance, cost reduction, lifetime or control-benefit claim is made, and dynamic magnetic loss is outside the quasi-static JA class.
