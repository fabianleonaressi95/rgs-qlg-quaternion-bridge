"""Tests for the magnetic-powder workbook loader (Zenodo 17053338)."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

openpyxl = pytest.importorskip("openpyxl")

from models.magnetic_powders import (  # noqa: E402
    audit_sheet, extract_first_magnetization, extract_major_loop,
    load_results_metadata, load_sheet, load_workbook, loop_metrics_bh,
)


def _synthetic_loop(n=400):
    """Triangle-wave H with a rectangular J-H loop."""
    H = np.concatenate([
        np.linspace(60, -60, n // 2),
        np.linspace(-60, 60, n // 2 + 1)[1:],
    ])
    J = np.where(H > 0, 10.0 - 0.1 * H, -10.0 - 0.1 * H)
    J += 0.02 * H  # small reversible slope
    B = J + 1.2566 * H  # mu0*H in mT for H in kA/m
    t = np.arange(H.size) * 0.02
    return H, J, B, t


def _make_xlsx(path):
    H, J, B, t = _synthetic_loop()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Results"
    ws.append(["Researcher:", "Test", None, None])
    ws.append(["Id", "Batch", "Material", "Temperature[°C]", "Coil",
               "Date", "Time"])
    ws.append(["TEST-1", "1", "Ferrit", 20, "JH-26", "2024-01-01",
               "2024-01-01"])
    ws.append(["Scape", "Width[mm]", "Length[mm]", "Surface[cm²]",
               "Mass[g]", "Height[mm]", "Volume[cm³]"])
    ws.append(["Cubic", 17, 17, 2.89, 8.5, 2.4, 0.694])
    ws.append(["HcJ[kA/m]", "Br[mT]", "Js[mT]", "Hs[kA/m]", "HcB[kA/m]",
               "BH(B)[mT]", "BH(H)[kA/m]", "BHMax"])
    ws.append([10.0, 10.0, 10.0, 50.0, 2.0, 1.0, 1.0, 0.01])
    ds = wb.create_sheet("TESTSHEET")
    ds.append(["H [kA/m]", "J [mT]", "B [mT]", "t [s]"])
    for i in range(H.size):
        ds.append([float(H[i]), float(J[i]), float(B[i]), float(t[i])])
    wb.save(path)
    return path


def test_load_and_audit(tmp_path):
    p = _make_xlsx(tmp_path / "test.xlsx")
    wb = load_workbook(p)
    meta = load_results_metadata(wb)
    assert meta["experiments"][0]["id"] == "TEST-1"
    assert meta["author_metrics"][0]["Br_mT"] == 10.0
    d = load_sheet(wb, "TESTSHEET")
    assert d["H_kA_m"].shape == (400,)
    a = audit_sheet(d)
    assert a["n_samples"] == 400
    assert a["dt_median_s"] == pytest.approx(0.02)
    assert a["n_missing"] == 0
    # B = J + mu0 H consistency
    assert a["B_minus_J_minus_mu0H_max_mT"] < 0.01


def test_major_loop_extraction(tmp_path):
    p = _make_xlsx(tmp_path / "test.xlsx")
    wb = load_workbook(p)
    d = load_sheet(wb, "TESTSHEET")
    a = audit_sheet(d)
    lp = extract_major_loop(d, a)
    assert lp is not None
    assert len(lp["H_kA_m"]) > 300
    # loop should start near +Hmax region and end back near +Hmax
    assert lp["H_kA_m"][0] > 0
    fm = extract_first_magnetization(d, a, lp)
    # synthetic loop has no separate virgin ramp: first segment IS the
    # down-sweep, so virgin extraction may return the tiny prefix
    assert fm is None or len(fm["H_kA_m"]) < len(lp["H_kA_m"])


def test_loop_metrics():
    H, J, B, t = _synthetic_loop()
    m = loop_metrics_bh(H, J, B)
    # rectangular loop: |Hc| ~ 10/0.05? J=±10 at H=0 -> Br ~10; Hc where
    # J=0: on descending J=10-0.05H -> J=0 at H=200? no: J crosses 0
    # where branch value hits 0 -> |Hc| ~ 200? check sign structure
    assert m["J_max_mT"] == pytest.approx(J.max(), rel=1e-6)
    assert m["loop_loss_abs_J_m3"] > 0
    assert len(m["coercive_fields_kA_m"]) >= 1
    assert len(m["remanence_points_mT"]) >= 1
