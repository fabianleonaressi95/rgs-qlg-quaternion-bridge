import numpy as np
import pytest

from models.constitutive_hysteresis import (
    asymmetric_play_features,
    asymmetric_play_states,
    fit_bouc_wen,
    fit_gpi_varpro,
    generalized_prandtl_ishlinskii_predict,
    gpi_envelope,
    gpi_split_theta,
    simulate_bouc_wen,
)
from models.zenodo_soft_actuator import load_zenodo_actuator


def _synthetic_actuator_csv(path, n_half=400, cycles=2):
    """Small triangular record with the audited column schema."""
    us = []
    up = True
    for k in range(cycles * 2):
        seg = np.linspace(0.0 if up else 1.0, 1.0 if up else 0.0, n_half)
        us.append(seg if k == 0 else seg[1:])  # avoid duplicated turning points
        up = not up
    u = np.concatenate(us)
    y = 0.002 + 0.01 * u + 0.002 * np.sin(4 * np.pi * u)
    tt = np.arange(len(u)) / 30.0 + 1.0 / 30.0
    data = np.column_stack([u, y, tt])
    with open(path, "w") as f:
        f.write("Input,Output,Time\n")
        for row in data:
            f.write(f"{row[0]},{row[1]},{row[2]}\n")
    return data


def test_loader_segments_complete_cycles(tmp_path):
    csv = tmp_path / "data.csv"
    _synthetic_actuator_csv(csv, n_half=800, cycles=2)
    ds = load_zenodo_actuator(csv, verify_md5=False)
    assert len(ds.cycles) == 2
    assert all(1598 <= c.n_samples <= 1599 for c in ds.cycles)
    u, y = ds.cycle_slices([0, 1])
    assert u.shape == y.shape
    assert np.isclose(u[0], 0.0, atol=1e-9)
    assert np.isclose(u[-1], 0.0, atol=1e-9)
    assert ds.provenance["n_cycles"] == 2


def test_loader_rejects_wrong_schema(tmp_path):
    csv = tmp_path / "bad.csv"
    csv.write_text("a,b,c\n1,2,3\n")
    with pytest.raises(ValueError):
        load_zenodo_actuator(csv, verify_md5=False)


def test_asymmetric_play_states_matches_reference():
    rng = np.random.default_rng(0)
    u = np.cumsum(rng.normal(0, 0.05, 500))
    u = (u - u.min()) / (u.max() - u.min())
    lo = np.array([0.05, 0.2])
    hi = np.array([0.1, 0.35])
    fast = asymmetric_play_states(u, lo, hi)
    ref = asymmetric_play_features(u, lo, hi)
    assert fast.shape == ref.shape
    np.testing.assert_allclose(fast, ref, atol=1e-12)


def test_gpi_envelope_kinds():
    x = np.linspace(0, 1, 11)
    t = gpi_envelope("tanh", x, [1.0, 0.0, 0.0])
    np.testing.assert_allclose(t, np.tanh(x), atol=1e-12)
    p = gpi_envelope("poly", x, [0.0, 0.0])
    np.testing.assert_allclose(p, x * x, atol=1e-12)
    g = gpi_envelope("gauss", x, [1.0, 0.5, 0.2])
    assert np.all(np.isfinite(g))
    with pytest.raises(ValueError):
        gpi_envelope("gauss", x, [1.0, 0.5, -0.2])


def test_gpi_varpro_recovers_synthetic_loop():
    u = np.r_[np.linspace(0, 1, 800), np.linspace(1, 0, 800),
              np.linspace(0, 1, 800), np.linspace(1, 0, 800)]
    # synthetic GPI-ish output: affine + play on tanh-transformed input
    radii = np.linspace(0.05, 0.6, 8)
    kind = "tanh"
    theta = np.array([0.005, 0.001, 0.01, 1.5,
                      1.2, 0.1, 0.05, 0.9, -0.1, 0.02])
    states = generalized_prandtl_ishlinskii_predict.__wrapped__ if False else None
    from models.constitutive_hysteresis import gpi_predict_states
    S = gpi_predict_states(u, radii, kind, theta)
    d1, d2 = theta[2], theta[3]
    w = d1 * np.exp(-d2 * radii)
    y = theta[0] * u + theta[1] + S @ w
    fit = fit_gpi_varpro(u[::4], y[::4], radii, kind=kind, max_nfev=80)
    pred = generalized_prandtl_ishlinskii_predict(u, fit)
    rmse = float(np.sqrt(np.mean((pred - y) ** 2)))
    assert rmse < 0.2 * float(np.std(y))
    p0, M0, dd1, dd2, ar, al = gpi_split_theta(fit["theta"], kind)
    assert dd1 >= 0 and dd2 >= 0


def test_bouc_wen_asymmetry_flag_and_fit():
    u = np.r_[np.linspace(0, 1, 400), np.linspace(1, 0, 400)]
    dt = 1 / 30
    y = simulate_bouc_wen(u, dt, A=1.0, beta=0.4, gamma=0.3, n=2.0,
                          linear_gain=0.01, hysteretic_gain=0.02,
                          asym_delta=0.05)
    fit = fit_bouc_wen(u, y, dt, stride=2, asymmetric=True, max_nfev=60)
    assert "asym_delta" in fit["params"]
    from models.constitutive_hysteresis import predict_bouc_wen
    pred = predict_bouc_wen(u, fit, dt)
    assert pred.shape == y.shape
    assert np.all(np.isfinite(pred))
    # classical model ignores asymmetry -> larger error than ABW
    fit_c = fit_bouc_wen(u, y, dt, stride=2, asymmetric=False, max_nfev=60)
    pred_c = predict_bouc_wen(u, fit_c, dt)
    e_asym = np.sqrt(np.mean((pred - y) ** 2))
    e_cls = np.sqrt(np.mean((pred_c - y) ** 2))
    assert e_asym <= e_cls * 1.5
