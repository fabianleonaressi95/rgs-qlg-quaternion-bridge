import numpy as np
import pytest

from models.magnetic_datasets import (
    extract_major_loop, ja_units_check, load_inrim_first_magnetization,
    load_hefmag_segment,
)
from models.constitutive_hysteresis import simulate_jiles_atherton
from scripts.run_jiles_atherton_validation import fit_ja, loop_metrics


def _hefmag_like(path):
    "ident"""
    # two segments separated by '-- --'
    lines = []
    for seg in range(2):
        H = np.linspace(-100 - 50 * seg, 100 + 50 * seg, 500)
        J = 0.8 * np.tanh(H / 80.0) + 0.05 * np.sign(np.gradient(H))
        for h, j in zip(H, J):
            lines.append(f"{h}\t{j}")
        lines.append("--\t--")
    path.write_text("\n".join(lines) + "\n")


def test_hefmag_segment_parse(tmp_path):
    f = tmp_path / "NO.dat"
    _hefmag_like(f)
    H, J = load_hefmag_segment(f, 0)
    assert H.shape == J.shape and H.size == 500
    H1, _ = load_hefmag_segment(f, 1)
    assert np.abs(H1).max() > np.abs(H).max()


def test_extract_major_loop():
    H = np.r_[np.linspace(-100, 100, 400), np.linspace(100, -100, 400)]
    J = np.tanh(H / 50)
    Hl, Jl = extract_major_loop(H, J)
    assert Hl[0] < 0 and Hl[-1] < 0
    assert Hl.max() > 90


def test_inrim_parser(tmp_path):
    f = tmp_path / "inrim.dat"
    f.write_text(
        "Material A\nH B\n0.0 0.0\n10.0 1.0\n50.0 1.5\n"
        "Material B\nB H\n0.0 0.0\n0.5 20.0\n1.2 100.0\n")
    mats = load_inrim_first_magnetization(f)
    assert set(mats) == {"Material A", "Material B"}
    assert mats["Material A"]["H"][-1] == 50.0
    assert mats["Material B"]["order"] == "B H"
    assert mats["Material B"]["H"][-1] == 100.0


def test_ja_units_and_fit_smoke():
    # synthetic JA loop in consistent units
    H = np.r_[np.linspace(-2e4, 2e4, 800), np.linspace(2e4, -2e4, 800)]
    M = simulate_jiles_atherton(H, Ms=1.2e6, a=3e4, k=2e3, alpha=1e-3,
                                c=0.3, Mirr0=0.0)
    fit = fit_ja(H, M, max_nfev=40)
    assert fit["success"] or fit["nfev"] > 0
    assert 0.0 <= fit["c"] <= 1.0
    assert fit["Ms"] > 0
    # J [T] -> M [A/m] conversion
    M2 = ja_units_check(np.array([4e-7 * np.pi]))
    assert np.isclose(M2[0], 1.0)


def test_loop_metrics_keys():
    H = np.linspace(-100, 100, 200)
    J = np.tanh(H / 30) + 0.1 * np.sign(np.gradient(H))
    met = loop_metrics(H, J, J.copy())
    for k in ("gof", "loop_area_rel_err", "coercive_field_meas",
              "remanence_meas"):
        assert k in met
    assert met["loop_area_rel_err"] < 1e-9
