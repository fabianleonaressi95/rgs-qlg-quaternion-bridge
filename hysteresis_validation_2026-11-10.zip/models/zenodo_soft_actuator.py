"""Dataset-specific loader for the Zenodo soft pneumatic actuator record.

Source: de la Morena Duque, Ramos and Vazquez, "Hysteresis Modeling of Soft
Pneumatic Actuators: An Experimental Review", Actuators 14(7), 321 (2025),
https://doi.org/10.3390/act14070321, dataset https://doi.org/10.5281/zenodo.15584329
(CC BY 4.0).

Schema audit (verified against the published file, MD5
654c05be81fa60391e4b481787c320d3):

- columns: ``Input`` (dimensionless, triangular voltage command to the
  electronic pressure regulator, normalized to [0, 1]), ``Output``
  (actuator curvature channel as released; observed range roughly
  [0.0012, 0.0168] -- the article describes output normalization to the
  unit, but the released values are not in [0, 1]; units are therefore
  reported as *released* and no rescaling is applied by this loader),
  ``Time`` (monotone, uniform step 1/30 s, total span 8000 time units).
- 240001 samples, no missing values, no repeated timestamps.
- The input is piecewise-linear triangular: 8 monotone half-cycles of
  30000 samples each, i.e. 4 complete up-down cycles. All cycles start
  and end at Input ~ 0.
- The article states f = 0.05 Hz. If ``Time`` is seconds, the record
  implies 0.0005 Hz (2000 time units per cycle); if ``Time`` is in
  centiseconds the implied frequency is 0.05 Hz. The CSV carries no unit
  metadata, so this loader exposes the raw ``Time`` column and flags the
  ambiguity instead of guessing.

This module never modifies the raw samples; cycle segmentation only
returns index views.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

ZENODO_RECORD = "15584329"
ZENODO_DOI = "10.5281/zenodo.15584329"
ARTICLE_DOI = "10.3390/act14070321"
EXPECTED_MD5 = "654c05be81fa60391e4b481787c320d3"
EXPECTED_COLUMNS = ("Input", "Output", "Time")


@dataclass
class ActuatorCycle:
    """One complete up-down hysteresis cycle (view into the raw arrays)."""

    index: int
    start: int
    stop: int  # exclusive
    direction_first: str  # 'up' or 'down'

    @property
    def n_samples(self):
        return self.stop - self.start


@dataclass
class ActuatorDataset:
    input: np.ndarray
    output: np.ndarray
    time: np.ndarray
    cycles: list = field(default_factory=list)
    half_cycles: list = field(default_factory=list)
    provenance: dict = field(default_factory=dict)

    def cycle_slices(self, indices):
        """Return concatenated (u, y) views for the given cycle indices."""
        us, ys = [], []
        for i in indices:
            c = self.cycles[i]
            us.append(self.input[c.start:c.stop])
            ys.append(self.output[c.start:c.stop])
        return np.concatenate(us), np.concatenate(ys)


def file_checksums(path):
    path = Path(path)
    data = path.read_bytes()
    return {"md5": hashlib.md5(data).hexdigest(),
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data)}


def load_zenodo_actuator(path, verify_md5=True):
    """Load the Zenodo actuator CSV and segment it into complete cycles.

    Raises ValueError if the schema differs from the audited record.
    """
    path = Path(path)
    sums = file_checksums(path)
    if verify_md5 and sums["md5"] != EXPECTED_MD5:
        raise ValueError(
            f"MD5 mismatch for {path}: {sums['md5']} != {EXPECTED_MD5}. "
            "Refusing to treat a different file as the Zenodo record.")

    # genfromtxt is slow on 240k rows but dependency-free; use it once.
    raw = np.genfromtxt(path, delimiter=",", names=True, dtype=float)
    names = tuple(raw.dtype.names)
    if names != EXPECTED_COLUMNS:
        raise ValueError(f"expected columns {EXPECTED_COLUMNS}, got {names}")
    u = np.ascontiguousarray(raw["Input"], dtype=float)
    y = np.ascontiguousarray(raw["Output"], dtype=float)
    t = np.ascontiguousarray(raw["Time"], dtype=float)
    if not (np.all(np.isfinite(u)) and np.all(np.isfinite(y))
            and np.all(np.isfinite(t))):
        raise ValueError("non-finite samples present")
    if not np.all(np.diff(t) > 0):
        raise ValueError("Time column is not strictly increasing")

    # Segment on input reversals: a direction change of diff(u) marks a
    # half-cycle boundary. Each pair of consecutive half-cycles forms one
    # complete loop because every half-cycle spans the full [~0, ~1] range.
    du = np.diff(u)
    sgn = np.sign(du)
    # collapse exact zeros defensively (none expected, but stay non-destructive)
    change = np.flatnonzero(np.diff(sgn) != 0) + 1
    bounds = np.concatenate(([0], change, [len(u)]))
    half_cycles = []
    for k in range(len(bounds) - 1):
        s, e = int(bounds[k]), int(bounds[k + 1])
        if e - s < 3:
            continue
        direction = "up" if u[e - 1] > u[s] else "down"
        half_cycles.append({"start": s, "stop": e, "direction": direction})

    if len(half_cycles) % 2 != 0:
        raise ValueError("odd number of half-cycles; cannot pair complete loops")
    cycles = []
    for k in range(0, len(half_cycles), 2):
        a, b = half_cycles[k], half_cycles[k + 1]
        # sanity: second half-cycle must retrace to the start of the first
        if not (math.isclose(float(u[a["start"]]), float(u[b["stop"] - 1]),
                             abs_tol=2e-3)
                and math.isclose(float(u[a["stop"] - 1]),
                                 float(u[b["start"]]), abs_tol=2e-3)):
            raise ValueError(f"half-cycles {k},{k+1} do not close a loop")
        cycles.append(ActuatorCycle(
            index=k // 2, start=a["start"], stop=b["stop"],
            direction_first=a["direction"]))

    dt = float(np.median(np.diff(t)))
    provenance = {
        "zenodo_doi": ZENODO_DOI,
        "article_doi": ARTICLE_DOI,
        "license": "CC BY 4.0",
        "expected_md5": EXPECTED_MD5,
        "checksums": sums,
        "n_samples": int(len(u)),
        "columns": list(names),
        "input_range": [float(u.min()), float(u.max())],
        "output_range": [float(y.min()), float(y.max())],
        "output_units": "as released by Zenodo (see module docstring)",
        "time_step_median": dt,
        "time_span": [float(t[0]), float(t[-1])],
        "time_unit_status": "ambiguous: article states f=0.05 Hz; "
                            "raw Time implies 0.0005 Hz if seconds "
                            "(centisecond interpretation gives 0.05 Hz)",
        "n_cycles": len(cycles),
        "cycle_period_time_units": float(
            np.mean([c.stop - c.start for c in cycles]) * dt),
        "implied_frequency_hz_if_seconds": float(
            1.0 / (np.mean([c.stop - c.start for c in cycles]) * dt)),
    }
    return ActuatorDataset(u, y, t, cycles=cycles,
                           half_cycles=half_cycles, provenance=provenance)


def summarize_dataset(ds: ActuatorDataset):
    """Compact JSON-serializable audit summary for reports/tests."""
    out = dict(ds.provenance)
    out["cycles"] = [
        {"index": c.index, "start": c.start, "stop": c.stop,
         "n_samples": c.n_samples, "direction_first": c.direction_first}
        for c in ds.cycles]
    out["half_cycles"] = ds.half_cycles
    return out
