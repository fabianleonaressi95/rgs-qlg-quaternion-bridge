"""Loader and loop utilities for the magnetic-powder/magnetorheological
hysteresis workbook (Zenodo 17053338, CC BY 4.0).

The workbook ``Hysteresis_datasets.xlsx`` contains a ``Results`` metadata
sheet (researcher, batch, material class, temperature, coil, date, sample
dimensions and author-computed magnetic metrics) plus one sheet per
measurement. Every measurement sheet has columns::

    H [kA/m], J [mT], B [mT], t [s]

with ~50 Hz sampling. Each record consists of an initial positive-field
ramp (first magnetization / virgin curve, sometimes starting from a
remanent state) followed by one major loop: a sweep to negative maximum
field and a return sweep to positive maximum field.

Units are converted to SI inside the analysis scripts; this module keeps
the released units (kA/m, mT, s) so nothing is silently rescaled.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

try:
    import openpyxl
except ImportError:  # pragma: no cover
    openpyxl = None

EXPECTED_MD5 = "f2284f438b4d54282ae893dec4697a29"
DATA_SHEETS = ("CIPSQ", "CIPHS", "Fe85Si15", "NdFeB", "SF-D360",
               "Fe3O4", "Fe2O3")


def _require_openpyxl():
    if openpyxl is None:
        raise ImportError("openpyxl is required to read .xlsx workbooks")


def file_md5(path):
    import hashlib
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_workbook(path):
    """Open the workbook read-only; returns the openpyxl Workbook."""
    _require_openpyxl()
    return openpyxl.load_workbook(path, read_only=True, data_only=True)


def load_results_metadata(wb):
    """Parse the 'Results' sheet.

    Returns dict with 'experiments' (list of measurement metadata, in
    sheet order), 'samples' (list of sample-geometry rows) and
    'author_metrics' (list of author-computed metric rows aligned with
    the experiments).
    """
    ws = wb["Results"]
    rows = [list(r) for r in ws.iter_rows(values_only=True)]

    def section(header_idx):
        out = []
        for r in rows[header_idx + 1:]:
            if r[0] is None or (isinstance(r[0], str)
                                and not r[0].strip()):
                if out:
                    break
                continue
            out.append(r)
        return out

    # locate the three table headers by their first cell text
    headers = {}
    for i, r in enumerate(rows):
        c0 = r[0]
        if isinstance(c0, str):
            if c0.strip() == "Id":
                headers["experiments"] = i
            elif c0.strip() == "Scape":
                headers["samples"] = i
            elif c0.strip() == "HcJ[kA/m]":
                headers["author_metrics"] = i
    exp_rows = section(headers["experiments"])
    sample_rows = section(headers["samples"])
    metric_rows = section(headers["author_metrics"])

    def f(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None

    experiments = [{
        "id": r[0], "batch": r[1], "material_class": r[2],
        "temperature_C": f(r[3]), "coil": r[4],
        "date": str(r[5]), "time": str(r[6]),
    } for r in exp_rows if r[0]]
    samples = [{
        "shape": r[0], "width_mm": f(r[1]), "length_mm": f(r[2]),
        "surface_cm2": f(r[3]), "mass_g": f(r[4]),
        "height_mm": f(r[5]), "volume_cm3": f(r[6]),
    } for r in sample_rows if r[0]]
    author_metrics = [{
        "HcJ_kA_m": f(r[0]), "Br_mT": f(r[1]), "Js_mT": f(r[2]),
        "Hs_kA_m": f(r[3]), "HcB_kA_m": f(r[4]),
        "BH_B_mT": f(r[5]), "BH_H_kA_m": f(r[6]), "BHmax": f(r[7]),
    } for r in metric_rows]
    return {"experiments": experiments, "samples": samples,
            "author_metrics": author_metrics,
            "researcher": str(rows[0][1]), "contact": str(rows[1][1]),
            "affiliation": str(rows[2][1])}


def load_sheet(wb, sheet_name):
    """Return dict of float arrays H_kA_m, J_mT, B_mT, t_s for a sheet."""
    ws = wb[sheet_name]
    data = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] is None:
            continue
        try:
            data.append([float(row[0]), float(row[1]),
                         float(row[2]), float(row[3])])
        except (TypeError, ValueError):
            continue
    a = np.asarray(data, float)
    return {"H_kA_m": a[:, 0], "J_mT": a[:, 1],
            "B_mT": a[:, 2], "t_s": a[:, 3]}


def audit_sheet(d):
    """Basic quality audit of one measurement sheet (released units)."""
    H, J, B, t = d["H_kA_m"], d["J_mT"], d["B_mT"], d["t_s"]
    dt = np.diff(t)
    dH = np.diff(H)
    sgn = np.sign(dH)
    rev = np.flatnonzero(np.diff(sgn) != 0)
    # merge micro-reversals: keep only sign changes that persist
    seg_idx = np.concatenate([[0], rev + 1, [H.size - 1]])
    segs = []
    for i in range(seg_idx.size - 1):
        sl = slice(seg_idx[i], seg_idx[i + 1] + 1)
        if sl.stop - sl.start < 3:
            continue
        segs.append({
            "i0": int(seg_idx[i]), "i1": int(seg_idx[i + 1]),
            "n": int(sl.stop - sl.start),
            "H_start": float(H[sl][0]), "H_end": float(H[sl][-1]),
            "J_start": float(J[sl][0]), "J_end": float(J[sl][-1]),
            "duration_s": float(t[sl][-1] - t[sl][0]),
        })
    return {
        "n_samples": int(H.size),
        "H_range_kA_m": [float(H.min()), float(H.max())],
        "J_range_mT": [float(J.min()), float(J.max())],
        "B_range_mT": [float(B.min()), float(B.max())],
        "t_range_s": [float(t.min()), float(t.max())],
        "dt_median_s": float(np.median(dt)),
        "dt_min_s": float(dt.min()), "dt_max_s": float(dt.max()),
        "n_missing": int(np.sum(~np.isfinite(H) | ~np.isfinite(J)
                                | ~np.isfinite(B) | ~np.isfinite(t))),
        "n_sign_reversals_H": int(rev.size),
        "segments": segs,
        "B_minus_J_minus_mu0H_max_mT": float(
            np.max(np.abs(B - J - 4e-7 * np.pi * H * 1e3 * 1e3))),
        # note: H[kA/m]*1e3 -> A/m ; mu0*H[A/m] in T -> *1e3 mT
    }


def extract_major_loop(d, audit=None):
    """Return the major loop as the two long opposite-sweep segments.

    The record layout is: initial ramp up to +Hmax (first magnetization),
    sweep down to -Hmax, sweep back up to +Hmax. The major loop is the
    concatenation of the last two long monotone segments. Returns dict
    with indices and arrays, or None if the structure is not found.
    """
    if audit is None:
        audit = audit_sheet(d)
    long_segs = [s for s in audit["segments"]
                 if s["n"] > 100 and abs(s["H_end"] - s["H_start"]) > 100]
    if len(long_segs) < 2:
        return None
    # last two long segments form the closed loop (down then up)
    down, up = long_segs[-2], long_segs[-1]
    i0, i1 = down["i0"], up["i1"]
    H = d["H_kA_m"][i0:i1 + 1]
    J = d["J_mT"][i0:i1 + 1]
    B = d["B_mT"][i0:i1 + 1]
    t = d["t_s"][i0:i1 + 1]
    return {"i0": i0, "i1": i1, "H_kA_m": H, "J_mT": J,
            "B_mT": B, "t_s": t,
            "kind": "major_loop",
            "H_max_kA_m": float(np.abs(H).max())}


def extract_first_magnetization(d, audit=None, loop=None):
    """Return the initial ramp before the major loop (virgin curve)."""
    if audit is None:
        audit = audit_sheet(d)
    if loop is None:
        loop = extract_major_loop(d, audit)
    if loop is None:
        return None
    i0 = loop["i0"]
    if i0 < 3:
        return None
    return {"H_kA_m": d["H_kA_m"][:i0 + 1],
            "J_mT": d["J_mT"][:i0 + 1],
            "B_mT": d["B_mT"][:i0 + 1],
            "t_s": d["t_s"][:i0 + 1], "kind": "first_magnetization"}


def _crossings(x, y):
    """Interpolated x-values where y crosses zero, deduplicated."""
    s = np.sign(y)
    idx = np.flatnonzero(np.diff(s) != 0)
    vals = []
    for i in idx:
        if y[i + 1] == y[i]:
            continue
        vals.append(float(x[i] + (x[i + 1] - x[i])
                          * (0 - y[i]) / (y[i + 1] - y[i])))
    vals.sort()
    # cluster crossings closer than 1% of the x span (noise duplicates)
    if not vals:
        return []
    span = max(abs(v) for v in vals) or 1.0
    out = [vals[0]]
    for v in vals[1:]:
        if abs(v - out[-1]) > 0.01 * span:
            out.append(v)
    return out


def _loop_metrics_xy(H_kA_m, Y, y_kind):
    """Metrics on a closed loop in the H-Y plane.

    y_kind "J" -> polarization (mT); "B" -> flux density (mT).
    Returns coercive fields (kA/m), remanence (mT), extrema and the
    signed area product Y*dH in mT*kA/m.
    """
    H = np.asarray(H_kA_m, float)
    Y = np.asarray(Y, float)
    hc = _crossings(H, Y)
    rem = _crossings(Y, H)
    return {
        "coercive_fields_kA_m": hc,
        "remanence_points_mT": rem,
        f"{y_kind}_max_mT": float(Y.max()),
        f"{y_kind}_min_mT": float(Y.min()),
        "H_max_kA_m": float(H.max()), "H_min_kA_m": float(H.min()),
        "area_mT_kA_m": float(np.trapezoid(Y, H)),
    }


def loop_metrics_bh(H_kA_m, J_mT, B_mT):
    """Hysteresis metrics on a closed loop (released units).

    Computes the metric set on both the J-H (polarization) and B-H
    (flux density) planes, matching the author-reported HcJ/HcB
    convention, plus the physical hysteresis loss per unit volume
    ∮ H dB in J/m^3.
    """
    H = np.asarray(H_kA_m, float)
    J = np.asarray(J_mT, float)
    B = np.asarray(B_mT, float)
    mj = _loop_metrics_xy(H, J, "J")
    mb = _loop_metrics_xy(H, B, "B")
    H_A_m = H * 1e3
    B_T = B * 1e-3
    loss = float(np.trapezoid(H_A_m, B_T))  # ∮ H dB, J/m^3
    out = dict(mj)
    out.update({f"B_{k}": v for k, v in mb.items()
                if k not in ("H_max_kA_m", "H_min_kA_m")})
    out["loop_loss_J_m3"] = loss
    out["loop_loss_abs_J_m3"] = abs(loss)
    # loss estimate from the J-H plane: ∮ H dJ equals ∮ H dB on a closed
    # loop because ∮ H d(μ0H) = 0; kept as a consistency check.
    J_T = J * 1e-3
    out["loop_loss_J_m3_from_J"] = float(np.trapezoid(H_A_m, J_T))
    return out
