"""Reference constitutive hysteresis baselines for controlled synthetic/data tests.

Preisach and Prandtl-Ishlinskii are operator models; Bouc-Wen is a
differential phenomenological model. Parameter fitting here is deliberately
limited to the linear weights of fixed operator dictionaries.
"""
from __future__ import annotations
import numpy as np


def play_features(u, radii, initial_memory=None):
    u=np.asarray(u,float); radii=np.asarray(radii,float)
    if u.ndim!=1 or u.size<2 or radii.ndim!=1 or np.any(radii<0):
        raise ValueError("u must be a vector and radii nonnegative")
    out=np.empty((u.size,radii.size),float)
    for j,r in enumerate(radii):
        state=float(u[0] if initial_memory is None else initial_memory)
        state=max(u[0]-r,min(u[0]+r,state))
        out[0,j]=state
        for k in range(1,u.size):
            state=max(u[k]-r,min(u[k]+r,state))
            out[k,j]=state
    return out


def prandtl_ishlinskii_design(u, radii):
    u=np.asarray(u,float)
    return np.column_stack((u,play_features(u,radii)))


def fit_prandtl_ishlinskii(u,y,radii):
    X=prandtl_ishlinskii_design(u,radii)
    y=np.asarray(y,float)
    if y.shape!=(X.shape[0],): raise ValueError("y must match u")
    coeff,_,rank,_=np.linalg.lstsq(X,y,rcond=None)
    return {"linear_gain":float(coeff[0]),"play_weights":coeff[1:],
            "radii":np.asarray(radii,float),"rank":int(rank)}


def predict_prandtl_ishlinskii(u,model):
    X=prandtl_ishlinskii_design(u,model["radii"])
    coeff=np.r_[model["linear_gain"],model["play_weights"]]
    return X@coeff


def preisach_features(u,alpha,beta,initial_state=-1):
    u=np.asarray(u,float); alpha=np.asarray(alpha,float); beta=np.asarray(beta,float)
    if u.ndim!=1 or alpha.shape!=beta.shape or alpha.ndim!=1 or np.any(alpha<=beta):
        raise ValueError("require vector input and alpha > beta thresholds")
    states=np.full(alpha.size,float(initial_state))
    X=np.empty((u.size,alpha.size),float)
    for k,value in enumerate(u):
        states=np.where(value>=alpha,1.0,np.where(value<=beta,-1.0,states))
        X[k]=states
    return X


def fit_preisach(u,y,alpha,beta):
    X=preisach_features(u,alpha,beta)
    y=np.asarray(y,float)
    if y.shape!=(X.shape[0],): raise ValueError("y must match u")
    design=np.column_stack((np.ones(X.shape[0]),X))
    coeff,_,rank,_=np.linalg.lstsq(design,y,rcond=None)
    return {"bias":float(coeff[0]),"relay_weights":coeff[1:],
            "alpha":np.asarray(alpha,float),"beta":np.asarray(beta,float),
            "rank":int(rank)}


def predict_preisach(u,model):
    X=preisach_features(u,model["alpha"],model["beta"])
    return model["bias"]+X@model["relay_weights"]


def simulate_bouc_wen(u,dt,A=1.0,beta=0.5,gamma=0.5,n=2.0,
                      linear_gain=0.1,hysteretic_gain=1.0,z0=0.0,
                      asym_delta=0.0):
    """Integrate the classical rate-dependent Bouc-Wen state equation by RK4.

    ``asym_delta`` optionally adds the asymmetric correction
    ``asym_delta * u * sign(du/dt)`` inside the restoring-force derivative,
    i.e. the ABW1 variant psi[x] = delta * x * sgn(x_dot) of the reference
    literature. Default 0.0 recovers the classical symmetric model.
    """
    import math
    u=np.asarray(u,float)
    if u.ndim!=1 or u.size<2 or dt<=0 or n<1:
        raise ValueError("invalid input, dt or exponent")
    du=np.gradient(u,dt)
    n1=n-1.0
    z=[float(z0)]
    def f(state,velocity,xval):
        av=abs(velocity)
        s=1.0 if velocity>0.0 else (-1.0 if velocity<0.0 else 0.0)
        return (A*velocity-beta*av*abs(state)**n1*state
                -gamma*velocity*abs(state)**n
                +asym_delta*xval*s)
    for k in range(u.size-1):
        h=dt; v=float(du[k]); xk=float(u[k]); zk=z[-1]
        k1=f(zk,v,xk); k2=f(zk+.5*h*k1,v,xk+.5*h*v)
        k3=f(zk+.5*h*k2,v,xk+.5*h*v); k4=f(zk+h*k3,v,xk+h*v)
        zn=zk+h*(k1+2*k2+2*k3+k4)/6
        if not math.isfinite(zn) or abs(zn)>1e8:
            raise FloatingPointError("Bouc-Wen state diverged")
        z.append(zn)
    return linear_gain*u+hysteretic_gain*np.asarray(z)


def threshold_grid(u,levels=9):
    """Return a reproducible triangular Preisach grid over observed input range."""
    u=np.asarray(u,float)
    if levels<2 or u.ndim!=1 or u.size<2: raise ValueError("invalid grid request")
    lo,hi=float(np.min(u)),float(np.max(u))
    q=np.linspace(lo,hi,levels)
    pairs=[(a,b) for a in q for b in q if a>b]
    return np.array([p[0] for p in pairs]),np.array([p[1] for p in pairs])

def _langevin(x):
    """Stable Langevin function coth(x) - 1/x."""
    x=np.asarray(x,float)
    out=np.empty_like(x)
    small=np.abs(x)<1e-4
    xs=x[small]
    out[small]=xs/3.0-xs**3/45.0+2.0*xs**5/945.0
    xl=x[~small]
    out[~small]=1.0/np.tanh(xl)-1.0/xl
    return out


def _langevin_derivative(x):
    """Derivative of the Langevin function, with a stable small-x series."""
    x=np.asarray(x,float)
    out=np.empty_like(x)
    small=np.abs(x)<1e-4
    xs=x[small]
    out[small]=1.0/3.0-xs**2/15.0+2.0*xs**4/189.0
    xl=x[~small]
    out[~small]=1.0/(xl**2)-1.0/(np.sinh(xl)**2)
    return out


def simulate_jiles_atherton(H, Ms, a, k, alpha, c, Mirr0=0.0):
    """Simulate the classical scalar Jiles--Atherton magnetization model.

    Parameters use one consistent field/magnetization unit system:
    Ms saturation magnetization, a anhysteretic field scale, k pinning
    parameter, alpha mean-field coupling, and c reversible fraction (0..1).
    The irreversible state is advanced with a predictor-corrector step in H.
    This is a reference quasi-static model, not a dynamic eddy-current model.
    """
    H=np.asarray(H,float)
    if H.ndim!=1 or H.size<2 or not np.all(np.isfinite(H)):
        raise ValueError("H must be a finite 1-D vector with at least two samples")
    if not (Ms>0 and a>0 and k>0 and alpha>=0 and 0<=c<=1):
        raise ValueError("require Ms,a,k > 0, alpha >= 0 and 0 <= c <= 1")
    if not np.isfinite(Mirr0):
        raise ValueError("Mirr0 must be finite")

    import math
    Mirr=np.empty(H.size,float)
    M=np.empty(H.size,float)
    Mirr[0]=float(Mirr0)

    Ms_f=float(Ms); a_f=float(a)
    def langevin_scalar(x):
        if abs(x)<1e-4:
            return x/3.0-x**3/45.0+2.0*x**5/945.0
        return 1.0/math.tanh(x)-1.0/x

    def anhysteretic(he):
        return Ms_f*langevin_scalar(he/a_f)

    def irreversible_rate(he, mirr, direction):
        man=anhysteretic(he)
        delta=man-mirr
        denom=direction*k-alpha*delta
        if abs(denom)<1e-12*max(1.0,k,abs(alpha*delta)):
            raise FloatingPointError("Jiles-Atherton irreversible denominator is singular")
        return delta/denom

    man0=anhysteretic(H[0]+alpha*Mirr[0])
    M[0]=c*man0+(1.0-c)*Mirr[0]
    tol=1e-12*max(1.0,Ms_f)

    for i in range(1,H.size):
        dH=float(H[i]-H[i-1])
        if dH==0.0:
            Mirr[i]=Mirr[i-1]
            M[i]=M[i-1]
            continue
        direction=1.0 if dH>0.0 else -1.0
        r0=irreversible_rate(float(H[i-1])+alpha*M[i-1],Mirr[i-1],direction)
        pred_mirr=Mirr[i-1]+dH*r0
        pred_man=anhysteretic(float(H[i])+alpha*M[i-1])
        pred_M=c*pred_man+(1.0-c)*pred_mirr
        r1=irreversible_rate(float(H[i])+alpha*pred_M,pred_mirr,direction)
        Mirr[i]=Mirr[i-1]+0.5*dH*(r0+r1)

        # Close the mean-field relation H_eff = H + alpha*M by fixed-point
        # iteration; this avoids evaluating the output at a stale field.
        Mi=M[i-1]
        for _ in range(12):
            man=anhysteretic(float(H[i])+alpha*Mi)
            updated=c*man+(1.0-c)*Mirr[i]
            if abs(updated-Mi)<tol:
                Mi=updated
                break
            Mi=updated
        M[i]=Mi
    return M


def asymmetric_play_features(u, lower_widths, upper_widths, initial_memory=None):
    """Return asymmetric play-operator states for an input history.

    For operator j the memory state is projected at each sample onto
    [u[k] - lower_widths[j], u[k] + upper_widths[j]]. Unequal widths encode
    different loading and unloading reversal distances. This is an
    asymmetric PI dictionary baseline; it is not asserted to reproduce every
    convention called Generalized Prandtl-Ishlinskii (GPI) in the literature.
    """
    u = np.asarray(u, float)
    lower = np.asarray(lower_widths, float)
    upper = np.asarray(upper_widths, float)
    if (u.ndim != 1 or u.size < 2 or lower.ndim != 1 or upper.shape != lower.shape
            or np.any(lower < 0) or np.any(upper < 0)
            or not np.all(np.isfinite(u)) or not np.all(np.isfinite(lower))
            or not np.all(np.isfinite(upper))):
        raise ValueError("require finite vector input and matching nonnegative width vectors")
    out = np.empty((u.size, lower.size), float)
    for j, (lo, hi) in enumerate(zip(lower, upper)):
        state = float(u[0] if initial_memory is None else initial_memory)
        state = min(u[0] + hi, max(u[0] - lo, state))
        out[0, j] = state
        for k in range(1, u.size):
            state = min(u[k] + hi, max(u[k] - lo, state))
            out[k, j] = state
    return out


def asymmetric_prandtl_ishlinskii_design(u, lower_widths, upper_widths):
    """Design matrix for an asymmetric PI model with a direct linear term."""
    u = np.asarray(u, float)
    return np.column_stack((u, asymmetric_play_features(u, lower_widths, upper_widths)))


def fit_asymmetric_prandtl_ishlinskii(u, y, lower_widths, upper_widths):
    """Least-squares fit of asymmetric PI weights on a fixed threshold dictionary."""
    X = asymmetric_prandtl_ishlinskii_design(u, lower_widths, upper_widths)
    y = np.asarray(y, float)
    if y.shape != (X.shape[0],) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    coeff, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    return {"linear_gain": float(coeff[0]), "play_weights": coeff[1:],
            "lower_widths": np.asarray(lower_widths, float),
            "upper_widths": np.asarray(upper_widths, float), "rank": int(rank)}


def predict_asymmetric_prandtl_ishlinskii(u, model):
    X = asymmetric_prandtl_ishlinskii_design(
        u, model["lower_widths"], model["upper_widths"])
    coeff = np.r_[model["linear_gain"], model["play_weights"]]
    return X @ coeff


def asymmetric_play_states(u, lower_widths, upper_widths, initial_memory=None):
    """Vectorized-over-operators asymmetric play states.

    Same recursion as :func:`asymmetric_play_features` but loops over time
    with the operator axis vectorized, which is ~100x faster on long
    records. Returns an (n_samples, n_operators) array.
    """
    u = np.asarray(u, float)
    lower = np.asarray(lower_widths, float)
    upper = np.asarray(upper_widths, float)
    if (u.ndim != 1 or u.size < 2 or lower.ndim != 1
            or upper.shape != lower.shape or lower.size < 1
            or np.any(lower < 0) or np.any(upper < 0)
            or not np.all(np.isfinite(u)) or not np.all(np.isfinite(lower))
            or not np.all(np.isfinite(upper))):
        raise ValueError("require finite vector input and matching nonnegative width vectors")
    out = np.empty((u.size, lower.size), float)
    state = np.full(lower.size, float(u[0] if initial_memory is None else initial_memory))
    state = np.minimum(u[0] + upper, np.maximum(u[0] - lower, state))
    out[0] = state
    for k in range(1, u.size):
        state = np.minimum(u[k] + upper, np.maximum(u[k] - lower, state))
        out[k] = state
    return out


def _design_with_intercept(states, u, intercept):
    cols = [states]
    if intercept:
        cols.insert(0, np.ones((u.size, 1)))
    cols.append(u.reshape(-1, 1))
    return np.column_stack(cols)


def _split_affine_coeff(coeff, intercept, n_ops):
    pos = 0
    bias = 0.0
    if intercept:
        bias = float(coeff[0]); pos = 1
    linear = float(coeff[pos]); pos += 1
    weights = coeff[pos:pos + n_ops]
    return bias, linear, weights


def fit_prandtl_ishlinskii_v2(u, y, radii, intercept=True):
    """PI fit with optional intercept, using the fast state recursion.

    Classical PI is the symmetric special case of the asymmetric play
    operator (lower_width == upper_width == radius).
    """
    u = np.asarray(u, float); y = np.asarray(y, float)
    radii = np.asarray(radii, float)
    if y.shape != (u.size,) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    states = asymmetric_play_states(u, radii, radii)
    X = _design_with_intercept(states, u, intercept)
    coeff, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    bias, linear, weights = _split_affine_coeff(coeff, intercept, radii.size)
    return {"intercept": intercept, "bias": bias, "linear_gain": linear,
            "play_weights": weights, "radii": radii, "rank": int(rank)}


def predict_prandtl_ishlinskii_v2(u, model):
    radii = model["radii"]
    states = asymmetric_play_states(u, radii, radii)
    X = _design_with_intercept(states, u, model.get("intercept", True))
    return X @ np.concatenate(([model["bias"]] if model.get("intercept", True) else [],
                               [model["linear_gain"]], model["play_weights"]))


def fit_asymmetric_prandtl_ishlinskii_v2(u, y, lower_widths, upper_widths,
                                         intercept=True):
    """Asymmetric-PI dictionary fit: independent (lo, hi) dead-zone widths.

    This is the asymmetric play-operator baseline of PR #115 extended with
    an optional affine intercept. It is *not* the GPI formulation: here the
    input itself is unchanged and only the dead-zone widths differ between
    the loading and unloading sides; GPI instead applies the play operator
    to nonlinearly transformed envelope signals (see
    :func:`fit_generalized_prandtl_ishlinskii`).
    """
    u = np.asarray(u, float); y = np.asarray(y, float)
    lower = np.asarray(lower_widths, float)
    upper = np.asarray(upper_widths, float)
    if y.shape != (u.size,) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    states = asymmetric_play_states(u, lower, upper)
    X = _design_with_intercept(states, u, intercept)
    coeff, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    bias, linear, weights = _split_affine_coeff(coeff, intercept, lower.size)
    return {"intercept": intercept, "bias": bias, "linear_gain": linear,
            "play_weights": weights, "lower_widths": lower,
            "upper_widths": upper, "rank": int(rank)}


def predict_asymmetric_prandtl_ishlinskii_v2(u, model):
    lower = model["lower_widths"]; upper = model["upper_widths"]
    states = asymmetric_play_states(u, lower, upper)
    X = _design_with_intercept(states, u, model.get("intercept", True))
    return X @ np.concatenate(([model["bias"]] if model.get("intercept", True) else [],
                               [model["linear_gain"]], model["play_weights"]))


# ---------------------------------------------------------------------------
# Generalized Prandtl-Ishlinskii (GPI)
#
# Following the formulation used in de la Morena Duque, Ramos and Vazquez,
# Actuators 14(7), 321 (2025), each play operator acts on *transformed*
# input envelopes alpha_R(u), alpha_L(u) instead of the raw input:
#
#   Gamma^a_{r}[u](t_k) = max{ alpha_R(u_k) - r,
#                              min{ alpha_L(u_k) + r, Gamma^a_{r}[u](t_{k-1}) } }
#
#   y(t) = p0 * u(t) + M0 + sum_i p_i * Gamma^a_{r_i}[u](t),
#   p_i = delta1 * exp(-delta2 * r_i)
#
# This differs from the asymmetric PI above: the dead-zone asymmetry is
# produced by nonlinear envelope maps applied before the play operator,
# not by independent lower/upper widths on the raw input.
# ---------------------------------------------------------------------------

def gpi_envelope(kind, x, params):
    """Evaluate one GPI envelope function.

    kinds/params (per direction):
      'tanh': a*tanh(x + b) + c          -> params (a, b, c)
      'poly': x**2 + a*x + b             -> params (a, b)
      'gauss': a*exp(-(x-b)**2/(2*c))    -> params (a, b, c), c > 0
    """
    x = np.asarray(x, float)
    p = np.asarray(params, float)
    if kind == "tanh":
        if p.size != 3:
            raise ValueError("tanh envelope needs (a, b, c)")
        a, b, c = p
        return a * np.tanh(x + b) + c
    if kind == "poly":
        if p.size != 2:
            raise ValueError("poly envelope needs (a, b)")
        a, b = p
        return x * x + a * x + b
    if kind == "gauss":
        if p.size != 3:
            raise ValueError("gauss envelope needs (a, b, c)")
        a, b, c = p
        if c <= 0:
            raise ValueError("gauss envelope width c must be positive")
        return a * np.exp(-((x - b) ** 2) / (2.0 * c))
    raise ValueError(f"unknown envelope kind {kind!r}")


GPI_ENVELOPE_NPARAMS = {"tanh": 3, "poly": 2, "gauss": 3}


def gpi_split_theta(theta, kind):
    """Split the GPI parameter vector into named parts."""
    theta = np.asarray(theta, float)
    m = GPI_ENVELOPE_NPARAMS[kind]
    p0, M0, d1, d2 = theta[:4]
    alpha_r = theta[4:4 + m]
    alpha_l = theta[4 + m:4 + 2 * m]
    if alpha_l.size != m:
        raise ValueError("theta length inconsistent with envelope kind")
    return p0, M0, d1, d2, alpha_r, alpha_l


def gpi_predict_states(u, radii, kind, theta, initial_memory=None):
    """Play-operator states for the GPI model on input history ``u``."""
    u = np.asarray(u, float)
    radii = np.asarray(radii, float)
    _, _, _, _, alpha_r, alpha_l = gpi_split_theta(theta, kind)
    a_r = gpi_envelope(kind, u, alpha_r)
    a_l = gpi_envelope(kind, u, alpha_l)
    n_r = radii.size
    out = np.empty((u.size, n_r), float)
    state = np.full(n_r, float(u[0] if initial_memory is None else initial_memory))
    state = np.minimum(a_l[0] + radii, np.maximum(a_r[0] - radii, state))
    out[0] = state
    for k in range(1, u.size):
        state = np.minimum(a_l[k] + radii,
                           np.maximum(a_r[k] - radii, state))
        out[k] = state
    return out


def generalized_prandtl_ishlinskii_predict(u, model):
    """Evaluate a fitted GPI model dict (see fit_generalized_prandtl_ishlinskii)."""
    u = np.asarray(u, float)
    states = gpi_predict_states(u, model["radii"], model["envelope"],
                                model["theta"])
    _, _, d1, d2, _, _ = gpi_split_theta(model["theta"], model["envelope"])
    weights = d1 * np.exp(-d2 * model["radii"])
    p0, M0 = model["theta"][0], model["theta"][1]
    return p0 * u + M0 + states @ weights


def fit_generalized_prandtl_ishlinskii(u, y, radii, kind="tanh",
                                       theta0=None, bounds=None,
                                       max_nfev=None, x_scale=None):
    """Nonlinear least-squares fit of the GPI model.

    Parameters theta = [p0, M0, delta1, delta2, alpha_R..., alpha_L...] with
    operator weights p_i = delta1 * exp(-delta2 * r_i), following the
    vanishing-density parameterization of the reference article. Envelope
    kinds: 'tanh' (default), 'poly', 'gauss'.
    """
    from scipy.optimize import least_squares

    u = np.asarray(u, float); y = np.asarray(y, float)
    radii = np.asarray(radii, float)
    if y.shape != (u.size,) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    m = GPI_ENVELOPE_NPARAMS[kind]
    n_par = 4 + 2 * m
    if theta0 is None:
        theta0 = np.zeros(n_par)
        theta0[0] = 0.0      # p0: direct feedthrough
        theta0[1] = float(np.mean(y))  # M0: offset
        theta0[2] = float(np.std(y))   # delta1: weight scale
        theta0[3] = 1.0      # delta2: decay
        if kind == "tanh":
            theta0[4:7] = [1.0, 0.0, 0.0]    # alpha_R ~ tanh(u)
            theta0[7:10] = [1.0, 0.0, 0.0]   # alpha_L ~ tanh(u)
        elif kind == "poly":
            theta0[4:6] = [0.0, 0.0]
            theta0[6:8] = [0.0, 0.0]
        else:
            theta0[4:7] = [1.0, 0.5, 0.2]
            theta0[7:10] = [1.0, 0.5, 0.2]
    theta0 = np.asarray(theta0, float)
    if theta0.size != n_par:
        raise ValueError(f"theta0 must have {n_par} entries for {kind}")

    if bounds is None:
        lb = np.full(n_par, -np.inf)
        ub = np.full(n_par, np.inf)
        lb[2] = 0.0; ub[2] = np.inf   # delta1 >= 0
        lb[3] = 0.0; ub[3] = np.inf   # delta2 >= 0
        if kind == "gauss":
            lb[6] = 1e-6; ub[6] = np.inf   # c_R > 0
            lb[4 + m + 2] = 1e-6; ub[4 + m + 2] = np.inf  # c_L > 0
        bounds = (lb, ub)

    def resid(theta):
        try:
            pred = generalized_prandtl_ishlinskii_predict(u, {
                "radii": radii, "envelope": kind, "theta": theta})
        except (ValueError, FloatingPointError):
            return np.full(y.size, 1e3)
        r = pred - y
        if not np.all(np.isfinite(r)):
            return np.full(y.size, 1e3)
        # soft order-preservation penalty: alpha_L(u)+r_min >= alpha_R(u)-r_min
        # is enforced structurally per-operator; here we only guard gross
        # envelope crossings that would invert the dead zone for all r.
        return r

    sol = least_squares(resid, theta0, bounds=bounds, method="trf",
                        x_scale=x_scale if x_scale is not None else "jac",
                        max_nfev=max_nfev)
    return {"envelope": kind, "theta": sol.x, "radii": radii,
            "cost": float(sol.cost), "nfev": int(sol.nfev),
            "optimality": float(sol.optimality), "success": bool(sol.success),
            "message": str(sol.message)}


def fit_gpi_varpro(u, y, radii, kind="tanh", delta2_0=1.0,
                   envelope0=None, max_nfev=None, mask=None):
    """Fit the GPI model by variable projection.

    For fixed nonlinear parameters phi = (delta2, alpha_R params,
    alpha_L params) the model is linear in c = (p0, M0, delta1):

        y ~= p0*u + M0 + delta1 * (S @ exp(-delta2*r))

    where S are the GPI play-operator states. Each residual evaluation
    therefore costs one operator pass plus a 3-column bounded linear
    least squares, which is far cheaper than differentiating all
    parameters jointly. delta1 is constrained >= 0.
    """
    from scipy.optimize import least_squares, lsq_linear

    u = np.asarray(u, float); y = np.asarray(y, float)
    radii = np.asarray(radii, float)
    if mask is not None:
        mask = np.asarray(mask, bool)
        if mask.shape != (u.size,):
            raise ValueError("mask must match u length")
    else:
        mask = np.ones(u.size, bool)
    if y.shape != (u.size,) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    m = GPI_ENVELOPE_NPARAMS[kind]
    n_phi = 1 + 2 * m

    if envelope0 is None:
        phi0 = np.zeros(n_phi)
        phi0[0] = float(delta2_0)
        if kind == "tanh":
            phi0[1:4] = [1.0, 0.0, 0.0]
            phi0[4:7] = [1.0, 0.0, 0.0]
        elif kind == "gauss":
            phi0[1:4] = [1.0, 0.5, 0.2]
            phi0[4:7] = [1.0, 0.5, 0.2]
        # 'poly' zeros -> alpha_R = alpha_L = u**2 (symmetric baseline)
    else:
        phi0 = np.asarray(envelope0, float)
        if phi0.size != n_phi:
            raise ValueError(f"envelope0 must have {n_phi} entries")

    lb = np.full(n_phi, -np.inf)
    ub = np.full(n_phi, np.inf)
    lb[0] = 0.0                       # delta2 >= 0
    if kind == "gauss":
        lb[3] = 1e-6; ub[3] = np.inf          # c_R > 0
        lb[1 + m + 2] = 1e-6; ub[1 + m + 2] = np.inf  # c_L > 0 (index 6)

    def linear_fit(phi):
        d2 = float(phi[0])
        theta_env = np.concatenate(([0.0, 0.0, 1.0, d2], phi[1:]))
        states = gpi_predict_states(u, radii, kind, theta_env)
        w = np.exp(-d2 * radii)
        B = np.column_stack((u, np.ones(u.size), states @ w))
        Bm = B[mask]; ym = y[mask]
        res = lsq_linear(Bm, ym, bounds=([-np.inf, -np.inf, 0.0],
                                         [np.inf, np.inf, np.inf]),
                         method="bvls", tol=1e-12, max_iter=200)
        return res.x, B @ res.x

    def resid(phi):
        try:
            _, pred = linear_fit(phi)
        except (ValueError, FloatingPointError):
            return np.full(int(mask.sum()), 1e3)
        r = (pred - y)[mask]
        return r if np.all(np.isfinite(r)) else np.full(int(mask.sum()), 1e3)

    sol = least_squares(resid, phi0, bounds=(lb, ub), method="trf",
                        x_scale="jac", max_nfev=max_nfev)
    c, _ = linear_fit(sol.x)
    d2 = float(sol.x[0])
    theta = np.concatenate(([c[0], c[1], c[2], d2], sol.x[1:]))
    return {"envelope": kind, "theta": theta, "radii": radii,
            "linear_coeffs": {"p0": float(c[0]), "M0": float(c[1]),
                              "delta1": float(c[2])},
            "cost": float(sol.cost), "nfev": int(sol.nfev),
            "optimality": float(sol.optimality), "success": bool(sol.success),
            "message": str(sol.message)}


def fit_bouc_wen(u, y, dt, stride=1, theta0=None, asymmetric=False,
                 max_nfev=None, mask=None):
    """Least-squares fit of the (optionally asymmetric) Bouc-Wen model.

    Parameters: A, beta, gamma, n, linear_gain, hysteretic_gain, z0 and,
    when ``asymmetric`` is true, asym_delta. Fitting is performed on
    ``u[::stride]`` with effective step ``dt*stride``; evaluate on the
    full grid afterwards for honest metrics.
    """
    from scipy.optimize import least_squares

    u = np.asarray(u, float); y = np.asarray(y, float)
    if y.shape != (u.size,) or not np.all(np.isfinite(y)):
        raise ValueError("y must be finite and match u")
    if mask is not None:
        mask = np.asarray(mask, bool)
        if mask.shape != (u.size,):
            raise ValueError("mask must match u length")
        mask = mask[::stride]
    else:
        mask = np.ones(u.size // stride + (1 if u.size % stride else 0), bool)
    us = u[::stride]
    ys = y[::stride]
    dts = dt * stride
    n_par = 8 if asymmetric else 7
    sy = float(np.std(ys)) if ys.size else 1.0
    if theta0 is None:
        theta0 = np.array([1.0, 0.5, 0.5, 2.0,
                           0.4 * sy, 0.6 * sy, 0.0]
                          + ([0.0] if asymmetric else []), float)
    if theta0.size != n_par:
        raise ValueError(f"theta0 must have {n_par} entries")
    lb = np.array([0.0, -np.inf, -np.inf, 1.0, -np.inf, -np.inf, -np.inf]
                  + ([-0.2] if asymmetric else []))
    ub = np.array([np.inf, np.inf, np.inf, 12.0, np.inf, np.inf, np.inf]
                  + ([0.2] if asymmetric else []))

    def unpack(th):
        A, beta, gamma, n, lg, hg, z0 = th[:7]
        ad = th[7] if asymmetric else 0.0
        return A, beta, gamma, n, lg, hg, z0, ad

    def resid(th):
        try:
            pred = simulate_bouc_wen(us, dts, *unpack(th))
        except (ValueError, FloatingPointError, ZeroDivisionError):
            return np.full(int(mask.sum()), 1e3)
        r = (pred - ys)[mask]
        return r if np.all(np.isfinite(r)) else np.full(int(mask.sum()), 1e3)

    sol = least_squares(resid, theta0, bounds=(lb, ub), method="trf",
                        x_scale="jac", max_nfev=max_nfev)
    keys = ["A", "beta", "gamma", "n", "linear_gain", "hysteretic_gain", "z0"]
    if asymmetric:
        keys.append("asym_delta")
    return {"params": dict(zip(keys, sol.x)), "stride": int(stride),
            "dt_fit": float(dts), "cost": float(sol.cost),
            "nfev": int(sol.nfev), "optimality": float(sol.optimality),
            "success": bool(sol.success), "message": str(sol.message)}


def predict_bouc_wen(u, model, dt):
    p = model["params"]
    stride = model.get("stride", 1)
    # model was fit on strided data; for prediction we always simulate on
    # the *given* grid with its own dt (callers pass the matching dt).
    return simulate_bouc_wen(u, dt, p["A"], p["beta"], p["gamma"], p["n"],
                            p["linear_gain"], p["hysteretic_gain"], p["z0"],
                            p.get("asym_delta", 0.0))
