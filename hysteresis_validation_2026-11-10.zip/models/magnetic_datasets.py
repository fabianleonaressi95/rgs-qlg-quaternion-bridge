"""Loaders for open measured magnetic datasets (issue #114).

Sources (all verified CC BY 4.0 at download time):

- EMPIR 19ENG06 HEFMAG, Zenodo 5910893:
  https://doi.org/10.5281/zenodo.5910893
  Epstein-frame 50 Hz loops of non-oriented (NO) and grain-oriented (GO)
  FeSi steel. Files NO.dat / GO.dat contain tab-separated (H, J) rows in
  A/m and Tesla; segments are separated by ``-- --`` lines. Three
  amplitude levels per file.

- INRIM first magnetization curves, Zenodo 10725890:
  https://doi.org/10.5281/zenodo.10725890
  File HBJ data_file_res_Zenodo.dat: per-material blocks with a header
  line giving the column order (``H B``, ``B H``, ``H J`` or ``J H``),
  H in A/m and B/J in Tesla. These are first-magnetization (anhysteretic
  + irreversible) curves, not closed loops.

- Magnetic powders / MRE, Zenodo 17053338 (exploratory; .xlsx, not yet
  wired into the validation script).
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

EMPIR_EXPECTED = {
    "NO.dat": "see archive checksum in report",
    "GO.dat": "see archive checksum in report",
}
MU0 = 4e-7 * np.pi  # T m / A  (J = mu0 * M in SI)


def _parse_two_column_segments(path):
    """Parse tab/space separated 2-column numeric rows split by '--' lines."""
    segs, cur = [], []
    for line in Path(path).read_text().splitlines():
        parts = line.split()
        if len(parts) != 2:
            if cur:
                segs.append(np.asarray(cur, float))
                cur = []
            continue
        try:
            cur.append([float(parts[0]), float(parts[1])])
        except ValueError:
            if cur:
                segs.append(np.asarray(cur, float))
                cur = []
    if cur:
        segs.append(np.asarray(cur, float))
    return [s for s in segs if s.shape[0] >= 10]


def load_hefmag_segment(path, segment_index):
    """Return (H [A/m], J [T]) for one EMPIR segment."""
    segs = _parse_two_column_segments(path)
    s = segs[segment_index]
    return s[:, 0], s[:, 1]


def extract_major_loop(H, J):
    """Extract one major loop from a quasi-sinusoidal field record.

    EMPIR segments contain a single dominant major loop traced once
    (monotone field sweep with small 50 Hz ripple). The loop is taken
    from the last field minimum before the global maximum to the first
    field minimum after it. Falls back to the full record if the extrema
    structure is degenerate.
    """
    H = np.asarray(H, float); J = np.asarray(J, float)
    i_max = int(np.argmax(H))
    if i_max < 2 or i_max > len(H) - 3:
        return H, J
    i_lo = int(np.argmin(H[:i_max]))
    i_hi = i_max + int(np.argmin(H[i_max:]))
    if i_hi <= i_lo + 2:
        return H, J
    return H[i_lo:i_hi + 1], J[i_lo:i_hi + 1]


def load_inrim_first_magnetization(path):
    """Parse the INRIM HBJ file into per-material first-magnetization data.

    Returns dict name -> {"order": str, "H": A/m array, "B_or_J": T array}.
    Column order comes from the header token pair, never assumed.
    """
    lines = Path(path).read_text().splitlines()
    materials = {}
    i = 0
    pending_name = None
    while i < len(lines):
        s = lines[i].strip()
        if not s:
            i += 1
            continue
        parts = s.split()
        numeric = False
        if len(parts) >= 2:
            try:
                float(parts[0]); float(parts[1]); numeric = True
            except ValueError:
                numeric = False
        if s in ("H B", "B H", "H J", "J H") and pending_name is not None:
            order = s.split()
            rows = []
            i += 1
            while i < len(lines):
                p = lines[i].split()
                if len(p) >= 2:
                    try:
                        rows.append((float(p[0]), float(p[1])))
                        i += 1
                        continue
                    except ValueError:
                        pass
                break
            if rows:
                arr = np.asarray(rows, float)
                if order[0] == "H":
                    H, X = arr[:, 0], arr[:, 1]
                else:
                    X, H = arr[:, 0], arr[:, 1]
                materials[pending_name] = {"order": s, "H": H, "B_or_J": X}
            pending_name = None
            continue
        if not numeric and not s.startswith(("H ", "B ", "J ")):
            pending_name = s
        i += 1
    return materials


def ja_units_check(X_T):
    """Return magnetization M [A/m] consistent with JA parameters."""
    return np.asarray(X_T, float) / MU0
