#!/usr/bin/env python3
"""Reproducible reconstruction of the available RGS-PSU 188D algebraic blocks.

Important: this script does NOT fabricate missing physical inputs. The archived 188D
bundle contains K0, Kinv, PG, J, JA, JB and related geometry arrays, but not the
N/J_canon/SST matrices, nor a connection-induced D_omega/E_omega, nor group generators
rho(g). The finite oscillator below is an explicit reference model, not a claim that
it is the project's original SST operator.
"""
import os, json, zipfile
import numpy as np

ROOT=os.path.dirname(os.path.abspath(__file__))
SRC=os.path.join(ROOT,'unpacked')
OUT=os.path.join(ROOT,'RGS_PSU_RECONSTRUCTION_COMPLETE')
os.makedirs(OUT,exist_ok=True)

def fnorm(x): return float(np.linalg.norm(x,'fro'))
def rel(x,ref): return fnorm(x)/max(fnorm(ref),np.finfo(float).tiny)
def savej(name,obj):
    with open(os.path.join(OUT,name),'w') as f: json.dump(obj,f,indent=2,allow_nan=False)

K=np.load(os.path.join(SRC,'K0.npy'))
Ki=np.load(os.path.join(SRC,'Kinv.npy'))
PG=np.load(os.path.join(SRC,'P_G.npy'))
J=np.load(os.path.join(SRC,'J.npy'))
JA=np.load(os.path.join(SRC,'J_A.npy'))
JB=np.load(os.path.join(SRC,'J_B.npy'))
M=np.load(os.path.join(ROOT,'RGS_PSU_all_matrices.npz'))
R=M['R_geo_tangent']

# Hermitian spectral decomposition; cut is chosen in the observed gap (near-zero ~1e-12,
# positive spectrum begins at 0.5). A 0.25 threshold is therefore safely inside the gap.
Kh=(K+K.T.conj())/2
lam,V=np.linalg.eigh(Kh)
cut=0.25
mask=lam<cut
V0=V[:,mask]
P0=V0@V0.T.conj()
Pdyn=np.eye(K.shape[0])-P0

# Explicit finite-dimensional truncated oscillator reference on dim=124.
Nw=124
a=np.zeros((Nw,Nw),dtype=float)
for n in range(1,Nw): a[n-1,n]=np.sqrt(n)
comm=a@a.T-a.T@a
Ptop=np.zeros((Nw,Nw)); Ptop[-1,-1]=1.
Cw=np.eye(Nw)-Nw*Ptop
Rbos=comm-Cw
SST=comm.copy() # explicit reference label only; not original SST data
SST_traceless=SST-np.trace(SST)/Nw*np.eye(Nw)

# Save reproducible matrices.
np.savez_compressed(os.path.join(OUT,'reconstructed_matrices.npz'),
                    K0=K,Kinv=Ki,PG_original=PG,P0_spectral=P0,P_dynamic=Pdyn,
                    eigenvalues=lam,eigenvectors=V,zero_basis=V0,
                    R_geo_tangent=R,J_bundle=J,J_A=JA,J_B=JB,
                    a_truncated=a,commutator_a_adag=comm,P_top=Ptop,C_W=Cw,
                    R_bos_reference=Rbos,SST_traceless_reference=SST_traceless)

# Algebraic diagnostics.
I=np.eye(K.shape[0])
report={
 'status':'RECONSTRUCTION_FROM_AVAILABLE_ARCHIVE; missing physical inputs explicitly flagged',
 'source_files':{'bundle':'188D_FINAL_BUNDLE.zip','auxiliary':'RGS_PSU_all_matrices.npz'},
 'dimensions':{'K0':list(K.shape),'PG':list(PG.shape),'J':list(J.shape),'J_A':list(JA.shape),'J_B':list(JB.shape),'R_geo_tangent':list(R.shape)},
 'K0':{
  'symmetry_fro':fnorm(K-K.T.conj()),
  'min_eigenvalue':float(lam.min()),'max_eigenvalue':float(lam.max()),
  'spectral_cut':cut,'kernel_rank_by_cut':int(mask.sum()),'dynamic_rank_by_cut':int((~mask).sum()),
  'smallest_64_abs_eigenvalues_max':float(np.max(np.abs(lam[:64]))),
  'first_dynamic_eigenvalue':float(lam[64]),
  'ladder_spacing_max_error':float(np.max(np.abs(lam[64:]-np.arange(0.5,12.9,0.1)))),
  'K0_PG_fro':fnorm(K@PG),'PG_K0_fro':fnorm(PG@K),
  'PG_idempotence_fro':fnorm(PG@PG-PG),
  'P0_idempotence_fro':fnorm(P0@P0-P0),
  'PG_vs_spectral_projector_fro':fnorm(PG-P0),
  'K0Kinv_minus_I_minus_PG_fro':fnorm(K@Ki-(I-PG)),
  'KinvK0_minus_I_minus_PG_fro':fnorm(Ki@K-(I-PG)),
  'Kinv_symmetry_fro':fnorm(Ki-Ki.T.conj()),
  'P0_trace':float(np.trace(P0).real),
  'K0P0_fro':fnorm(K@P0),
 },
 'geometry':{
  'Rgeo_symmetry_fro':fnorm(R-R.T.conj()),
  'Rgeo_involution_fro':fnorm(R@R-I),
  'Rgeo_signature_positive':int(np.sum(np.linalg.eigvalsh((R+R.T)/2)>0)),
  'Rgeo_signature_negative':int(np.sum(np.linalg.eigvalsh((R+R.T)/2)<0)),
  'commutator_Rgeo_PG_fro':fnorm(R@PG-PG@R),
  'commutator_Rgeo_P0_fro':fnorm(R@P0-P0@R),
  'commutator_Rgeo_K0_fro':fnorm(R@K-K@R),
  'rho_generators_available':False,
  'interpretation':'R_geo_tangent is an involution but does not commute with the kernel projector in the stored basis; no rho(g) generators are present to test group gauge invariance.'
 },
 'J_bundle':{
  'shape':list(J.shape),'gram_minus_identity_fro':fnorm(J.T.conj()@J-np.eye(J.shape[1])),
  'JA_gram_minus_identity_fro':fnorm(JA.T.conj()@JA-np.eye(JA.shape[1])),
  'JB_gram_minus_identity_fro':fnorm(JB.T.conj()@JB-np.eye(JB.shape[1])),
  'JA_dagger_JB_fro':fnorm(JA.T.conj()@JB),
  'warning':'J here is an archived 188x6 orthonormal frame, not sufficient to identify the separate factorization operator J_eff in N=J_eff^dagger J_eff+E.'
 },
 'factorization':{
  'status':'NOT_NUMERICALLY_TESTABLE_FROM_AVAILABLE_ARCHIVE',
  'missing':['N matrix used in K0_ALGEBRAIC_FACTORIZATION_REPORT.json','J_canon or the original ladder operator','connection omega / tetrad / covariant derivative D_omega','independently derived curvature-torsion correction E_omega'],
  'valid_residual_definition':'R_fact=N_omega-D_omega^dagger D_omega-E_omega',
  'prohibition':'Do not set D=N^(1/2) and call the resulting zero residual a geometric factorization.'
 },
 'bosonic_truncation_reference':{
  'dimension':Nw,'commutator_trace':float(np.trace(comm).real),
  'commutator_minus_CW_fro':fnorm(comm-Cw),
  'C_W_formula':'I_124 - 124 P_top',
  'C_W_trace':float(np.trace(Cw).real),
  'top_projector_rank':int(np.linalg.matrix_rank(Ptop)),
  'SST_traceless_trace':float(np.trace(SST_traceless).real),
  'status':'EXACT FOR THE EXPLICIT TRUNCATED OSCILLATOR BUILT IN THIS SCRIPT; NOT VERIFIED AS THE ORIGINAL PROJECT SST because SST was absent.'
 },
 'gauge_invariance_protocol':{
  'required':'For every supplied generator rho(g), compute ||rho(g)P0-P0rho(g)||_F and ||rho(g)K0-K0rho(g)||_F.',
  'status':'NOT TESTABLE: rho(g) matrices are not in the recovered bundle.'
 }
}
savej('reconstruction_report.json',report)

md='''# RGS–PSU: ricostruzione riproducibile dei tre blocchi\n\n## Ambito e provenienza\nQuesto pacchetto ricalcola le quantità dalle matrici effettivamente presenti in `188D_FINAL_BUNDLE.zip` e `RGS_PSU_all_matrices.npz`. Non inventa matrici mancanti.\n\n## 1. Fattorizzazione covariante\nLa verifica fisica richiede `N_omega`, `D_omega`, `E_omega` costruiti indipendentemente dalla connessione e dalla tetrade. Il residuo è `R_fact = N_omega - D_omega^† D_omega - E_omega`. I file disponibili non contengono questi oggetti, né `J_canon`; quindi il valore storico 782.78 non può essere riprodotto da questo archivio da solo. La scelta tautologica `D=N^(1/2)` non viene usata.\n\n## 2. Kernel spettrale\nSi diagonalizza la parte hermitiana di `K0`, con soglia 0.25 nel gap osservato fra i 64 autovalori quasi nulli (ordine 1e-12) e il primo autovalore dinamico 0.5. Il proiettore è `P0=V0 V0†`. La soglia è separata di ordini di grandezza dai due cluster. Si confronta `P0` con il `PG` archiviato e si misura separatamente l'invarianza rispetto a `R_geo_tangent`.\n\n**Nota:** `R_geo_tangent` non è una lista di generatori `rho(g)`. Il suo commutatore con `P0` è un test specifico di quella involuzione, non un test completo di invarianza di gauge del gruppo.\n\n## 3. Troncamento bosonico\nIl riferimento esplicito di dimensione 124 usa `a[n-1,n]=sqrt(n)`. Allora ` [a,a†] = I_124 - 124 P_top`, con `P_top=|123><123|`; la traccia del commutatore è zero. Il residuo rispetto a questo `C_W` è zero entro la precisione di macchina. Questo dimostra la formula per l'oscillatore troncato costruito qui, non dimostra che la matrice storica `SST` del progetto coincida con esso: tale matrice non è nel bundle recuperato.\n\n## Output\n- `reconstruction_report.json`: risultati numerici e input mancanti.\n- `reconstructed_matrices.npz`: proiettore spettrale, basi, commutatore bosonico di riferimento e matrici originali.\n- `reconstruct_all.py`: script riproducibile.\n\n## Conclusione\nIl kernel di `K0` e il troncamento bosonico di riferimento sono ricostruiti. La fattorizzazione geometrica e la gauge-invarianza completa restano non verificabili senza `N`, `J_canon`, `D_omega`, `E_omega` e i generatori `rho(g)`. Non si dichiara chiuso un test per cui manca l'input necessario.\n'''
open(os.path.join(OUT,'README.md'),'w').write(md)

# Copy script into output folder for self-contained package.
import shutil
shutil.copy2(__file__,os.path.join(OUT,'reconstruct_all.py'))
zipname=os.path.join(ROOT,'RGS_PSU_RECONSTRUCTION_COMPLETE.zip')
with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED) as z:
 for base,dirs,files in os.walk(OUT):
  for f in files:
   p=os.path.join(base,f); z.write(p,os.path.relpath(p,ROOT))
print(json.dumps(report,indent=2))
print('ZIP',zipname)
