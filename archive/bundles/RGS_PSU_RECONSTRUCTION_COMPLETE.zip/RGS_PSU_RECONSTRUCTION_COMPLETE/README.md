# RGS–PSU: ricostruzione riproducibile dei tre blocchi

## Ambito e provenienza
Questo pacchetto ricalcola le quantità dalle matrici effettivamente presenti in `188D_FINAL_BUNDLE.zip` e `RGS_PSU_all_matrices.npz`. Non inventa matrici mancanti.

## 1. Fattorizzazione covariante
La verifica fisica richiede `N_omega`, `D_omega`, `E_omega` costruiti indipendentemente dalla connessione e dalla tetrade. Il residuo è `R_fact = N_omega - D_omega^† D_omega - E_omega`. I file disponibili non contengono questi oggetti, né `J_canon`; quindi il valore storico 782.78 non può essere riprodotto da questo archivio da solo. La scelta tautologica `D=N^(1/2)` non viene usata.

## 2. Kernel spettrale
Si diagonalizza la parte hermitiana di `K0`, con soglia 0.25 nel gap osservato fra i 64 autovalori quasi nulli (ordine 1e-12) e il primo autovalore dinamico 0.5. Il proiettore è `P0=V0 V0†`. La soglia è separata di ordini di grandezza dai due cluster. Si confronta `P0` con il `PG` archiviato e si misura separatamente l'invarianza rispetto a `R_geo_tangent`.

**Nota:** `R_geo_tangent` non è una lista di generatori `rho(g)`. Il suo commutatore con `P0` è un test specifico di quella involuzione, non un test completo di invarianza di gauge del gruppo.

## 3. Troncamento bosonico
Il riferimento esplicito di dimensione 124 usa `a[n-1,n]=sqrt(n)`. Allora ` [a,a†] = I_124 - 124 P_top`, con `P_top=|123><123|`; la traccia del commutatore è zero. Il residuo rispetto a questo `C_W` è zero entro la precisione di macchina. Questo dimostra la formula per l'oscillatore troncato costruito qui, non dimostra che la matrice storica `SST` del progetto coincida con esso: tale matrice non è nel bundle recuperato.

## Output
- `reconstruction_report.json`: risultati numerici e input mancanti.
- `reconstructed_matrices.npz`: proiettore spettrale, basi, commutatore bosonico di riferimento e matrici originali.
- `reconstruct_all.py`: script riproducibile.

## Conclusione
Il kernel di `K0` e il troncamento bosonico di riferimento sono ricostruiti. La fattorizzazione geometrica e la gauge-invarianza completa restano non verificabili senza `N`, `J_canon`, `D_omega`, `E_omega` e i generatori `rho(g)`. Non si dichiara chiuso un test per cui manca l'input necessario.
