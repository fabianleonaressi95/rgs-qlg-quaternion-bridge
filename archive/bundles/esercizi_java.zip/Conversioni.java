// File: Conversioni.java
public class Conversioni {
    public static void main(String[] args) {
        // Conversione implicita (widening casting): da int a double
        int a = 5;
        double b = a; 
        
        // Conversione esplicita (narrowing casting): da double a int
        int c = (int) b;

        System.out.println("Valore int a: " + a);
        System.out.println("Valore double b (conversione implicita): " + b);
        System.out.println("Valore int c (conversione esplicita): " + c);
    }
}

/*
 * COSA ACCADE DURANTE I PASSAGGI?
 * 1. Conversione Implicita ($int \rightarrow double$): Avviene automaticamente perché il tipo 
 *    di destinazione ('double') ha una capacità maggiore rispetto alla sorgente ('int'). 
 *    Non vi è perdita di dati.
 * 2. Conversione Esplicita ($double \rightarrow int$): Richiede un'operazione di casting esplicita 
 *    (scrittura del tipo tra parentesi) perché si passa a un tipo con minore capacità o precisione. 
 *    Eventuali parti decimali vengono troncate (perdita di precisione).
 */
