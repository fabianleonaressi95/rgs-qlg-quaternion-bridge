public class ValoriBooleani {
    public static void main(String[] args) {
        boolean vero = true;
        boolean falso = false;
        System.out.println("L'affermazione è " + vero);
        System.out.println("L'altra affermazione è " + falso);
    }

    // boolean può assumere solo true o false e non è compatibile direttamente con numeri.
}
