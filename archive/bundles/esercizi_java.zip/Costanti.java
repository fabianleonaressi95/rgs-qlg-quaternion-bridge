public class Costanti {
    public static void main(String[] args) {
        final double PI = 3.14159;
        // PI = 3.14; // errore di compilazione: non si può assegnare un nuovo valore a una final
        System.out.println(PI);
    }

    // final rende la variabile assegnabile una sola volta: dopo l'inizializzazione
    // il suo riferimento o valore non può essere modificato.
}
