public class MainStructure {
    public static void main(String[] args) {
        System.out.println("Prima riga");
        System.out.println("Seconda riga");
    }

    // Una classe public deve avere lo stesso nome del file .java: il compilatore
    // usa questa corrispondenza per individuare la dichiarazione pubblica principale.
}
