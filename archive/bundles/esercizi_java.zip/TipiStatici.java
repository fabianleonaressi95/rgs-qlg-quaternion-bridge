// File: TipiStatici.java
public class TipiStatici {
    public static void main(String[] args) {
        int numero = 10;
        String parola = "test";

        /*
         * TENTATIVI ERRATI (Scommentando queste righe il programma non compila):
         * numero = "venti"; // ERROre: incompatible types: String cannot be converted to int
         * parola = 15;    // ERRORE: incompatible types: int cannot be converted to String
         */

        System.out.println("Numero: " + numero + ", Parola: " + parola);
    }
}

/*
 * COS'È LA "TIPIZZAZIONE STATICA"?
 * La tipizzazione statica significa che il tipo di ogni variabile viene verificato dal compilatore 
 * al momento della compilazione (prima che il programma venga eseguito), anziché a runtime. 
 * Una volta che una variabile è dichiarata con un determinato tipo (es. int o String), il suo tipo 
 * non può più cambiare durante l'intero ciclo di vita del programma, garantendo maggiore sicurezza 
 * ed eliminando molti errori logici prima dell'esecuzione.
 */

