// File: Caratteri.java
public class Caratteri {
    public static void main(String[] args) {
        char lettera = 'A';
        char numero = '5';
        char simbolo = '\u00A9'; // Simbolo del copyright ©

        System.out.println("Lettera: " + lettera);
        System.out.println("Numero come carattere: " + numero);
        System.out.println("Simbolo Unicode: " + simbolo);
    }
}

/*
 * COME GESTISCE JAVA I CARATTERI?
 * In Java, il tipo 'char' utilizza la codifica Unicode ed è memorizzato su 16 bit (2 byte). 
 * Questo permette di rappresentare non solo l'alfabeto latino classico (ASCII), ma decine 
 * di migliaia di caratteri provenienti da quasi tutte le lingue del mondo, oltre a simboli speciali 
 * ed emoji, specificandone direttamente il codice esadecimale (es. '\u00A9').
 */



