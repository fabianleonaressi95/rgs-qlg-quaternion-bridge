public class StringImmutabile {
    public static void main(String[] args) {
        String saluto = "Ciao";
        saluto = saluto + " Mondo";
        System.out.println(saluto);
    }

    // La String originale non viene modificata: la concatenazione crea un nuovo
    // oggetto String e saluto viene aggiornato per riferirsi al nuovo valore.
}
