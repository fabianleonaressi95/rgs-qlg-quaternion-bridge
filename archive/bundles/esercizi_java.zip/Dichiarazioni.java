public class Dichiarazioni {
    public static void main(String[] args) {
        // Dichiarazione multipla: compatta, ma può essere meno leggibile.
        int a = 1, b = 2, c = 3;

        // Dichiarazioni separate: generalmente più leggibili e facili da commentare.
        int primo = 1;
        int secondo = 2;
        int terzo = 3;

        System.out.println(a + ", " + b + ", " + c);
        System.out.println(primo + ", " + secondo + ", " + terzo);
    }
}
