// File: TipiPrimitivi.java
public class TipiPrimitivi {
    public static void main(String[] args) {
        // 1. byte: 1 byte (8 bit), intervallo da -128 a 127
        byte b = 100;
        
        // 2. short: 2 byte (16 bit), intervallo da -32.768 a 32.767
        short s = 30000;
        
        // 3. int: 4 byte (32 bit), intervallo da -2.147.483.648 a 2.147.483.647
        int i = 100000;
        
        // 4. long: 8 byte (64 bit), intervallo da -9.223.372.036.854.775.808 a 9.223.372.036.854.775.807
        long l = 15000000000L;
        
        // 5. float: 4 byte (32 bit), precisione singola IEEE 754
        float f = 5.75f;
        
        // 6. double: 8 byte (64 bit), precisione doppia IEEE 754
        double d = 19.99;
        
        // 7. char: 2 byte (16 bit), caratteri Unicode da '\u0000' a '\uffff' (0 a 65.535)
        char c = 'J';
        
        // 8. boolean: dimensione virtuale (solitamente 1 bit o 1 byte), valori true o false
        boolean veritiero = true;

        System.out.println("Il valore di byte è: " + b);
        System.out.println("Il valore di short è: " + s);
        System.out.println("Il valore di int è: " + i);
        System.out.println("Il valore di long è: " + l);
        System.out.println("Il valore di float è: " + f);
        System.out.println("Il valore di double è: " + d);
        System.out.println("Il valore di char è: " + c);
        System.out.println("Il valore di boolean è: " + veritiero);
    }
}

