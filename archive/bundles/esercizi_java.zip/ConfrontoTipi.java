public class ConfrontoTipi {
    public static void main(String[] args) {
        int x = 5;
        String y = "5";
        System.out.println(x);
        System.out.println(y);
    }

    // x è un tipo primitivo int; y è un oggetto String. Sembrano uguali in output,
    // ma hanno operazioni, rappresentazione e regole di tipo differenti.
}
