public class StringConfronto {
    public static void main(String[] args) {
        String a = "Java";
        String b = new String("Java");
        System.out.println(a == b);
        System.out.println(a.equals(b));
    }

    // == confronta i riferimenti agli oggetti; equals() confronta il contenuto.
    // Perciò qui == è false, mentre equals() è true.
}
