public class Concatenazione {
    public static void main(String[] args) {
        String prima = "Ciao ";
        String seconda = "mondo";
        String risultato = prima + seconda;
        System.out.println(risultato);
    }

    // Con le String, + produce una nuova sequenza di testo; il compilatore può
    // ottimizzare alcuni casi, ma le String restano immutabili.
}
