// File: StampaSequenza.java
public class StampaSequenza {
    public static void main(String[] args) {
        // Esempio con println (stampa e va a capo)
        System.out.println("one");
        System.out.println("two");
        System.out.println("three");
        
        System.out.println("-------------------");

        // Esempio con print (stampa senza andare a capo)
        System.out.print("one ");
        System.out.print("two");
        System.out.print("three");
    }
}

/*
 * DIFFERENZA TRA print E println:
 * - System.out.print(): Stampa il contenuto sullo schermo e lascia il cursore alla fine 
 *   della stringa stampata. Le eventuali stampe successive continueranno sulla stessa riga.
 * - System.out.println(): Stampa il contenuto sullo schermo e inserisce automaticamente 
 *   un carattere di ritorno a capo (newline). Il testo successivo inizierà sulla riga seguente.
 */
