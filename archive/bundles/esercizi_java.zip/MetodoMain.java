// File: MetodoMain.java
public class MetodoMain {
    
    public static void main(String[] args) {
        System.out.println("Esecuzione avviata");
        // Richiamo del secondo metodo statico
        inizia("sono qua");
    }

    public static void inizia("sono qua") {
        System.out.println("Metodo secondario 'inizia' eseguito con successo.");
    }
}

/*
 * COSA SIGNIFICA 'static' E PERCHÉ È NECESSARIO?
 * - La parola chiave 'static' indica che il membro appartiene alla classe in sé e non a una 
 *   specifica istanza (oggetto) di essa.
 * - È necessario nel metodo 'main' perché la Java Virtual Machine (JVM) deve poter avviare 
 *   l'esecuzione del programma richiamando il main direttamente dalla classe, senza dover 
 *   prima creare un oggetto di quella classe con l'operatore 'new'.
 * - È necessario anche per il metodo 'inizia()' in questo contesto poiché viene richiamato 
 *   direttamente all'interno di un altro contesto statico (il 'main'), il quale non può accedere 
 *   a metodi non statici senza un'istanza di riferimento.
 */
