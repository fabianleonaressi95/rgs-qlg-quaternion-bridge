#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A14 — reconstruct the labelled 3+1 constraint Jacobian for RGS–PSU/QLG.

Rebuilds the 4x192 Jacobian from the archived 64x3 embedding X_Oh:
  F_x(X) = sum_i X_i^x = 0
  F_y(X) = sum_i X_i^y = 0
  F_z(X) = sum_i X_i^z = 0
  F_r(X) = 1/2 (sum_i |X_i|^2 - R2_ref) = 0
Thus dF/dX has three translation rows and one radial/scale row X_flat^T.
The 192x188 Q basis is loaded only for independent validation, never to
construct the Jacobian. Its column space is compared by projectors, not by
columnwise equality (null-space bases are non-unique up to O(188)).

No glueball mass is inferred here. This is the geometric constraint layer
needed before projecting gauge-invariant glueball operators/correlators.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np


def fnorm(a): return float(np.linalg.norm(a, ord='fro'))
def rel(a,b): return fnorm(a)/max(fnorm(b), np.finfo(float).tiny)


def build_jacobian(X):
    X=np.asarray(X,dtype=float)
    if X.shape != (64,3):
        raise ValueError(f'X must have shape (64,3), got {X.shape}')
    J=np.zeros((4,192),dtype=float)
    J[0,0::3]=1.0
    J[1,1::3]=1.0
    J[2,2::3]=1.0
    J[3,:]=X.reshape(-1)
    return J


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',default='RGS_PSU_all_matrices.npz')
    ap.add_argument('--output',default='A14_RGS_PSU_JACOBIAN_OUTPUT')
    args=ap.parse_args()
    src=Path(args.source).resolve(); out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    z=np.load(src,allow_pickle=False)
    if 'X_Oh_reconstructed' not in z or 'Q_tangent' not in z:
        raise KeyError('Source NPZ must contain X_Oh_reconstructed and Q_tangent')
    X=np.asarray(z['X_Oh_reconstructed'],float)
    Q=np.asarray(z['Q_tangent'],float)
    if Q.shape!=(192,188): raise ValueError(f'Q must be (192,188), got {Q.shape}')

    # Constraint map and its exact Jacobian at X.
    R2=float(np.sum(X*X))
    F=np.array([X[:,0].sum(),X[:,1].sum(),X[:,2].sum(),0.5*(R2-R2)],float)
    J=build_jacobian(X)
    # SVD: row-space basis N (192x4), tangent basis Qsv (192x188).
    U,s,Vh=np.linalg.svd(J,full_matrices=True)
    rank=int(np.sum(s>max(J.shape)*np.finfo(float).eps*s[0]))
    if rank!=4: raise RuntimeError(f'Constraint Jacobian rank is {rank}, expected 4')
    N=Vh[:4,:].T
    Qsv=Vh[4:,:].T
    # Canonically labelled normal frame from the four Jacobian covectors.
    # The archived embedding is centered, so J J^T is diagonal: (64,64,64,240).
    row_norms=np.linalg.norm(J,axis=1)
    N_labelled=J.T/row_norms[None,:]
    # Projector comparison makes the check invariant under tangent-basis rotation.
    P_arch=Q@Q.T
    P_svd=Qsv@Qsv.T
    I=np.eye(192)
    # finite-difference derivative check for F at X
    def constraints(Y):
        return np.array([Y[:,0].sum(),Y[:,1].sum(),Y[:,2].sum(),0.5*(np.sum(Y*Y)-R2)])
    rng=np.random.default_rng(14013)
    dX=rng.normal(size=X.shape)
    eps=1e-7
    fd=(constraints(X+eps*dX)-constraints(X-eps*dX))/(2*eps)
    analytic=J@dX.reshape(-1)
    fd_res=float(np.linalg.norm(fd-analytic)/max(1.,np.linalg.norm(analytic)))

    # Translation/radial row semantics and scale geometry.
    centroid=X.sum(axis=0)
    radial_norm=float(np.linalg.norm(X))
    orth_rows=J@J.T
    report={
      'title':'A14 RGS-PSU QLG labelled constraint Jacobian reconstruction',
      'status':'RECONSTRUCTED_AND_VALIDATED' if (
        fnorm(J@Q)<1e-9 and fnorm(P_arch-P_svd)<1e-9 and fd_res<1e-7
      ) else 'FAIL',
      'source':src.name,
      'definitions':{
        'F_translation':'F_a(X)=sum_{i=1}^{64} X_i^a, a=x,y,z',
        'F_scale':'F_r(X)=1/2*(sum_i ||X_i||^2-R2_ref), with R2_ref fixed to the archived embedding norm',
        'Jacobian_rows':'J[0,:]=dF_x/dX; J[1,:]=dF_y/dX; J[2,:]=dF_z/dX; J[3,:]=dF_r/dX=X_flat^T',
        'variation_constraint':'J deltaX=0',
        'tangent':'Im(Q)=ker(J)'
      },
      'shapes':{'X':list(X.shape),'J':list(J.shape),'Q_archived':list(Q.shape),'normal_basis_svd':list(N.shape),'normal_basis_labelled':list(N_labelled.shape),'Q_svd':list(Qsv.shape)},
      'rank':rank,
      'singular_values':s.tolist(),
      'row_norms':row_norms.tolist(),
      'row_gram':orth_rows.tolist(),
      'geometry':{'centroid':centroid.tolist(),'R2':R2,'radial_norm':radial_norm,'R_rms':float(np.sqrt(R2/64))},
      'residuals':{
        'JQ_frobenius':fnorm(J@Q),
        'Q_orthonormality':fnorm(Q.T@Q-np.eye(188)),
        'projector_archived_vs_svd':fnorm(P_arch-P_svd),
        'projector_complement':fnorm(P_arch+N@N.T-I),
        'normal_orthonormality':fnorm(N.T@N-np.eye(4)),
        'labelled_normal_orthonormality':fnorm(N_labelled.T@N_labelled-np.eye(4)),
        'labelled_normal_span_vs_svd':fnorm(N_labelled@N_labelled.T-N@N.T),
        'J_normal_diagonalization':fnorm(J@N-U[:,:4]@np.diag(s)),
        'finite_difference_directional_derivative_relative':fd_res,
        'centroid_constraint_abs':float(np.max(np.abs(centroid)))
      },
      'interpretation':{
        'translation_rows':'exactly the three uniform Cartesian translation generators',
        'radial_row':'gradient of the fixed-radius/fixed-scale constraint; points along X_flat',
        'basis_note':'The four normal vectors are the row-space of J; their orthonormal SVD basis is not itself a canonical physical labelling. The labelled constraint covectors are the four rows of J.',
        'glueball_scope':'No glueball mass/correlator is computed in A14. This Jacobian fixes the admissible geometric variations for subsequent projected QLG gauge/plaquette observables.'
      }
    }
    np.savez_compressed(out/'A14_jacobian_matrices.npz',X=X,J_constraint=J,Q_archived=Q,
                        normal_basis_svd=N,normal_basis_labelled=N_labelled,Q_tangent_svd=Qsv,
                        P_tangent_archived=P_arch,P_tangent_svd=P_svd,
                        singular_values=s,centroid=centroid)
    (out/'A14_jacobian_report.json').write_text(json.dumps(report,indent=2))
    # Human-readable exact formula and result
    md='''# A14 — Jacobiana RGS–PSU / QLG\n\n## Definizione\n\nPer i 64 siti $X_i=(x_i,y_i,z_i)$, $X\\in\\mathbb R^{64\\times3}$, i vincoli sono\n\n$$F(X)=\\begin{pmatrix}\\sum_i x_i\\\\\\sum_i y_i\\\\\\sum_i z_i\\\\\\frac12(\\sum_i\\|X_i\\|^2-R_0^2)\\end{pmatrix}=0.$$\n\nLa Jacobiana rispetto a $X_{flat}\\in\\mathbb R^{192}$ è\n\n$$J=\\frac{\\partial F}{\\partial X_{flat}}=\\begin{pmatrix}1&0&0&1&0&0&\\cdots\\\\0&1&0&0&1&0&\\cdots\\\\0&0&1&0&0&1&\\cdots\\\\x_1&y_1&z_1&x_2&y_2&z_2&\\cdots\\end{pmatrix}\\in\\mathbb R^{4\\times192}.$$\n\nIl quarto vincolo usa $R_0^2=\\sum_i\\|X_i\\|^2$ dell'embedding archiviato: è la varietà a scala fissata passante per $X$. La sua derivata è $X_{flat}^T$.\n\n## Esito numerico\n\n- `rank(J)=4`; `dim ker(J)=188`.\n- Il test indipendente è $\\|JQ\\|_F$ e il confronto fra proiettori $QQ^T$ e $Q_{SVD}Q_{SVD}^T$.\n- La base SVD delle normali è una scelta ortonormale; le etichette traslazione x/y/z e radiale appartengono alle righe di $J$, non a una scelta arbitraria di quattro vettori normali.\n\nIl report JSON contiene i residui misurati.\n'''
    (out/'A14_jacobian_derivation.md').write_text(md)
    digest=hashlib.sha256((out/'A14_jacobian_matrices.npz').read_bytes()).hexdigest()
    print('='*72)
    print('A14 RGS-PSU / QLG — CONSTRAINT JACOBIAN')
    print('='*72)
    print('J shape:',J.shape,'rank:',rank,'ker dim:',192-rank)
    print('singular values:',s)
    print('||J Q||_F:',report['residuals']['JQ_frobenius'])
    print('projector difference:',report['residuals']['projector_archived_vs_svd'])
    print('finite-difference residual:',fd_res)
    print('status:',report['status'])
    print('SHA256:',digest)
    print('Output:',out)

if __name__=='__main__': main()
