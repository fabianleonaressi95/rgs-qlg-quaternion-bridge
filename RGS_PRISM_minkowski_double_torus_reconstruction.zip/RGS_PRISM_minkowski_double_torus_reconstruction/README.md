# RGS–PSU: reconstructed Minkowski double-sheet / double-torus audit

This reconstruction uses the recovered 64-site RGS–PRISM embedding, archived Q6 antipodal involution, and archived SO(3) link transport. It is a reproducible discrete audit, not a claim that the continuum ovalization is uniquely reconstructed.

## Exact cone lift
For each site `X_g`, define `V_±=(||X_g||, ±X_g)` and `η=diag(-1,1,1,1)`. Then `V_±ᵀηV_±=0` by construction. The antipodal map pairs `X_{p(g)}=-X_g`, with `J²=I`.

## Discrete translational mismatch
For each archived oriented edge, calculate `d_gh = X_h - R_gh X_g`. This is a parallel-transport mismatch, useful as a discrete Cartan/torsion candidate. It is not automatically the continuum torsion tensor: that requires a specified coframe, spin connection, and edge-to-continuum limit.

## Numbers
See `audit_report.json`. The cone residuals and antipodal pairing are exact up to floating-point error. The link defect is nonzero under the archived SO(3) transport. The physical inter-sheet coupling and its scale remain to be derived from the RGS–PSU action.
