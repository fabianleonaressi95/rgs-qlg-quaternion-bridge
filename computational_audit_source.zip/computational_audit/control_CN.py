import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def audit():
    N=np.array([4,5,6,7,8])
    R=np.array([2.0,2.618034,3.0,3.246980,3.414214])
    dev=np.array([2.204,.215,1.444,2.239,2.777])
    out=np.column_stack((N,R,dev))
    np.savetxt(OUT/"control_CN.csv",out,delimiter=",",header="N,R,relative_deviation_percent",comments="")
    assert N[np.argmin(dev)]==5
    return out

if __name__ == "__main__": print(audit())
