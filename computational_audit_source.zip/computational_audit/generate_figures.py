import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

R=Path("results"); F=R/"figures"; F.mkdir(parents=True,exist_ok=True)

data=np.loadtxt(R/"spectral_selector.csv",delimiter=",",skiprows=1)
plt.plot(data[:,0],data[:,4],"o-"); plt.xlabel("N"); plt.ylabel("V(R_N)/mu^4"); plt.grid(alpha=.3); plt.tight_layout(); plt.savefig(F/"spectral_selector.pdf"); plt.close()

a=np.array([.2,.1,.05,.025,.0125]); e=np.array([8.583e-3,2.146e-3,5.360e-4,1.340e-4,3.400e-5])
plt.loglog(a,e,"o-",label="supplied Test E"); plt.loglog(a,.2146*a*a,"--",label="0.2146 a^2"); plt.xlabel("a"); plt.ylabel("E(a)"); plt.grid(True,which="both",alpha=.3); plt.legend(); plt.tight_layout(); plt.savefig(F/"test_E.pdf"); plt.close()
