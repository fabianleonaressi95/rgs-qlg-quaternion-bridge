import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def lap(u,dx):
    return (np.roll(u,-1)-2*u+np.roll(u,1))/dx**2

def exact(x):
    return np.sin(2*np.pi*x)

def run(n):
    dx=1/n; x=np.arange(n)*dx
    numerical=-(2*np.pi)**2*exact(x)
    discrete=lap(exact(x),dx)
    err=np.sqrt(np.mean((discrete-numerical)**2))
    return dx,err

def audit(levels=(32,64,128,256)):
    rows=[]
    for n in levels:
        dx,e=run(n); rows.append((dx,e))
    rows=np.asarray(rows)
    orders=np.full(len(rows),np.nan)
    orders[:-1]=np.log(rows[:-1,1]/rows[1:,1])/np.log(rows[:-1,0]/rows[1:,0])
    out=np.column_stack((rows,orders))
    np.savetxt(OUT/"operator_convergence.csv",out,delimiter=",",header="a,error,observed_order",comments="")
    return out

if __name__ == "__main__":
    print(audit())
