import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def fit_power(a,e):
    p,logC=np.polyfit(np.log(a),np.log(e),1)
    return p,np.exp(logC)

def audit(dim=3, levels=(8,16,32,64)):
    # Periodic uniform lattice with target inverse metric I.
    # The exact symmetric stencil has zero moment error up to roundoff.
    rows=[]
    target=np.eye(dim)
    for n in levels:
        a=1/n
        M=np.zeros((dim,dim))
        for i in range(dim):
            ei=np.zeros(dim); ei[i]=a
            M += np.outer(ei,ei)/(a*a)
        # M here is the sum over + and - links divided by 2a^2.
        M=M
        err=np.linalg.norm(M-target,np.inf)
        eig=np.linalg.eigvalsh(M)
        rows.append((a,err,eig.min(),eig.max(),eig.max()/eig.min()))
    rows=np.asarray(rows)
    # Exact stencil has zero error; report conditioning instead of fitting zero.
    np.savetxt(OUT/"metric_convergence.csv",rows,delimiter=",",header="a,error,lambda_min,lambda_max,condition",comments="")
    return rows

if __name__ == "__main__":
    print(audit())
