# Computational audit

This package separates exact algebraic tests, elliptic moment tests,
metric C2 tests, Lorentzian hyperbolic tests, and Schwarzschild checks.
It does not prove continuum convergence or general-relativistic well-posedness.

## Install

python -m pip install -r requirements.txt

## Run

python spectral_selector.py
python metric_convergence.py
python operator_convergence.py
python lorentzian_stability.py
python schwarzschild_test.py
python control_CN.py
python generate_figures.py
