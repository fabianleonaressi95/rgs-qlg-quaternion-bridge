import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def lam(N):
    k=np.arange(N)
    return 2-2*np.cos(2*np.pi*k/N)

def audit(Nmax=20, mu=1.0):
    rows=[]
    for N in range(3,Nmax+1):
        l=lam(N)
        R=l[2]/l[1]
        formula=1.0 if N==3 else 4*np.cos(np.pi/N)**2
        V=0.5*mu**4*(R+1/R-3)**2
        rows.append((N,R,formula,abs(R-formula),V))
    rows=np.asarray(rows)
    assert int(rows[np.argmin(rows[:,4]),0])==5
    assert np.isclose(rows[2,4],0.0,atol=1e-14)
    assert np.all(rows[rows[:,0]!=5,4]>0)
    np.savetxt(OUT/"spectral_selector.csv",rows,delimiter=",",header="N,R_direct,R_formula,abs_error,V",comments="")
    return rows

if __name__ == "__main__":
    print(audit())
