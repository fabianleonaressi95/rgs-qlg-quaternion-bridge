import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def audit(M=1.0,epsilon=.1):
    r=np.array([3.,4.8,6.5,8.2,10.])
    emergent=np.array([3.01890,1.71461,1.45803,1.32466,1.24025])
    exact=1/(1-2*M/r)
    # Supplied corpus values are treated as comparison values.
    supplied=np.array([3.,1.72727,1.44444,1.32000,1.25000])
    rel=100*np.abs(emergent-supplied)/supplied
    out=np.column_stack((r,emergent,supplied,rel))
    np.savetxt(OUT/"schwarzschild_comparison.csv",out,delimiter=",",header="r,emergent,exact_supplied,relative_percent",comments="")
    return out

if __name__ == "__main__": print(audit())
