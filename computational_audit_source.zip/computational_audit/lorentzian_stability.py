import numpy as np
from pathlib import Path

OUT=Path("results"); OUT.mkdir(exist_ok=True)

def exact(x,t,c=1): return np.cos(2*np.pi*(x-c*t))

def run(nx,T=1,c=1,cfl=.4,gamma=0):
    dx=1/nx; dt=cfl*dx/c; nt=int(np.ceil(T/dt)); dt=T/nt
    x=np.arange(nx)*dx; u=exact(x,0,c); v=2*np.pi*c*np.sin(2*np.pi*x)
    def L(z): return (np.roll(z,-1)-2*z+np.roll(z,1))/dx**2
    up=u.copy(); u=u+dt*v+.5*dt**2*(c*c*L(u)-gamma*v)
    E=[]; C=[]
    for _ in range(1,nt):
        vh=(u-up)/dt
        un=2*u-up+dt**2*(c*c*L(u)-gamma*vh)
        vn=(un-up)/(2*dt)
        grad=(np.roll(u,-1)-np.roll(u,1))/(2*dx)
        E.append(.5*np.mean(vn*vn+c*c*grad*grad))
        C.append(np.sqrt(np.mean(((un-2*u+up)/dt**2-c*c*L(u)+gamma*vh)**2)))
        up,u=u,un
    err=np.sqrt(np.mean((u-exact(x,T,c))**2))
    return dx,dt,err,max(E),max(C)

def audit(levels=(50,100,200,400)):
    rows=[]
    for n in levels: rows.append(run(n))
    rows=np.asarray(rows); p=np.full(len(rows),np.nan)
    p[:-1]=np.log(rows[:-1,2]/rows[1:,2])/np.log(rows[:-1,0]/rows[1:,0])
    out=np.column_stack((rows,p))
    np.savetxt(OUT/"lorentzian_stability.csv",out,delimiter=",",header="dx,dt,L2_error,max_energy,max_residual,order",comments="")
    return out

if __name__ == "__main__": print(audit())
